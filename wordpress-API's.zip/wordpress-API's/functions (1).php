<?php
//define('DISALLOW_FILE_MODS', true);

function insert_og_image_in_head() {
    global $post;
    if(!has_post_thumbnail( $post->ID )) { //the post does not have featured image, use a default image
        $default_image= get_template_directory_uri()."/images/defaultshareimage.jpg"; //replace this with a default image on your server or an image in your media library
        echo '<meta property="og:image" content="' . $default_image . '"/>';
    }
    else{
        $thumbnail_src = wp_get_attachment_image_src( get_post_thumbnail_id( $post->ID ), 'medium' );
        echo '<meta property="og:image" content="' . esc_attr( $thumbnail_src[0] ) . '"/>';
    }
}
add_action( 'wp_head', 'insert_og_image_in_head', 5 );
 



function register_my_menus() {
register_nav_menus(
array(
'header-menu' => __( 'Header Menu Left' ),
'header-menu-right' => __( 'Header Menu Right' ),
'side-menu' => __( 'Side Menu' ),
'footer-menu' => __( 'Footer Menu' )
)
);
}
add_action( 'init', 'register_my_menus' );

add_theme_support( 'post-thumbnails' ); 


if( function_exists('acf_add_options_page') ) {
    
    acf_add_options_page(array(
        'page_title'    => 'Theme General Settings',
        'menu_title'    => 'Theme Settings',
        'menu_slug'     => 'theme-general-settings',
        'capability'    => 'edit_posts',
        'redirect'      => false
    ));
    
}






function arphabet_widgets_init() {

    register_sidebar( array(
        'name' => 'Home right sidebar',
        'id' => 'home_right_1',
        'before_widget' => '<div>',
        'after_widget' => '</div>',
        'before_title' => '<h2 class="rounded">',
        'after_title' => '</h2>',
    ) );
}
add_action( 'widgets_init', 'arphabet_widgets_init' );


function mytheme_add_woocommerce_support() {
add_theme_support( 'woocommerce' );
}

add_action( 'after_setup_theme', 'mytheme_add_woocommerce_support' );



add_filter('wpcf7_form_action_url', 'wpcf7_custom_form_action_url');
function wpcf7_custom_form_action_url( $url ){
$wpcf7 = WPCF7_ContactForm::get_current();
$wpcf7_id = $wpcf7->id();
if ( $wpcf7_id == 340 ) {
$url = 'https://enigma-study.com/enigmaApp/user/addNewUser1';// replace this with the new action url (excluding the 'http://')
}
return $url;
}

add_filter('wpcf7_form_elements', function($content) {
    $content = preg_replace('/<(span).*?class="\s*(?:.*\s)?wpcf7-form-control-wrap(?:\s[^"]+)?\s*"[^\>]*>(.*)<\/\1>/i', '\2', $content);

    return $content;
});

add_filter('wpcf7_autop_or_not', '__return_false');

add_role('user', __(
   'User'),
   array(
       'read'            => false, // Allows a user to read
       'create_posts'      => false, // Allows user to create new posts
       'edit_posts'        => false, // Allows user to edit their own posts
       'edit_others_posts' => false, // Allows user to edit others posts too
       'publish_posts' => false, // Allows the user to publish posts
       'manage_categories' => false, // Allows user to manage post categories
       )
);



add_action('rest_api_init', 'register_rest_images' );function register_rest_images(){
    register_rest_field( array('post'),
        'fimg_url',
        array(
            'get_callback'    => 'get_rest_featured_image',
            'update_callback' => null,
            'schema'          => null,
        )
    );
}function get_rest_featured_image( $object, $field_name, $request ) {
    if( $object['featured_media'] ){
        $img = wp_get_attachment_image_src( $object['featured_media'], 'app-thumb' );
        return $img[0];
    }
    return false;
}


require get_template_directory() . '/api/test.php';
require get_template_directory() . '/api/auth.php';
require get_template_directory() . '/api/general_faq.php';
require get_template_directory() . '/api/special_questions.php';
require get_template_directory() . '/api/faq.php';