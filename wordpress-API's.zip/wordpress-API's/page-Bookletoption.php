<?php
/**
 * Template Name: Bookletoption

 */

get_header(); 

?>
<div class="innermain">
  <div class="container">
   <div class="booklets_newarea">
    <div class="text-center">
     <h3>Booklets</h3>
   </div>
   <div class="bookletslist">
     <div class="row d-flex justify-content-center">
         
       <div class="col-lg-3 col-md-3 col-6">
        <a href="https://enigma-study.com/level-dictionary/?booklet=1">
         <div class="bookletslist_box">
           <div class="bookletslist_iconbox">
             <img src="<?php echo get_template_directory_uri(); ?>/images/bookletslistimg9.png">
           </div>
           <h5>Booklet <span>1</span></h5>
           <button><i class="fas fa-chevron-left"></i></button>
         </div>
         </a>
       </div>

        <div class="col-lg-3 col-md-3 col-6">
        <a href="https://enigma-study.com/chapters/?booklet=2">
         <div class="bookletslist_box">
           <div class="bookletslist_iconbox">
             <img src="<?php echo get_template_directory_uri(); ?>/images/bookletslistimg10.png">
           </div>
           <h5>Practice <span>1</span></h5>
           <button><i class="fas fa-chevron-left"></i></button>
         </div>
         </a>
       </div>

       <div class="col-lg-3 col-md-3 col-6">
        <a href="https://enigma-study.com/chapters/?booklet=3">
         <div class="bookletslist_box">
           <div class="bookletslist_iconbox">
             <img src="<?php echo get_template_directory_uri(); ?>/images/bookletslistimg11.png">
           </div>
           <h5>Practice <span>2</span></h5>
           <button><i class="fas fa-chevron-left"></i></button>
         </div>
         </a>
       </div>

       <div class="col-lg-3 col-md-3 col-6">
        <a href="https://enigma-study.com/chapters/?booklet=4">
         <div class="bookletslist_box">
           <div class="bookletslist_iconbox">
             <img src="<?php echo get_template_directory_uri(); ?>/images/bookletslistimg13.png">
           </div>
           <h5>Home Exams Booklet</h5>
           <button><i class="fas fa-chevron-left"></i></button>
         </div>
         </a>
       </div>
       <div class="col-lg-3 col-md-3 col-6">
        <a href="<?php echo home_url(); ?>/chapters/?booklet=6">
         <div class="bookletslist_box">
           <div class="bookletslist_iconbox">
             <img src="<?php echo get_template_directory_uri(); ?>/images/bookletslistimg1.png">
           </div>
           <h5>Sentence Completions</h5>
           <button><i class="fas fa-chevron-left"></i></button>
         </div>
         </a>
       </div>
       <div class="col-lg-3 col-md-3 col-6">
        <a href="https://enigma-study.com/chapters/?booklet=5">
         <div class="bookletslist_box">
           <div class="bookletslist_iconbox">
             <img src="<?php echo get_template_directory_uri(); ?>/images/bookletslistimg2.png">
           </div>
           <h5>Restatements Booklet</h5>
           <button><i class="fas fa-chevron-left"></i></button>
         </div>
         </a>
       </div>
       <div class="col-lg-3 col-md-3 col-6">
        <a href="<?php echo home_url(); ?>/chapters/?booklet=7">
         <div class="bookletslist_box">
           <div class="bookletslist_iconbox">
             <img src="<?php echo get_template_directory_uri(); ?>/images/bookletslistimg3.png">
           </div>
           <h5>Enigma Reader Booklet <span>1</span></h5>
           <button><i class="fas fa-chevron-left"></i></button>
         </div>
         </a>
       </div>
       <div class="col-lg-3 col-md-3 col-6">
        <a href="<?php echo home_url(); ?>/chapters/?booklet=8">
         <div class="bookletslist_box">
           <div class="bookletslist_iconbox">
             <img src="<?php echo get_template_directory_uri(); ?>/images/bookletslistimg4.png">
           </div>
           <h5>Enigma Reader Booklet <span>2</span></h5>
           <button><i class="fas fa-chevron-left"></i></button>
         </div>
         </a>
       </div>

        <div class="col-lg-3 col-md-3 col-6">
        <a href="<?php echo home_url(); ?>/chapters/?booklet=9">
         <div class="bookletslist_box">
           <div class="bookletslist_iconbox">
             <img src="<?php echo get_template_directory_uri(); ?>/images/bookletslistimg5.png">
           </div>
           <h5>Booklet R<span>1</span></h5>
           <button><i class="fas fa-chevron-left"></i></button>
         </div>
         </a>
       </div>

        <div class="col-lg-3 col-md-3 col-6">
        <a href="<?php echo home_url(); ?>/chapters/?booklet=10">
         <div class="bookletslist_box">
           <div class="bookletslist_iconbox">
             <img src="<?php echo get_template_directory_uri(); ?>/images/bookletslistimg6.png">
           </div>
           <h5>Booklet R<span>2</span></h5>
           <button><i class="fas fa-chevron-left"></i></button>
         </div>
         </a>
       </div>

        <div class="col-lg-3 col-md-3 col-6">
        <a href="#">
         <div class="bookletslist_box">
           <div class="bookletslist_iconbox">
             <img src="<?php echo get_template_directory_uri(); ?>/images/bookletslistimg7.png">
           </div>
           <h5>Booklet R<span>3</span></h5>
           <button><i class="fas fa-chevron-left"></i></button>
         </div>
         </a>
       </div>
       <div class="col-lg-3 col-md-3 col-6">
        <a href="#">
         <div class="bookletslist_box">
           <div class="bookletslist_iconbox">
             <img src="<?php echo get_template_directory_uri(); ?>/images/bookletslistimg8.png">
           </div>
           <h5>Booklet R<span>4</span></h5>
           <button><i class="fas fa-chevron-left"></i></button>
         </div>
         </a>
       </div>
       
        <div class="col-lg-3 col-md-3 col-6">
        <a href="https://enigma-study.com/random-leaderboard/">
         <div class="bookletslist_box">
           <div class="bookletslist_iconbox">
             <img src="<?php echo get_template_directory_uri(); ?>/images/bookletslistimg12.png">
           </div>
           <h5>Random</h5>
           <button><i class="fas fa-chevron-left"></i></button>
         </div>
         </a>
       </div>


     </div>
   </div>
   </div>
  </div>
</div>


<?php get_footer(); ?>