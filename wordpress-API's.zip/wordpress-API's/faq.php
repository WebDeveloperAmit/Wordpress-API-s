<?php

add_action( 'rest_api_init', function() {
  register_rest_route( 'myplugin/v2', '/faq-type', [
    'methods' => 'GET',
    'callback' => 'get_faq_type',
    'permission_callback' => '__return_true',
  ] );
} );


function get_faq_type( $params ) {
$url = get_template_directory_uri();
$list['special_question_image'] = $url.'/images/icon1.png';
$list['special_question_type'] = ' أسئلة خاصة في إنيجما';
$list['general_image'] = $url.'/images/icon2.png';
$list['general_type'] = ' أسئلة عامة';


$success_message = '';
$respond['status']        = true;
$respond['response_data'] = $list;
$respond['message'] = $success_message;


  return $respond;
}

add_action( 'rest_api_init', function() {
  register_rest_route( 'myplugin/v2', '/special-questions', [
    'methods' => 'GET',
    'callback' => 'special_questions',
    'permission_callback' => '__return_true',
  ] );
} );


function special_questions( $params ) {
$url = get_template_directory_uri();
$list['head_text'] = 'أسئلة في';
$list['book_list'] = 'الكتب';

$list['exam_list'] = ' الإمتحانات ';


$success_message = '';
$respond['status']        = true;
$respond['response_data'] = $list;
$respond['message'] = $success_message;


  return $respond;
}

add_action( 'rest_api_init', function() {
  register_rest_route( 'myplugin/v2', '/exam-list', [
    'methods' => 'GET',
    'callback' => 'exam_list',
    'permission_callback' => '__return_true',
  ] );
} );

function exam_list( $params ) {
  $projects =  get_posts( [
    'post_type' => 'examlist',
    'numberposts'      => -1,
    'order'            => 'DESC',
  ] );

// $defaults = array(
//         'numberposts'      => 5,
//         'category'         => 0,
//         'orderby'          => 'date',
//         'order'            => 'DESC',
//         'include'          => array(),
//         'exclude'          => array(),
//         'meta_key'         => '',
//         'meta_value'       => '',
//         'post_type'        => 'post',
//         'suppress_filters' => true,
//     );

$success_message = '';
$respond['status']        = true;
$respond['response_data'] = $projects;
$respond['message'] = $success_message;

return $respond;
}

//https://docs.google.com/spreadsheets/d/1s4FSM-WIkUK7a3nYH7mV_hkdpXoPsjzV_ocjJo7lGEQ/edit#gid=0

function sendContactMail( WP_REST_Request $request ) {
    $response = array(
        'status'  => 304,
        'message' => 'There was an error sending the form.'
    );

    $siteName = wp_strip_all_tags( trim( get_option( 'blogname' ) ) );
    $contactName = $request['contact_name'];
    $contactEmail = $request['contact_email'];
    $contactMessage = $request['contact_message'];

    $subject = $request['tpoic'];
//  $body = "<h3>$subject</h3><br/>";
    $body = "<p><b>Name:</b> $contactName</p>";
    $body .= "<p><b>Email:</b> $contactEmail</p>";
    $body .= "<p><b>Message:</b> $contactMessage</p>";

    //$to = get_option( 'admin_email' );
    $to = 'wtm.tanmoy@gmail.com';
    $headers = array(
        'Content-Type: text/html; charset=UTF-8',
        "Reply-To: $contactName <$contactEmail>",
    );

    if ( wp_mail( $to, $subject, $body, $headers ) ) {
        $response['status'] = 200;
        $response['message'] = 'Form sent successfully.';
        $response['test'] = $body;
    }

    return new WP_REST_Response( $response );
}

add_action( 'rest_api_init', function () {
    register_rest_route( 'myplugin/v2', 'send', array(
        'methods'             => 'POST',
        'callback'            => 'sendContactMail',
        'permission_callback' => '__return_true',
        'args'                => array(
            'contact_name'    => array(
                'required'          => true,
                'validate_callback' => function ( $value ) {
                    return preg_match( '/[a-z0-9]{2,}/i', $value ) ? true :
                        new WP_Error( 'invalid_contact_name', 'Your custom error.' );
                },
                'sanitize_callback' => 'sanitize_text_field',
            ),
            'contact_email'   => array(
                'required'          => true,
                'validate_callback' => 'is_email',
                'sanitize_callback' => 'sanitize_email',
            ),
            'topic'   => array(
                'required'          => true,
            ),
            'contact_message' => array(
                'required'          => true,
                'sanitize_callback' => 'sanitize_textarea_field',
            ),
        ),
    ) );
} );



add_action( 'rest_api_init', function() {
  register_rest_route( 'myplugin/v2', '/single-exam', [
    'methods' => 'GET',
    'callback' => 'single_exam',
    'permission_callback' => '__return_true',
  ] );
} );

function single_exam( WP_REST_Request $request ) {

$id = $request['id'];

    $projects =  get_posts( [
    'post_type' => 'examlist',
    // 'numberposts'      => -1,
    'post__in' => [ $id ]
  ] );


$success_message = '';
$respond['status']        = true;
$respond['response_data'] = $projects;
$respond['message'] = $success_message;


 return $respond;
}



add_action( 'rest_api_init', function () {
  register_rest_route( 'myplugin/v2', '/special_word', array(
    'methods' => 'GET',
    'callback' => 'handle_get_all',

  ) );
} );

function handle_get_all( $data ) {
    global $wpdb;
    $query = "SELECT * FROM special_word ORDER BY RAND() LIMIT 1";
    $list1 = $wpdb->get_results($query);


$list['response_data']   = $list1;
$list['status']          = true;
$list['message'] = 'success';


    return $list;
}

add_action( 'rest_api_init', function () {
  register_rest_route( 'myplugin/v2', '/english_word', array(
    'methods' => 'GET',
    'callback' => 'get_english_word',

  ) );
} );

function get_english_word( $data ) {
    global $wpdb;
    $query = "SELECT word_name,meaning_one FROM wp_tbl_questions ORDER BY RAND() LIMIT 1";
    $list1 = $wpdb->get_results($query);

$list1['cirrent_date']   = date('Y-m-d');
$list['response_data']   = $list1;
$list['status']          = true;
$list['message'] = 'success';


    return $list;
}


add_action( 'rest_api_init', function() {
  register_rest_route( 'myplugin/v2', '/book-list', [
    'methods' => 'GET',
    'callback' => 'book_list',
    'permission_callback' => '__return_true',
  ] );
} );

function book_list( $params ) { 
  $projects =  get_posts( [
    'post_type' => 'book',
    'numberposts'      => -1,
    'order'            => 'DESC',
  ] );


// $projects['featured_image'] = get_post_thumbnail_id( $projects );

$success_message = '';
$respond['status']        = true;
$respond['response_data'] = $projects;
$respond['message'] = $success_message;

return $respond;
}


add_action( 'rest_api_init', function() {
  register_rest_route( 'myplugin/v2', '/book-details', [
    'methods' => 'GET',
    'callback' => 'book_details',
    'permission_callback' => '__return_true',
  ] );
} );


function book_details( WP_REST_Request $request ) {

$id = $request['id'];

    $projects =  get_posts( [
    'post_type' => 'book',
    // 'numberposts'      => -1,
    'post__in' => [ $id ]
  ] );


foreach( $projects as &$p ) {
    $p->question = get_field('question',$p->ID);
  }


  $post_meta = get_post_meta( $id );
  $post_image = get_post_thumbnail_id( $id );      
$respond['featured_image'] = wp_get_attachment_image_src($post_image)[0];



$success_message = '';
$respond['status']        = true;
$respond['response_data'] = $projects;
$respond['message'] = $success_message;


 return $respond;
}

?>