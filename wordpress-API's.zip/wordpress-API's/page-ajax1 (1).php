<?php

/**

 * Template Name: Ajax1



 */

?>



<?php

global $wpdb;



$word=$_POST["word"];

$know=$_POST["know"];

$uid=$_POST["uid"];

$booklet=$_POST["booklet"];

$level=$_POST["level"];

$chapter=$_POST["chapter"];

$entry_date = date('Y-m-d');

$word_id=$_POST["word_id"];


if($level!=''){

$thepost = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM ".$wpdb->prefix."dictionaryprev WHERE user_id='$uid' and word='$word' and booklet='$booklet' and level='$level' and word_id='$word_id'" ) );

$id=$thepost->id;

$wpdb->get_results("SELECT * FROM ".$wpdb->prefix."dictionaryprev WHERE user_id='$uid' and word='$word' and booklet='$booklet' and level='$level' and word_id='$word_id' "); 

}elseif($chapter!=''){

$thepost = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM ".$wpdb->prefix."dictionaryprev WHERE user_id='$uid' and word='$word' and booklet='$booklet' and chapter='$chapter' and word_id='$word_id'" ) );

$id=$thepost->id;

$wpdb->get_results("SELECT * FROM ".$wpdb->prefix."dictionaryprev WHERE user_id='$uid' and word='$word' and booklet='$booklet' and chapter='$chapter' and word_id='$word_id' "); 
}


$total = $wpdb->num_rows;



if($total==0){



$wpdb->query("INSERT INTO `".$wpdb->prefix."dictionaryprev` (`id`,`user_id`, `word`, `booklet`, `level`, `chapter`, `entry_date`, `know`, `word_id`) VALUES (NULL, '$uid', '$word', '$booklet', '$level', '$chapter', '$entry_date', '$know', '$word_id')");

}else{



$wpdb->query("UPDATE `".$wpdb->prefix."dictionaryprev` SET know='$know' WHERE id='$id'");



}

if($level!=''){
$wpdb->get_results("SELECT * FROM wp_dictionaryprev WHERE user_id='$uid' AND booklet='$booklet' AND level='$level' AND know=1"); 
$as = $wpdb->num_rows;

$wpdb->get_results("SELECT * FROM wp_dictionaryprev WHERE user_id='$uid' AND booklet='$booklet' AND level='$level' AND know=3"); 
$bs = $wpdb->num_rows;

$wpdb->get_results("SELECT * FROM wp_dictionaryprev WHERE user_id='$uid' AND booklet='$booklet' AND level='$level' AND know=2"); 
$cs = $wpdb->num_rows;

echo '<span class="p_text_green">'.$as.'<div class="dq">'.$bs.'</div><div class="ds">'.$cs.'</div></span>';
}elseif($chapter!=''){

$wpdb->get_results("SELECT * FROM wp_dictionaryprev WHERE user_id='$uid' AND booklet='$booklet' AND chapter='$chapter' AND know=1"); 
$as = $wpdb->num_rows;

$wpdb->get_results("SELECT * FROM wp_dictionaryprev WHERE user_id='$uid' AND booklet='$booklet' AND chapter='$chapter' AND know=3"); 
$bs = $wpdb->num_rows;

$wpdb->get_results("SELECT * FROM wp_dictionaryprev WHERE user_id='$uid' AND booklet='$booklet' AND chapter='$chapter' AND know=2"); 
$cs = $wpdb->num_rows;

echo '<span class="p_text_green">'.$as.'<div class="dq">'.$bs.'</div><div class="ds">'.$cs.'</div></span>';


}
?>
