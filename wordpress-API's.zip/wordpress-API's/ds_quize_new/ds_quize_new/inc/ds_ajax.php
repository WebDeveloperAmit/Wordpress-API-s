<?php


//this part needed for ajaxurl page (admin-ajax page) which is not included by default in frontend but it is included in backend by default//
add_action('wp_head','ds_qz_ajaxurl');
function ds_qz_ajaxurl() {
?>
<script type="text/javascript">
var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
</script>
<?php
}

////////////////////////////////////////////////////////////////////////////////

add_action( 'wp_ajax_ds_qz_login', 'ds_qz_my_action_callback' );

add_action( 'wp_ajax_nopriv_ds_qz_login', 'ds_qz_my_action_callback' );
function ds_qz_my_action_callback() {
	 // this is how you get access to the database

	//$ds_x =  $_POST['ds_x'];
	//$whatever += 10;
	global $wpdb;
	$ds_qz_user_name=$_POST['ds_qz_user_name'];
	$ds_qz_password=md5($_POST['ds_qz_password']);
	
    $sql="select count(*) from `".$wpdb->prefix."ds_qz_users` where
	 user_name='$ds_qz_user_name' and password='$ds_qz_password'";
if($wpdb->get_var($sql)>0){
    $sql="select * from `".$wpdb->prefix."ds_qz_users` where
	 user_name='$ds_qz_user_name' and password='$ds_qz_password' limit 1";
    $ds_qz_user_data=$wpdb->get_row($sql);
	$_SESSION['ds_qz_user_name']=$ds_qz_user_data->user_name;
	$_SESSION['ds_qz_password']=$ds_qz_user_data->password;
	$_SESSION['ds_qz_user_id']=$ds_qz_user_data->user_id;
	
	/*$ds_qz_assignment_data=$wpdb->get_results("select q.quizz_name,q.id as quizz_id from `".$wpdb->prefix."ds_qz_assignments` as a,`".$wpdb->prefix."ds_qz_quizz` as q where a.quizz_id=q.id and a.user_group=$ds_qz_user_data->user_group ");*/
	$ds_qz_assignment=$wpdb->get_row("select count(*) as count from 
	`".$wpdb->prefix."ds_qz_assignments` where user_group=$ds_qz_user_data->user_group ");
	//echo $wpdb->last_query;
	
?>


<table width="500" border="1">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td align="center" id="ds_qz_ajax_area">
<script type="text/javascript" >
	jQuery(document).ready(function($) {
	  $("#ds_qz_assignment_btn").click( function() {
        
		var data = {
			'action': 'ds_qz_assignment_list',
			'ds_x': 2,
			'ds_qz_user_group': '<?php echo $ds_qz_user_data->user_group; ?>',
			
		};

		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		$.post(ajaxurl, data, function(response) {
		$("#ds_qz_ajax_area").html(response);
			//alert('response : ' + response);
		});
       });
	});
	</script>
	
	hello <?php echo $ds_qz_user_data->name; ?>
	Welcome To Quiz Section Home Page  &nbsp; <br />
	<span id="ds_qz_assignment_btn" style="cursor:pointer"><?php echo $ds_qz_assignment->count." Assignments" ; ?></span>
	
	</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
<?php
}else{
echo "Unable To Login";
}
	wp_die(); // this is required to terminate immediately and return a proper response
}
///////////////////////////////////////////////////////////////////////////////////////////////
add_action('wp_ajax_ds_qz_assignment_list','ds_qz_assignment_list');
function ds_qz_assignment_list(){ ?>
<script type="text/javascript">
jQuery(document).ready(function($) {
   $("#ds_qz_table  tbody tr").on("click", function(event){
     var ds_qz_row_num=$(this).index();
	 var ds_qz_counter=0;
	 $('input#ds_qz_assignment_id_hidden').each(function() {
	   if(ds_qz_counter==ds_qz_row_num){
	     var assignment_id=$(this).val();
		 //alert(assignment_id);
		 var data = {'action': 'ds_qz_assignment_details','ds_x': 2,'ds_qz_assignment_id':assignment_id,};
		 $.post(ajaxurl, data, function(response) {
		    $("#ds_qz_ajax_area").html(response);
			//alert('response : ' + response);
		 });
		 return false;
	   }
       ds_qz_counter++;
     })
	
   });
});



  /*function ds_qz_get_assignment_details(id){
     alert(id);
    var data = {
			'action': 'ds_qz_assignment_details',
			'ds_x': 2,
			'ds_qz_assignment_id': id,
			
		};

		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		$.post(ajaxurl, data, function(response) {
		$("#ds_qz_ajax_area").html(response);
			alert('response : ' + response);
		});
  
  }*/
</script>
 <?php $ds_qz_user_group=$_POST['ds_qz_user_group'];
  global $wpdb;
  $ds_qz_assignment_data=$wpdb->get_results("select a.id as assignment_id,q.quizz_name,q.id as quizz_id from
   `".$wpdb->prefix."ds_qz_assignments` as a,`".$wpdb->prefix."ds_qz_quizz` as q where a.quizz_id=q.id and a.user_group='$ds_qz_user_group' ");?>
   <table id="ds_qz_table" border="0">
<?php foreach($ds_qz_assignment_data as $ds_qz_data){ ?>
    <tr><td>
	<input type="hidden" name="ds_qz_assignment_id_hidden[]" id="ds_qz_assignment_id_hidden" value=" <?php echo $ds_qz_data->assignment_id; ?>" />
    <span id="ds_qz_assign_det" style="cursor:pointer" > <?php echo $ds_qz_data->quizz_name; ?> </span> <br/>
	</td></tr>
<?php }
  
  wp_die();
}
/////////////////////////////////////////////////////////////////////////////////////////////
add_action('wp_ajax_ds_qz_assignment_details','ds_qz_assignment_details');
function ds_qz_assignment_details(){
  $ds_qz_assignment_id=$_POST['ds_qz_assignment_id'];
  global $wpdb;
  $ds_qz_assign_det=$wpdb->get_row("select q.quizz_name,q.id as que_id,a.id 
  as assignment_id,a.pass_score,a.assigned_time from `".$wpdb->prefix."ds_qz_assignments` as a left join `".$wpdb->prefix."ds_qz_quizz` as q on a.quizz_id=q.id where a.id='$ds_qz_assignment_id' limit 1");
  
  $ds_qz_que_count=$wpdb->get_row("select count(*)as que_count from `".$wpdb->prefix."ds_qz_questions` where quiz_id='$ds_qz_assign_det->que_id'");
  ?>
 <script type="text/javascript" >
	jQuery(document).ready(function($) {
	  $("#ds_qz_start_btn").click( function() {
        var assignment_id=$("#ds_qz_assignment_id").val();
		var quiz_id=$("#ds_qz_quiz_id").val();
		var data = {
			'action': 'ds_qz_get_quiz_question',
			'ds_qz_assignment_id': assignment_id,
			'ds_qz_quiz_id': quiz_id,
			
		};

		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		$.post(ajaxurl, data, function(response) {
		$("#ds_qz_ajax_area").html(response);
			//alert('response : ' + response);
		});
       });
	});
	</script> 
  <table width="100%" border="1">
  <tr>
    <td>Quizz Name&nbsp;</td>
    <td><?php echo $ds_qz_assign_det->quizz_name; ?> &nbsp;</td>
  </tr>
  <tr>
    <td>Number Of Quizzes&nbsp;</td>
    <td><?php echo $ds_qz_que_count->que_count; ?> &nbsp;</td>
  </tr>
  <tr>
    <td>Pass Score&nbsp;</td>
    <td> <?php echo $ds_qz_assign_det->pass_score ; ?>&nbsp;</td>
  </tr>
  <tr>
    <td>Time Duration&nbsp;</td>
    <td> <?php echo $ds_qz_assign_det->assigned_time ; ?>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" align="center">
	<input type="hidden" name="ds_qz_quiz_id" id="ds_qz_quiz_id" value="<?php echo $ds_qz_assign_det->que_id; ?>" />
	<input type="hidden" name="ds_qz_assignment_id" id="ds_qz_assignment_id" value="<?php echo $ds_qz_assign_det->assignment_id; ?>" />
	<input type="button" name="ds_qz_start_btn" id="ds_qz_start_btn" value="Start Now" />
	
	</td>
    
  </tr>
</table>

  
  
<?php
  wp_die();
}
////////////////////////////////////////////////////////////////////////////////////////////
add_action('wp_ajax_ds_qz_get_quiz_question','ds_qz_get_quiz_question');
function ds_qz_get_quiz_question(){
  global $wpdb;
  $ds_qz_assignment_id=$_POST['ds_qz_assignment_id'];
  $ds_qz_quiz_id=$_POST['ds_qz_quiz_id'];
  $ds_qz_sql=$wpdb->get_row("select * from `".$wpdb->prefix."ds_qz_questions` where  
  quiz_id='$ds_qz_quiz_id' and id not in(select question_id from `".$wpdb->prefix.
  "ds_qz_user_answers` where user_id='".$_SESSION['user_id']."' and 
  user_quiz_id='$ds_qz_quiz_id' )");
  echo $wpdb->last_error;
  print_r($ds_qz_sql);
  
  

}

////////////////////////////////////////////////////////////////////////////////////////////

add_action( 'wp_ajax_ds_qz_quiz_name_exist_check','ds_qz_quiz_name_exist_check');
function ds_qz_quiz_name_exist_check(){
  global $wpdb;
  $ds_quiz_name=$_POST['ds_qz_quiz_name'];
  $ds_qz_data=$wpdb->get_var("select count(*) from `".$wpdb->prefix."ds_qz_quizz`
   where quizz_name='$ds_quiz_name' ");
   
   //echo $wpdb->last_query;
  echo $ds_qz_data;
 wp_die();
  

}

add_action('wp_ajax_ds_qz_get_quiz_cat_combo','get_quiz_cat_combo');

function get_quiz_cat_combo(){
   $ds_qz_quiz_cat=$_POST['ds_qz_quiz_cat'];
   $ds_qz_combo_name=$_POST['ds_qz_combo_name'];
   $ds_qz_combo_id=$_POST['ds_qz_combo_id'];
   global $wpdb;
   $ds_qz_result=$wpdb->get_results("select quizz_name,id from `".$wpdb->prefix."ds_qz_quizz` where category='$ds_qz_quiz_cat' order by quizz_name"); ?>
   <select name="<?php echo $ds_qz_combo_name; ?>" id="<?php echo $ds_qz_combo_id; ?>">
	    <option value="">Select Category</option>
<?php foreach($ds_qz_result as $ds_qz_data){?>
        <option value="<?php echo $ds_qz_data->id;?>"><?php echo $ds_qz_data->quizz_name;?>
		</option>
<?php } ?>
  </select>
<?php 
  wp_die(); 
}

 add_action( 'wp_ajax_ds_qz_get_answer_type_template','ds_qz_get_answer_type_template');
 function ds_qz_get_answer_type_template(){
    echo "xcsdfzcvx dcvxc";
   $answer_type=$_POST['answer_type'];
   if($answer_type=="2"){?>
     <table width="300" border="1">
  <tr>
    <td>Answers</td>
    <td>Correct</td>
  </tr>
  <tr>
    <td><label>
      <input type="text" name="answer[]">
    </label></td>
    <td><label>
      <input name="correct[]" type="checkbox" id="correct[]" value="0">
    </label></td>
  </tr>
  <tr>
    <td><input name="answer[]" type="text" id="answer[]"></td>
    <td><input name="correct[]" type="checkbox" id="correct[]" value="1"></td>
  </tr>
  <tr>
    <td><input name="answer[]" type="text" id="answer[]"></td>
    <td><input name="correct[]" type="checkbox" id="correct[]" value="2"></td>
  </tr>
  <tr>
    <td><input name="answer[]" type="text" id="answer[]"></td>
    <td><input name="correct[]" type="checkbox" id="correct[]" value="3"></td>
  </tr>
  <tr>
    <td><div align="right">
        <input name="" value="Add More" type="button">
    </div></td>
    <td>&nbsp;<input name="" value="Remove" type="button"></td>
  </tr>
</table>
   
   <?php 
   }
   if($answer_type=="1"){ ?>
   <table width="300" border="1">
  <tr>
    <td>Answers</td>
    <td>Correct</td>
  </tr>
  <tr>
    <td><label>
      <input name="answer[]" type="text" id="answer[]">
    </label></td>
    <td><label>
      <input name="correct[]" type="radio" value="">
    </label></td>
  </tr>
  <tr>
    <td><input name="answer[]" type="text" id="answer[]"></td>
    <td><input name="correct[]" type="radio" value=""></td>
  </tr>
  <tr>
    <td><input name="answer[]" type="text" id="answer[]"></td>
    <td><input name="correct[]" type="radio" value=""></td>
  </tr>
  <tr>
    <td><input name="answer[]" type="text" id="answer[]"></td>
    <td><input name="correct[]" type="radio" value=""></td>
  </tr>
  <tr>
    <td><div align="right">
      <input name="Input" value="Add More" type="button">
    </div></td>
    <td>&nbsp;
        <input name="Input" value="Remove" type="button"></td>
  </tr>
</table>
   <?php  
   }
   
   if($answer_type=="3"){?>
     <table width="300" border="1">
  <tr>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>enter Answer 
      <label>
      <textarea name="answer" id="answer"></textarea>
    </label></td>
  </tr>
</table>
   <?php
   }
   
   if($answer_type=="4"){?>
   <table width="300" border="1">
  <tr>
    <td>Answers</td>
    <td>Correct</td>
  </tr>
  <tr>
    <td><label>
      <input name="answer[]" type="text" id="answer[]">
    </label></td>
    <td><label>
    <input name="correct[]" type="text" id="correct[]">
    </label></td>
  </tr>
  <tr>
    <td><input name="answer[]" type="text" id="answer[]"></td>
    <td><input name="correct[]" type="text" id="correct[]"></td>
  </tr>
  <tr>
    <td><input name="answer[]" type="text" id="answer[]"></td>
    <td><input name="correct[]" type="text" id="correct[]"></td>
  </tr>
  <tr>
    <td><input name="answer[]" type="text" id="answer[]"></td>
    <td><input name="correct[]" type="text" id="correct[]"></td>
  </tr>
  <tr>
    <td><div align="right">
      <input name="Input2" value="Add More" type="button">
    </div></td>
    <td>&nbsp;
        <input name="Input2" value="Remove" type="button"></td>
  </tr>
</table>
   <?php
   }
   wp_die();
 }

 



?>
