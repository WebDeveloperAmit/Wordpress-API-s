
    
 


<?php

global $wpdb;

if($_SESSION['ds_qz_msg']!=""){
  add_action('shutdown','ds_unset_session_vars');
   function ds_unset_session_vars(){
     $_SESSION['ds_qz_msg']="";
	
   }
}
if(isset($_POST['ds_quiz_submit'])){
  $ds_qz_group_name=$_POST['ds_add_user_group_name'];
  
  $ds_qz_query=$wpdb->query("INSERT INTO `".$wpdb->prefix."ds_qz_user_groups` (`id`, `group_name`, `status`) VALUES ('', '$ds_qz_group_name', '')");
    //echo $wpdb->last_query;
  
  if($ds_qz_query){
    $_SESSION['ds_qz_msg']="User Group Added Successfully";
  }else{
    $_SESSION['ds_qz_msg']="Unable";
  }
  //header("location:");
  echo '<script>window.location.href=""</script>';
  

}

if(isset($_POST['ds_qz_user_group_del_btn'])){
  $ds_qz_user_group_id=$_POST['ds_qz_user_group_id'];
  $ds_qz_query=$wpdb->query("update `".$wpdb->prefix."ds_qz_user_groups` set
  status='1' where id='$ds_qz_user_group_id' limit 1");
if($ds_qz_query){
    $_SESSION['ds_qz_msg']="User Group Deactivate Successfully";
  }else{
    $_SESSION['ds_qz_msg']="Unable to Deactivate ";
  }
  //header("location:");
  echo '<script>window.location.href=""</script>';
  

}

if(isset($_POST['ds_qz_user_group_update_btn'])){

  $ds_qz_user_group_update_id=$_POST['ds_qz_user_group_update_id'];
  $ds_qz_user_group_update_input=$_POST['ds_qz_user_group_update_input'];
  
  $ds_qz_query=$wpdb->query("update `".$wpdb->prefix."ds_qz_user_groups` set
  group_name='$ds_qz_user_group_update_input' where id='$ds_qz_user_group_update_id'");
  
  if($ds_qz_query){
    $_SESSION['ds_qz_msg']="Data Updated Successfully";
  }else{
    $_SESSION['ds_qz_msg']="Unable to Update ";
  }
  //header("location:");
  echo '<script>window.location.href=""</script>';
 

}



?>
<form action="" method="post">
<input name="ds_add_user_group_name" type="text">
<input type="submit" name="ds_quiz_submit" value="Add New Group"/>
</form>
<?php echo $_SESSION['ds_qz_msg']; ?>
<table width="100%" border="1">
  <tr>
    <td>id</td>
    <td> name </td>
    <td>edit</td>
    <td>Deactive</td>
    <td class="delete">Delete</td>
  </tr>
  <?php
   global $wpdb;
   $ds_query243="select * from `".$wpdb->prefix."ds_qz_user_groups` 
   where status='0' ";
   //if(!$ds_query) {echo "dasdasd";}
   $ds_data=$wpdb->get_results($ds_query243);
   //echo $wpdb->last_query;
   foreach($ds_data as $ds_list){ 
   ?>
  <tr>
    <td>&nbsp;</td>
    <td><?php echo $ds_list->group_name; ?>&nbsp;</td>
    <td><a class="button" href="#openModal=<?php echo $ds_list->id; ?>">Edit</a></td>
 <form action="" method="post">    
  <div id="openModal=<?php echo $ds_list->id; ?>" class="modalbg">
  <div class="dialog">
  <a href="#close" title="Close" class="close">X</a>
 <h3>Update Your Data</h3>
  <input name="ds_qz_user_group_update_input" type="text" value="<?php echo $ds_list->group_name; ?>">
  <input type="hidden" name="ds_qz_user_group_update_id" value="<?php echo $ds_list->id; ?>" />
  <input name="ds_qz_user_group_update_btn" type="submit" value="Update" />
 
  </div>
  </div>
   </form>
    
    
    <td>
	 <form action="" method="post">
	  <input type="hidden" name="ds_qz_user_group_id" 
	  value="<?php echo $ds_list->id; ?>" />
      <input type="submit" name="ds_qz_user_group_del_btn" value="Deactive" />
	 </form>
    </td>
    
    

    
    
    
	
    
    <td>
    

       <script type="text/javascript">
			$(document).ready(function() {
				// Basic confirmation
				$(".link").popConfirm();
				
				// Custom Title, Content and Placement
				$(".button1").popConfirm({
					title: "Really You delete it?",
					
					placement: "bottom"
				});
			});
		</script>
    
    
    <a href="?delete=<?php echo $ds_list->id; ?>" class="button1">Delete</a>
    
    
        
                <script type="text/javascript">
(function ($) {
  'use strict';
  /*global jQuery, $*/
  /*jslint nomen: true, evil: true*/
  $.fn.extend({
    popConfirm: function (options) {
      var defaults = {
          title: 'Confirmation',
          content: '',
          placement: 'right',
          container: 'body',
          yesBtn: 'Yes',
          noBtn: 'No'
        },
        last = null;
      options = $.extend(defaults, options);
      return this.each(function () {
        var self = $(this),
          arrayActions = [],
          arrayDelegatedActions = [],
          eventToConfirm,
          optName,
          optValue,
          i,
          elmType,
          code,
          form;

        // Load data-* attriutes
        for (optName in options) {
          if (options.hasOwnProperty(optName)) {
            optValue = $(this).attr('data-confirm-' + optName);
            if (optValue) {
              options[optName] = optValue;
            }
          }
        }

        // If there are jquery click events
        if (jQuery._data(this, "events") && jQuery._data(this, "events").click) {

          // Save all click handlers
          for (i = 0; i < jQuery._data(this, "events").click.length; i = i + 1) {
            arrayActions.push(jQuery._data(this, "events").click[i].handler);
          }

          // unbind it to prevent it firing
          $(self).unbind("click");
        }

        // If there are jquery delegated click events
        if (self.data('remote') && jQuery._data(document, "events") && jQuery._data(document, "events").click) {

          // Save all delegated click handlers that apply
          for (i = 0; i < jQuery._data(document, "events").click.length; i = i + 1) {
            elmType = self[0].tagName.toLowerCase();
            if (jQuery._data(document, "events").click[i].selector && jQuery._data(document, "events").click[i].selector.indexOf(elmType + "[data-remote]") !== -1) {
              arrayDelegatedActions.push(jQuery._data(document, "events").click[i].handler);
            }
          }
        }

        // If there are hard onclick attribute
        if (self.attr('onclick')) {
          // Extracting the onclick code to evaluate and bring it into a closure
          code = self.attr('onclick');
          arrayActions.push(function () {
            eval(code);
          });
          $(self).prop("onclick", null);
        }

        // If there are href link defined
        if (!self.data('remote') && self.attr('href')) {
          // Assume there is a href attribute to redirect to
          arrayActions.push(function () {
            window.location.href = self.attr('href');
          });
        }

        // If the button is a submit one
        if (self.attr('type') && self.attr('type') === 'submit') {
          // Get the form related to this button then store submiting in closure
          form = $(this).parents('form:first');
          arrayActions.push(function () {
            form.submit();
          });
        }

        self.popover({
          trigger: 'manual',
          title: options.title,
          html: true,
          placement: options.placement,
          container: options.container,
          //Avoid using multiline strings, nno support in older browsers.
		  
          content: options.content + '<input type="submit" class="button1" value="<?php echo $ds_list->id; ?>"> <input type="submit" id="button" value="Cancle">'
		  
		 
		  
		  
        }).click(function (e) {
          if (last && last !== self) {
            last.popover('hide').removeClass('popconfirm-active');
          }
          last = self;
        });

        $(document).on('click', function () {
          if (last) {
            last.popover('hide').removeClass('popconfirm-active');
          }
        });

        self.bind('click', function (e) {
          eventToConfirm = e;

          e.preventDefault();
          e.stopPropagation();

          $('.popconfirm-active').not(self).popover('hide').removeClass('popconfirm-active');
          self.popover('show').addClass('popconfirm-active');

          $(document).find('.popover .confirm-dialog-btn-confirm').bind('click', function (e) {
            for (i = 0; i < arrayActions.length; i = i + 1) {
              arrayActions[i].apply(self);
            }

            for (i = 0; i < arrayDelegatedActions.length; i = i + 1) {
              arrayDelegatedActions[i].apply(self, [eventToConfirm.originalEvent]);
            }

            self.popover('hide').removeClass('popconfirm-active');
          });
          $(document).find('.popover .confirm-dialog-btn-abord').bind('click', function (e) {
            self.popover('hide').removeClass('popconfirm-active');
          });
        });
      });
    }
  });
}(jQuery));

        
        
        
        </script>

    
    
    
    
    </td>
</form>
    
  </tr>
  <?php
   } 
   ?>
   
</table>
<br /><br />
<table width="500" border="0" cellspacing="0" cellpadding="0">
  <tr>
  
<?php
global $wpdb;
if(isset($_POST['ds_quiz_group_activate_submit'])){
  $ds_qz_user_deactiv_group_id=$_POST['ds_qz_user_deactiv_group_id'];
  
$ds_qz_query=$wpdb->query("update `".$wpdb->prefix."ds_qz_user_groups` set
  status='0' where id='$ds_qz_user_deactiv_group_id' limit 1");

if($ds_qz_query){
    $_SESSION['ds_qz_msg2']="User Group Activate Successfully";
  }else{
    $_SESSION['ds_qz_msg2']="Unable to Activate";
  }


echo '<script>window.location.href=""</script>';
  
}else{
   add_action('shutdown','ds_unset_session_vars2');
   function ds_unset_session_vars2(){
    
	 $_SESSION['ds_qz_msg2']="";
}
}  
  
?>  
  
  
  
  
  
 <td><form action="" method="post">
    
<select name="ds_qz_user_deactiv_group_id">

<option value="">select group</option>
<?php
global $wpdb;
$ds_deactive_user_group="select * from ".$wpdb->prefix."ds_qz_user_groups where status='1'";
$ds_retrive_deactive_group=$wpdb->get_results($ds_deactive_user_group);
foreach($ds_retrive_deactive_group as $deactive_group)
{
?> 
<option value="<?php echo $deactive_group->id; ?>"><?php echo $deactive_group->group_name;  ?></option> 

<?php
}
?>
</select>

<input type="submit" name="ds_quiz_group_activate_submit" value="Activate"/>
</form></td>
  </tr>
</table>


