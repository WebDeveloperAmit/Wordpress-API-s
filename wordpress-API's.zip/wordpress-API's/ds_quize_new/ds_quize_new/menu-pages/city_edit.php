<?php
global $wpdb;
if(isset($_POST['ds_qz_submit'])){



  $cat=$_POST['cat'];

  $country_id=$_POST['country'];

  $id=$_POST['id'];



  $ds_qz_sql=$wpdb->query("update tm_city set city_name='$cat', country_id='$country_id' where id='$id'");
  //echo $wpdb->last_error; exit();
  if($ds_qz_sql){
  $_SESSION['ds_qz_msg']="New User Added Successfuly";
    echo "success";
  }else{
    $_SESSION['ds_qz_msg']="Unable";
  echo "unable";
  }
  //header("location:");
  echo '<script>window.location.href=""</script>';

}else{
   add_action('shutdown','ds_unset_session_vars');
   function ds_unset_session_vars(){
     $_SESSION['ds_qz_msg']="";
   
   }
}





?>

<style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
</style>

<div>


<?php

$id = $_GET['id'];

global $wpdb;

$thepost = $wpdb->get_row( $wpdb->prepare( "select s.*,c.country_name from tm_city as s left join tm_country as c on(s.country_id=c.id) where s.id = $id" ) );


?>

  <h1 style="text-align: center;">City</h1>
<a style="color:#000;" href="<?php echo admin_url(); ?>admin.php?page=ds-quiz-city-add">City List</a>
<form style="margin-top: 50px;" method='post' action='' name='myform' enctype='multipart/form-data'>

<select style="padding: 12px 12px;border-radius: 0px;margin-bottom: 10px;background: #fff;color: #000;border:1px solid #eee;font-size: 14px;height: 50px!important;width: 100%;" name="country">

<option value="">Select Country</option>
  <?php
  $ds_query243="select * from tm_country";

   //if(!$ds_query) {echo "dasdasd";}
   $ds_data=$wpdb->get_results($ds_query243);
   //echo $wpdb->last_query;
   $ds_qz_count=0;
   foreach($ds_data as $ds_list){ $ds_qz_count++;
  ?>
<option <?php if($thepost->country_id==$ds_list->id){echo 'selected';} ?> value="<?php echo $ds_list->id;?>"><?php echo $ds_list->country_name;?></option>
 <?php
  }
  ?>
</select>


<input type="text" placeholder="Country" style="padding: 12px 12px;border-radius: 0px;margin-bottom: 10px;background: #fff;color: #000;border:1px solid #eee;font-size: 14px;height: 50px!important;width: 100%;" name="cat" value="<?php echo $thepost->city_name; ?>">

<input type="hidden" value="<?php echo $thepost->id; ?>" name="id">


<br>

<button name="ds_qz_submit" type="submit" style="padding: 12px 32px;border-radius: 0px;background: #000;color: #fff;font-size: 14px;height: 50px!important;">Update Now</button>



</form>

</div>

