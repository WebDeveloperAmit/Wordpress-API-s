<style type="text/css">
  .pagination li { display: inline-block; }
</style>
<?php
global $wpdb;
if(isset($_POST['ds_qz_submit'])){
  $ds_qz_name=$_POST['ds_qz_name'];
  $ds_qz_user_name=$_POST['ds_qz_user_name'];
  $ds_qz_pass=md5($_POST['ds_qz_pass']);
  $ds_qz_email=$_POST['ds_qz_email'];
  $ds_qz_phone=$_POST['ds_qz_phone'];
  $ds_qz_user_group=$_POST['ds_qz_user_group'];
  $ds_qz_user_type="0";
  
  $ds_qz_sql=$wpdb->query("INSERT INTO `".$wpdb->prefix."ds_qz_users` (`user_id`, `user_name`, `password`, `name`, `added_time`, `user_type`,`user_group`, `email`, `phone_no`, `status`) VALUES (NULL, '$ds_qz_user_name', '$ds_qz_pass', '$ds_qz_name', NOW(), '$ds_qz_user_type','$ds_qz_user_group', '$ds_qz_email', '$ds_qz_phone', '')");
  //echo $wpdb->last_error; exit();
  if($ds_qz_sql){
  $_SESSION['ds_qz_msg']="New User Added Successfuly";
    echo "success";
  }else{
    $_SESSION['ds_qz_msg']="Unable";
	echo "unable";
  }
  //header("location:");
  echo '<script>window.location.href=""</script>';

}else{
   add_action('shutdown','ds_unset_session_vars');
   function ds_unset_session_vars(){
     $_SESSION['ds_qz_msg']="";
   
   }
}
?>



<!-- <table width="100%" border="1">
  <tr>
    <td>sl no </td>
    <td>Word</td>
    <td>Meaning One</td>

    <td>Meaning Two</td>
    <td>Meaning Three</td>

    <td>Meaning Four</td>
  </tr>
  <?php
  $ds_query243="select * from ".$wpdb->prefix."tbl_questions LIMIT 30";
   //if(!$ds_query) {echo "dasdasd";}
   $ds_data=$wpdb->get_results($ds_query243);
   //echo $wpdb->last_query;
   $ds_qz_count=0;
   foreach($ds_data as $ds_list){ $ds_qz_count++;
  ?>
  <tr>
    <td><?php echo $ds_qz_count; ?>&nbsp;</td>
    <td><?php echo $ds_list->word_name;?>&nbsp;</td>
    <td><?php echo $ds_list->meaning_one;?>&nbsp;</td>

    <td><?php echo $ds_list->meaning_two;?>&nbsp;</td>
    <td><?php echo $ds_list->meaning_three;?>&nbsp;</td>
    <td><?php echo $ds_list->meaning_four;?>&nbsp;</td>
  </tr>
  <?php
  }
  ?>
</table> -->


<?php 

    $start = 0;  $per_page = 50;
    $page_counter = 0;
    $next = $page_counter + 1;
    $previous = $page_counter - 1;
    
    if(isset($_GET['start'])){
     $start = $_GET['start'];
     $page_counter =  $_GET['start'];
     $start = $start *  $per_page;
     $next = $page_counter + 1;
     $previous = $page_counter - 1;
    }
    // query to get messages from messages table
    $ds_query243 = "select * from ".$wpdb->prefix."tbl_questions  LIMIT $start, $per_page";

    $ds_data1=$wpdb->get_results($ds_query243);

    // count total number of rows in students table
    // $count_query = "SELECT * FROM students";
    // $query = $db->prepare($count_query);
    // $query->execute();
    // $count = $query->rowCount();
    // calculate the pagination number by dividing total number of rows with per page.

$wpdb->get_results("SELECT * FROM ".$wpdb->prefix."tbl_questions "); 

 $count = $wpdb->num_rows;


    $paginations = ceil($count / $per_page);

    echo $page_counter;
?>



<table class="table table-striped" class="table table-hover">
                <thead class="table-info">
                 <th scope="col" class="bg-primary" >sl no</th>
                 <th scope="col" class="bg-primary">Word</th>
                 <th scope="col" class="bg-primary">Meaning One</th>
                 <th scope="col" class="bg-primary">Meaning Two</th>
<th scope="col" class="bg-primary">Meaning Four</th>
                </thead>
                <tbody>
                <?php 
                $ds_qz_count=0;
                    foreach($ds_data1 as $data) {
                      $ds_qz_count++;
                     ?>
                     <tr>
    <td><?php echo $ds_qz_count; ?>&nbsp;</td>
    <td><?php echo $data->word_name;?>&nbsp;</td>
    <td><?php echo $data->meaning_one;?>&nbsp;</td>

    <td><?php echo $data->meaning_two;?>&nbsp;</td>
    <td><?php echo $data->meaning_three;?>&nbsp;</td>
    <td><?php echo $data->meaning_four;?>&nbsp;</td>
  </tr>
                    <?php }

                 ?>
                </tbody>
            </table>
            <center>
            <ul class="pagination">
            <?php
                if($page_counter == 0){
                    echo "<li><a href=?page=ds-quiz-words&start='0' class='active'>0</a></li>";
                    for($j=1; $j < $paginations; $j++) { 
                      echo "<li><a href=?page=ds-quiz-words&start=$j>".$j."</a></li>";
                   }
                }else{
                    echo "<li><a href=?page=ds-quiz-words&start=$previous>Previous</a></li>"; 
                    for($j=0; $j < $paginations; $j++) {
                     if($j == $page_counter) {
                        echo "<li><a href=?page=ds-quiz-words&start=$j class='active'>".$j."</a></li>";
                     }else{
                        echo "<li><a href=?page=ds-quiz-words&start=$j>".$j."</a></li>";
                     } 
                  }if($j != $page_counter+1)
                    echo "<li><a href=?page=ds-quiz-words&start=$next>Next</a></li>"; 
                } 
            ?>
            </ul>
            </center>