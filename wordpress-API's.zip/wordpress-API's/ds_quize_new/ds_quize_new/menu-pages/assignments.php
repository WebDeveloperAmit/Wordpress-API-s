<?php
global $wpdb;
if(isset($_POST['ds_qz_submit'])){
  $ds_qz_quiz=$_POST['ds_qz_quiz'];
  //echo "ddd :".$ds_qz_quiz; exit();
  $ds_qz_user_group=$_POST['ds_qz_user_group'];
  $ds_qz_percentage=$_POST['ds_qz_percentage'];
  $ds_qz_assigned_time=$_POST['ds_qz_assigned_time'];
  $ds_qz_hint=$_POST['ds_qz_hint'];
  
  $ds_qz_sql=$wpdb->query("INSERT INTO `".$wpdb->prefix."ds_qz_assignments` (`id`, `quizz_id`, `show_result`, `review`, `added_time`, `pass_score`, `assignment_type`,`user_group`, `status`,`assigned_time`,`hint`) VALUES (NULL, '$ds_qz_quiz', '1', '1', NOW(), '$ds_qz_percentage', '1','$ds_qz_user_group', '','$ds_qz_assigned_time','$ds_qz_hint')");
  //echo $wpdb->last_error; exit();
  if($ds_qz_sql){
  $_SESSION['ds_qz_msg']="New Assignment Added Successfuly";
    echo "success";
  }else{
    $_SESSION['ds_qz_msg']="Unable";
	echo "unable";
  }
  //header("location:");
  echo '<script>window.location.href=""</script>';

}else{
   add_action('shutdown','ds_unset_session_vars');
   function ds_unset_session_vars(){
     $_SESSION['ds_qz_msg']="";
   
   }
}
?>

<script type="text/javascript" >
	jQuery(document).ready(function($) {
	  $("#ds_qz_quiz_cat").change( function() {
        var ds_qz_quiz_cat=$("#ds_qz_quiz_cat").val();
		var data = {
			'action': 'ds_qz_get_quiz_cat_combo',
			'ds_x': 2,
			'ds_qz_quiz_cat': ds_qz_quiz_cat,
			'ds_qz_combo_name': 'ds_qz_quiz',
			'ds_qz_combo_id': 'ds_qz_quiz',	
		};

		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		$.post(ajaxurl, data, function(response) {
		$("#ds_qz_ajax_response").html(response);
			//alert('response : ' + response);
		});
       });
	});
	</script> 

<form action="" method="post"> 
<table width="100%" border="1">
  <tr>
    <td colspan="3" align="center">Add New Assignment </td>
  </tr>
  <tr>
    <td width="42%">Quiz Category
      <label>
      <select name="ds_qz_quiz_cat" id="ds_qz_quiz_cat">
        <option value="">Select Category</option>
        <?php  $ds_qz_data=$wpdb->get_results("SELECT * FROM 
		`".$wpdb->prefix."ds_qz_quizz_category` ");
		 foreach($ds_qz_data as $ds_qz_data){
		  ?>
        <option value="<?php echo $ds_qz_data->id;?>"><?php echo $ds_qz_data->name; ?></option>
        <?php
		 }
		 ?>
      </select>
      </label></td>
    <td width="25%" id="ds_qz_ajax_response">Quiz 
      <select name="ds_qz_quiz" id="ds_qz_quiz"></select></td>
    <td width="33%">User Group 
      <select name="ds_qz_user_group">
	    <option selected="selected" value="">Select Group</option>
	   <?php global $wpdb;
	     $ds_qz_data="select id,group_name from `".$wpdb->prefix."ds_qz_user_groups` where
		 status=0";
		 $ds_qz_group_list=$wpdb->get_results($ds_qz_data);
		 //echo $wpdb->last_query;
		
		 foreach($ds_qz_group_list as $ds_qz_data){
	   ?>
	    <option value="<?php echo $ds_qz_data->id; ?>"><?php echo $ds_qz_data->group_name; ?>
		</option>
		<?php
		}
		?>
      </select>
	  
	  </td>
  </tr>
  <tr>
    <td>Pass Marks (Percentage) 
      <input name="ds_qz_percentage" type="text" id="ds_qz_percentage" /></td>
    <td>Assigned Time 
      <input name="ds_qz_assigned_time" type="text" id="ds_qz_assigned_time" /></td>
    <td><label>Hint
        <select name="ds_qz_hint" id="ds_qz_hint">
		  <option value="">Select</option>
		  <option value="0">Off</option>
		  <option value="1">On</option>
        </select>
    </label></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><label>
   <input name="ds_qz_submit" type="submit" id="ds_qz_submit" value="Submit">
   <?php echo $_SESSION['ds_qz_msg']; ?> </label></td>
  </tr>
</table>

</form>

<table width="100%" border="1">
  <tr>
    <td>sl no </td>
    <td>Quiz</td>
    <td>User Group </td>
    <td>&nbsp;</td>
	<td>Pass Percentage </td>
    <td>Time Assigned </td>
    <td>&nbsp;</td>
  </tr>
  <?php
  $ds_query243="select date_format(a.added_time,'%d/%m/%Y') as entry_date,u.group_name,q.quizz_name,a.assigned_time,a.pass_score from `".$wpdb->prefix."ds_qz_assignments`
   as a left join `".$wpdb->prefix."ds_qz_quizz` as q on a.quizz_id=q.id  left join `".$wpdb->prefix."ds_qz_user_groups` as u 
    on   a.user_group=u.id  where a.status=0 order by a.id ";
	//$ds_query="select ug.group_name,a.user_group from  `""`"
   //if(!$ds_query) {echo "dasdasd";}
   $ds_data=$wpdb->get_results($ds_query243);
   //echo $wpdb->last_error;
   //print_r($ds_data);
   $ds_qz_count=0;
   foreach($ds_data as $ds_list){ $ds_qz_count++;
  ?>
  <tr>
    <td><?php echo $ds_qz_count; ?>&nbsp;</td>
    <td><?php echo $ds_list->quizz_name;?>&nbsp;</td>
    <td><?php echo $ds_list->group_name;?>&nbsp;</td>
    <td><?php echo $ds_list->entry_date;?>&nbsp;</td>
	<td><?php echo $ds_list->pass_score;?></td>
    <td><?php echo $ds_list->assigned_time;?></td>
    <td>&nbsp;</td>
  </tr>
  <?php
  }
  ?>
</table>


