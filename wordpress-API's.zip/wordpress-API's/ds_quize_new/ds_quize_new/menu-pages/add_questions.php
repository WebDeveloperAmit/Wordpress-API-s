<script type="text/javascript">
  jQuery(document).ready(function($) {
    $("#answer_type").change(function(){
	   var answer_type=$("#answer_type").val();
	     alert(answer_type);
		var data = {
			'action': 'ds_qz_get_answer_type_template',
			'answer_type': answer_type,
			
		};
		$.post(ajaxurl, data, function(response) {
		  $("#answer_type_holder").html(response);
		});
	});
  });

</script>

<?php if(isset($_POST['ds_qz_que_submit_btn'])){
  $quiz_id=$_POST['quiz_id'];
  $question=$_POST['question'];
  $header_text=$_POST['header_text'];
  $footer_text=$_POST['footer_text'];
  $answer_type=$_POST['answer_type'];
  $answer=$_POST['answer'];
  $correct=$_POST['correct'];
  //print_r($correct);
  //exit();
  
  global $wpdb;
  //echo " answer :".$answer; exit(); 
  
 /* echo "<pre>";
  print_r($answer);
  print_r($correct);
  exit();*/
  $hint=$_POST['hint'];
  $points=$_POST['points'];
  
    $ds_qz_que_sql="INSERT INTO `".$wpdb->prefix."ds_qz_questions` (`id`, `question_data`, `question_type`, `points`, `created_time`, `created_by`, `header_text`, `footer_text`, `hint`,`quiz_id`, `status`) VALUES (NULL, '$question', '$answer_type', '$points', NOW(), '', '$header_text', '$footer_text', '$hint','$quiz_id', '')";
	$ds_qz_que_sql=$wpdb->query($ds_qz_que_sql);
	$question_id=$wpdb->insert_id;
	if($answer_type=="1" || $answer_type=="2"){
	  for($ds_qz_counter=0;$ds_qz_counter<sizeof($answer); $ds_qz_counter++){
	    if(in_array($ds_qz_counter,$correct)) { 
		  $is_correct=1;
	    }else{
		  $is_correct=0;
		}
	    $ds_qz_answer_sql="INSERT INTO `".$wpdb->prefix."ds_qz_answers` (`id`, `answer_data`, `correct`, `correct_answer_text`, `points`, `answer_desc`, `question_id`, `status`)
		 VALUES (NULL, '".$answer[$ds_qz_counter]."', '$is_correct', '', '', '', '$question_id', '')";
		$ds_qz_answer_sql=$wpdb->query($ds_qz_answer_sql); 
	  }
	}
	
	
	if($answer_type=="3"){
	  $ds_qz_answer_sql="INSERT INTO `".$wpdb->prefix."ds_qz_answers` (`id`, `answer_data`, `correct`, `correct_answer_text`, `points`, `answer_desc`, `question_id`, `status`)
		 VALUES (NULL, '', '', '$answer', '', '', '$question_id', '')";
	  $ds_qz_answer_sql=$wpdb->query($ds_qz_answer_sql); 
	}
	
	if($answer_type=="4"){
	   for($ds_qz_counter=0;$ds_qz_counter<sizeof($answer); $ds_qz_counter++){
	     $ds_qz_answer_sql="INSERT INTO `".$wpdb->prefix."ds_qz_answers` (`id`, `answer_data`, `correct`, `correct_answer_text`, `points`, `answer_desc`, `question_id`, `status`)
		 VALUES (NULL, '".$answer[$ds_qz_counter]."', '1', '".$correct[$ds_qz_counter]."', '', '', '$question_id', '')";
		$ds_qz_answer_sql=$wpdb->query($ds_qz_answer_sql); 
	   
	   }
	}
	
	
	
	
	if($ds_qz_que_sql) {
	  echo "question added successfully";
	}

}?>

<form action="" method="post">
<table width="800" border="1">
  <tr>
    <td width="77">question</td>
    <td width="707"><label>
      <textarea name="question" id="question"></textarea>
    </label></td>
  </tr>
  <tr>
    <td>point</td>
    <td><label>
      <input name="points" type="text" id="points" />
    </label></td>
  </tr>
  <tr>
    <td>Header Text </td>
    <td><input name="header_text" type="text" id="header_text" /></td>
  </tr>
  <tr>
    <td>Footer Text </td>
    <td><input name="footer_text" type="text" id="footer_text" /></td>
  </tr>
  <tr>
    <td>Select Answer Type </td>
    <td><label>
      <select name="answer_type" id="answer_type">
	     <option value="">Select Answer Type</option>
		 <?php global $wpdb; ?>
		 <?php $ds_qz_data=$wpdb->get_results("select * from 
		 `".$wpdb->prefix."ds_qz_question_type`");
		 foreach($ds_qz_data as $qz_data){?>
	     <option value="<?php echo $qz_data->id; ?>"><?php echo $qz_data->que_type_name; ?></option>
		 <?php 
		 }
		 ?>
      </select>
    </label></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td id="answer_type_holder">&nbsp;</td>
  </tr>
  <tr>
    <td>Hint</td>
    <td><input name="hint" type="text" id="hint" /></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>
      <input type="submit" name="ds_qz_que_submit_btn" value="Submit" />
      <input type="reset" name="reset" value="Reset" /> <input type="text" name="quiz_id" value="<?php echo $_GET['quiz_id'];?>" />   </td>
  </tr>
</table>
</form>


