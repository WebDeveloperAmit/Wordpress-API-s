<?php
global $wpdb;
if(isset($_POST['ds_qz_submit'])){

$id=$_POST['id'];

  $title=$_POST['title'];
  $tm_country=$_POST['tm_country'];
  //$tm_state=$_POST['tm_state'];
  $tm_city=$_POST['tm_city'];
  $category=$_POST['category'];
  $gender_type=$_POST['gender_type'];
  $distribution=$_POST['distribution'];

  $short_desc = $_POST['short_desc'];

  $facilities = $_POST['facilities'];
  $address = $_POST['address'];


  if($_FILES['file']['name'] != ''){
    $uploadedfile = $_FILES['file'];
        $upload_overrides = array( 'test_form' => false );

        $movefile = wp_handle_upload( $uploadedfile, $upload_overrides );
        $imageurl = "";
        if ( $movefile && ! isset( $movefile['error'] ) ) {
            $imageurl  = $movefile['url'];
            echo "url : ".$imageurl;
        } else {
            echo $movefile['error'];
        }
    $photo=$imageurl;    
  }else{
   $photo=$_POST['photo'];
  }

  

  $ds_qz_sql=$wpdb->query("UPDATE sports SET title='$title',tm_country='$tm_country',tm_city='$tm_city',category='$category',content='$distribution',photo='$photo',short_content='$short_desc',facilities='$facilities',address='$address',gender_type='$gender_type' WHERE id='$id' ");
  //echo $wpdb->last_error; exit();
  if($ds_qz_sql){
  $_SESSION['ds_qz_msg']="Updated Successfuly";
    echo "success";
  }else{
    $_SESSION['ds_qz_msg']="Unable";
	echo "unable";
  }
  //header("location:");
  echo '<script>window.location.href=""</script>';

}else{
   add_action('shutdown','ds_unset_session_vars');
   function ds_unset_session_vars(){
     $_SESSION['ds_qz_msg']="";
   
   }
}
?>

<?php
$id = $_GET['id'];
global $wpdb;
$thepost = $wpdb->get_row( $wpdb->prepare( "select s.*,c.countryname,st.state_name,ct.name from sports as s left join country as c on(s.tm_country=c.id) left join state as st on(tm_state=st.sid) left join cities as ct on(s.tm_city=ct.cid) where s.id = $id" ) );
?>

<style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
</style>

<div>
<h1 style="text-align: center;">Sports Edit</h1>
<form style="margin-top: 50px;" method='post' action='' name='myform' enctype='multipart/form-data'>
  <input type="hidden" name="photo" value="<?php echo $thepost->photo ?>">
  <input type="hidden" name="id" value="<?php echo $thepost->id ?>">
<input type="text" placeholder="Name" style="padding: 12px 12px;border-radius: 0px;margin-bottom: 10px;background: #fff;color: #000;border:1px solid #eee;font-size: 14px;height: 50px!important;width: 100%;" name="title" value="<?php echo $thepost->title; ?>">
<?php
$country_id = $thepost->tm_country;
?>
<select style="padding: 12px 12px;border-radius: 0px;margin-bottom: 10px;background: #fff;color: #000;border:1px solid #eee;font-size: 14px;height: 50px!important;width: 100%; max-width: 100%;" id="ds_qz_name" name="tm_country">
<option value="">Select Country</option>
  <?php
  $ds_query243="select * from tm_country";
   //if(!$ds_query) {echo "dasdasd";}
   $ds_data=$wpdb->get_results($ds_query243);
   //echo $wpdb->last_query;
   $ds_qz_count=0;
   foreach($ds_data as $ds_list){ $ds_qz_count++;
  ?>
<option <?php if($country_id==$ds_list->id){echo "selected";} ?> value="<?php echo $ds_list->id;?>"><?php echo $ds_list->country_name;?></option>
<?php } ?>
</select>

<?php

?>



<select style="padding: 12px 12px;border-radius: 0px;margin-bottom: 10px;background: #fff;color: #000;border:1px solid #eee;font-size: 14px;height: 50px!important;width: 100%; max-width: 100%;" name="tm_city" id="ajax_key1">
<option value="">Select City</option>

</select>

<input type="text" placeholder="Location" style="padding: 12px 12px;border-radius: 0px;margin-bottom: 10px;background: #fff;color: #000;border:1px solid #eee;font-size: 14px;height: 50px!important;width: 100%;" name="address" value="<?php echo $thepost->address; ?>">

<?php
$category = $thepost->category;
?>
<select style="padding: 12px 12px;border-radius: 0px;margin-bottom: 10px;background: #fff;color: #000;border:1px solid #eee;font-size: 14px;height: 50px!important;width: 100%; max-width: 100%;" name="category" id="">
<option value="">Select Category</option>
<?php
  $ds_query243="select * from sports_cat";
   //if(!$ds_query) {echo "dasdasd";}
   $ds_data=$wpdb->get_results($ds_query243);
   //echo $wpdb->last_query;
   $ds_qz_count=0;
   foreach($ds_data as $ds_list){ $ds_qz_count++;
  ?>
<option <?php if($category==$ds_list->id){echo "selected";} ?> value="<?php echo $ds_list->id;?>"><?php echo $ds_list->cat_name;?></option>
<?php } ?>
</select>
<?php
$gender_type = $thepost->gender_type;
?>
<select style="padding: 12px 12px;border-radius: 0px;margin-bottom: 10px;background: #fff;color: #000;border:1px solid #eee;font-size: 14px;height: 50px!important;width: 100%; max-width: 100%;" name="gender_type" id="">
<option value="">Select Type</option>

<option <?php if($gender_type=='Men'){echo "selected";} ?> value="Men">Men</option>

<option <?php if($gender_type=='Women'){echo "selected";} ?> value="Women">Women</option>

<option <?php if($gender_type=='Children'){echo "selected";} ?> value="Women">Children</option>

</select>


<!-- <textarea type="text"  placeholder="Message" style="padding: 12px 12px;border-radius: 0px;margin-bottom: 15px;background: #fff;color: #000;border:1px solid #eee;font-size: 14px;height: 150px!important;width: 100%;"></textarea> -->

<input type="text" placeholder="Extra Facilities" style="padding: 12px 12px;border-radius: 0px;margin-bottom: 10px;background: #fff;color: #000;border:1px solid #eee;font-size: 14px;height: 50px!important;width: 100%;" name="facilities" value="<?php echo $thepost->facilities; ?>" required>

<input type="text" placeholder="Short Description" style="padding: 12px 12px;border-radius: 0px;margin-bottom: 10px;background: #fff;color: #000;border:1px solid #eee;font-size: 14px;height: 50px!important;width: 100%;" name="short_desc" maxlength="78" required value="<?php echo $thepost->short_content; ?>">

<?php 
$distribution = $thepost->content;
wp_editor( $distribution, 'distribution', array( 'theme_advanced_buttons1' => 'bold, italic, ul, pH, pH_min', "media_buttons" => false, "textarea_rows" => 8, "tabindex" => 4 ) );
 ?>


<br>

<input type="file" style="width: 100%;margin-bottom: 10px;" name="file">

<img style="width: 300px; height: auto;" src="<?php echo $thepost->photo; ?>">
<br>
<button name="ds_qz_submit" type="submit" style="padding: 12px 32px;border-radius: 0px;background: #000;color: #fff;font-size: 14px;height: 50px!important;">Update Now</button>



</form>

</div>
<script type="text/javascript">

jQuery(document).ready(function($) {

var ds_qz_name=$("#ds_qz_name").val();

var r_city=<?php echo $thepost->tm_city; ?>;

//alert(ds_qz_name);

var data = {

'action': 'tm_get_city',

'country': ds_qz_name,

'tm_city': r_city,

};


// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php

$.post(ajaxurl, data, function(response) {

if(response>0){

$("#ajax_key1").html("Same Name Allready Exist.. Please Use Another Name");

}

$("#ajax_key1").html(response);

//alert('response : ' + response);

});




$("#ds_qz_name").change( function() {

var ds_qz_name=$("#ds_qz_name").val();

//alert(ds_qz_name);

var data = {

'action': 'tm_get_state',

'ds_qz_quiz_name': ds_qz_name,

};


// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php

$.post(ajaxurl, data, function(response) {

if(response>0){

$("#ajax_key").html("Same Name Allready Exist.. Please Use Another Name");

}

$("#ajax_key").html(response);

//alert('response : ' + response);

});

});





$("#ajax_key").change( function() {

var state=$("#ajax_key").val();

//alert(ds_qz_name);

var data = {

'action': 'tm_get_city',

'state': state,

};


// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php

$.post(ajaxurl, data, function(response) {

if(response>0){

$("#ajax_key1").html("Same Name Allready Exist.. Please Use Another Name");

}

$("#ajax_key1").html(response);

//alert('response : ' + response);

});

});






});


</script>