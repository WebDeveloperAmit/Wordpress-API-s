<?php
global $wpdb;


?>

<form name="form1" method="post" action="">
  <label>
  <select name="select" size="1" id="select">
  <?php
   $ds_query243="select * from `".$wpdb->prefix."ds_qz_question_category` ";
   $ds_data=$wpdb->get_results($ds_query243);
   foreach($ds_data as $ds_list){ 
  ?>
    <option value=""><?php echo $ds_list->name; ?></option>
    
   <?php
   }
   ?> 
    </select>
  </label>
</form>