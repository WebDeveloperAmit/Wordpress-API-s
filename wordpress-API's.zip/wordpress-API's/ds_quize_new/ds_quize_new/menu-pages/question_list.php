
<?php
global $wpdb;
if(isset($_POST['submit'])){

  $word_name=$_POST['word_name'];
  $meaning_one=$_POST['meaning_one'];
  $meaning_two=$_POST['meaning_two'];
  $meaning_three=$_POST['meaning_three'];
  $meaning_four=$_POST['meaning_four'];

  $id=$_POST['id'];

  
  $ds_qz_sql=$wpdb->query("UPDATE wp_tbl_questions SET word_name='$word_name', meaning_one='$meaning_one', meaning_two='$meaning_two', meaning_three='$meaning_three', meaning_four='$meaning_four' WHERE id='$id' ");
  //echo $wpdb->last_error; exit();
  if($ds_qz_sql){
  $_SESSION['ds_qz_msg']="Updated Successfuly";
    echo "success";
  }else{
    $_SESSION['ds_qz_msg']="Unable";
  echo "unable";
  }
  //header("location:");
  echo '<script>window.location.href=""</script>';

}else{
   add_action('shutdown','ds_unset_session_vars');
   function ds_unset_session_vars(){
     $_SESSION['ds_qz_msg']="";
   
   }
}
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <h1>
         Edit Word
       
      </h1>
    </section>
    
    <section class="content">
    
        <div class="row">
            <!-- left column -->
            <div class="col-md-8">
              <!-- general form elements -->

<div class="row1">
    <div class="col-md-12">
        <div class="box box-info">
<?php
$word_id = $_GET['id'];
global $wpdb;
$thepost = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM wp_tbl_questions WHERE id = $word_id" ) );



?>  
<p style="font-size: 16px;"> <?php echo $_SESSION['ds_qz_msg']; ?></p>          
      <form action="" method="post">
      <div class="box-body">
        <div class="row clearfix">
          


          <div class="col-md-6">
            <label for="word_name" class="control-label"><span class="text-danger">*</span>Word Name</label>
            <div class="form-group">
              <input type="text" name="word_name" value="<?php echo $thepost->word_name; ?>" class="form-control" id="word_name" />
             
            </div>
          </div>

          <div class="col-md-6">
            <label for="word_name" class="control-label"><span class="text-danger">*</span>Meaning One(Right Answer)</label>
            <div class="form-group">
              <input type="text" name="meaning_one" value="<?php echo $thepost->meaning_one; ?>" class="form-control" id="meaning_one" />
             
            </div>
          </div>

          <div class="col-md-6">
            <label for="word_name" class="control-label"><span class="text-danger">*</span>Meaning Two</label>
            <div class="form-group">
              <input type="text" name="meaning_two" value="<?php echo $thepost->meaning_two; ?>" class="form-control" id="meaning_two" />
             
            </div>
          </div>

          <div class="col-md-6">
            <label for="word_name" class="control-label"><span class="text-danger">*</span>Meaning Three</label>
            <div class="form-group">
              <input type="text" name="meaning_three" value="<?php echo $thepost->meaning_three; ?>" class="form-control" id="meaning_three" />
             
            </div>
          </div>

          <div class="col-md-6">
            <label for="word_name" class="control-label"><span class="text-danger">*</span>Meaning Four</label>
            <div class="form-group">
              <input type="text" name="meaning_four" value="<?php echo $thepost->meaning_four; ?>" class="form-control" id="meaning_four" />
             
            </div>
          </div>


        </div>
      </div>
      <br>
      <div class="box-footer">
        <input type="hidden" name="id" value="<?php echo $thepost->id; ?>">
              <button type="submit" name="submit" class="btn btn-success">
          <i class="fa fa-check"></i> Update
        </button>
          </div>        
      </form>
    </div>
    </div>
</div>

            </div>
        </div>    
    </section>
    
</div>