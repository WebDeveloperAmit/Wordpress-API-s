<?php
global $wpdb;
if(isset($_POST['ds_qz_submit'])){

  $cat=$_POST['cat'];

  $country=$_POST['country'];


  $ds_qz_sql=$wpdb->query("INSERT INTO tm_city (`id`, `city_name`, `country_id`) VALUES (NULL, '$cat', '$country')");
  //echo $wpdb->last_error; exit();
  if($ds_qz_sql){
  $_SESSION['ds_qz_msg']="Added Successfuly";
    echo "success";
  }else{
    $_SESSION['ds_qz_msg']="Unable";
	echo "unable";
  }
  //header("location:");
  echo '<script>window.location.href=""</script>';

}else{
   add_action('shutdown','ds_unset_session_vars');
   function ds_unset_session_vars(){
     $_SESSION['ds_qz_msg']="";
   
   }
}



if(isset($_POST['cat_delete'])){

  $id=$_POST['id'];

  $ds_qz_sql=$wpdb->query("DELETE FROM tm_city WHERE id='$id'");
  //echo $wpdb->last_error; exit();
  if($ds_qz_sql){
  $_SESSION['ds_qz_msg']="Deleted Successfuly";
    echo "success";
  }else{
    $_SESSION['ds_qz_msg']="Unable";
  echo "unable";
  }
  //header("location:");
  echo '<script>window.location.href=""</script>';

}else{
   add_action('shutdown','ds_unset_session_vars1');
   function ds_unset_session_vars1(){
     $_SESSION['ds_qz_msg']="";
   
   }
}




?>

<style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
</style>

<div>

  <h1 style="text-align: center;">City</h1>

<form style="margin-top: 50px;" method='post' action='' name='myform' enctype='multipart/form-data'>

<select style="padding: 12px 12px;border-radius: 0px;margin-bottom: 10px;background: #fff;color: #000;border:1px solid #eee;font-size: 14px;height: 50px!important;width: 100%;" name="country">

<option value="">Select Country</option>
  <?php
  $ds_query243="select * from tm_country";

   //if(!$ds_query) {echo "dasdasd";}
   $ds_data=$wpdb->get_results($ds_query243);
   //echo $wpdb->last_query;
   $ds_qz_count=0;
   foreach($ds_data as $ds_list){ $ds_qz_count++;
  ?>
<option value="<?php echo $ds_list->id;?>"><?php echo $ds_list->country_name;?></option>
 <?php
  }
  ?>
</select>

<input type="text" placeholder="City Name" style="padding: 12px 12px;border-radius: 0px;margin-bottom: 10px;background: #fff;color: #000;border:1px solid #eee;font-size: 14px;height: 50px!important;width: 50%;" name="cat">



<button name="ds_qz_submit" type="submit" style="padding: 12px 32px;border-radius: 0px;background: #000;color: #fff;font-size: 14px;height: 50px!important;">Submit now</button>



</form>

</div>

<table id="customers" width="100%" >
  <tr>
    <th>sl no </th>
    <th>State</th>
    <th>Country</th>
    <th> </th>
  </tr>
  <?php
  $ds_query243="select s.*,c.country_name from tm_city as s left join tm_country as c on(s.country_id=c.id)";

   //if(!$ds_query) {echo "dasdasd";}
   $ds_data=$wpdb->get_results($ds_query243);
   //echo $wpdb->last_query;
   $ds_qz_count=0;
   foreach($ds_data as $ds_list){ $ds_qz_count++;
  ?>
  <tr>
    <td><?php echo $ds_qz_count; ?>&nbsp;</td>
    <td><?php echo $ds_list->city_name;?>&nbsp;</td>
    <td><?php echo $ds_list->country_name;?>&nbsp;</td>
    <td>
      <div style="display: flex;">
<a href="<?php echo admin_url(); ?>admin.php?page=ds-quiz-city&&id=<?php echo $ds_list->id;?>" class="btn btn-info btn-xs" style="background:#000 ;color: #fff;padding: 5px 10px;"><span class="fa fa-pencil"></span> Edit</a>


<form style="margin-left: 10px;" method='post' action='' name='myform' enctype='multipart/form-data' >
<button type="submit" name="cat_delete" onclick="return confirm('Are you sure to delete?')">delete</button>
<input type="hidden" name="id" value="<?php echo $ds_list->id;?>">
</form>
</div>
    </td>

  </tr>
  <?php
  }
  ?>
</table>
