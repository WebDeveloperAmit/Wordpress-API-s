<?php
global $wpdb;
if(isset($_POST['ds_qz_submit'])){
  $ds_qz_name=$_POST['ds_qz_name'];
  $ds_qz_desc=$_POST['ds_qz_desc'];
  $ds_qz_quiz_cat=$_POST['ds_qz_quiz_cat'];
  
  
  $ds_qz_sql=$wpdb->query("INSERT INTO `".$wpdb->prefix."ds_qz_quizz` (`id`, `category`, `quizz_name`, `quizz_desc`, `created_time`, `created_by`, `status`) VALUES (NULL, '$ds_qz_quiz_cat', '$ds_qz_name', '$ds_qz_desc', NOW(), '', '')");
  if($ds_qz_sql){
  $_SESSION['ds_qz_msg']="New Quiz Added Successfuly";
  }else{
    $_SESSION['ds_qz_msg']="Unable To Add New Quiz";
  }
  //header("location:");
  echo '<script>window.location.href=""</script>';

}else{
   add_action('shutdown','ds_unset_session_vars');
   function ds_unset_session_vars(){
     $_SESSION['ds_qz_msg']="";
   
   }
}
?>


<script type="text/javascript" >
	jQuery(document).ready(function($) {
	  $("#ds_qz_name").keyup( function() {
	  
        var ds_qz_name=$("#ds_qz_name").val();
		var data = {
			'action': 'ds_qz_quiz_name_exist_check',
			'ds_qz_quiz_name': ds_qz_name,
			
		};

		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		$.post(ajaxurl, data, function(response) {
		if(response>0){
		  $("#name_ajax").html("Same Name Allready Exist.. Please Use Another Name");
		  		}
		$("#ajax_key").val(response);
			//alert('response : ' + response);
		});
       });
	});
	
	
	function ds_qz_validate(){
	  var exist=document.getElementById("ajax_key").value;
	  //alert(exist);
	  if(exist>0){
	     alert("Same Name Allready Exist.. Please Use Another Name");
		 return false; 
	  }
	//return false; 
	}
	
	</script> <?php 

//}

?>




<form action="" method="post"> 
<table width="100%" border="1">
  <tr>
    <td colspan="3" align="center">Add New Quiz </td>
  </tr>
  <tr>
    <td>Name
      <label>
      <input name="ds_qz_name" type="text" id="ds_qz_name">
    </label><span id="name_ajax"></span></td>
    <td>Description
      <input name="ds_qz_desc" type="text" id="ds_qz_desc"></td>
    <td>Category      
      <label>
	  <?php global $wpdb; ?>
      <select name="ds_qz_quiz_cat">
	    <option value="">Select Category</option>
		<?php  $ds_qz_data=$wpdb->get_results("SELECT * FROM 
		`".$wpdb->prefix."ds_qz_quizz_category` ");
		 foreach($ds_qz_data as $ds_qz_data){
		  ?>
		<option value="<?php echo $ds_qz_data->id;?>"><?php echo $ds_qz_data->name; ?></option>
		 <?php
		 }
		 ?>
      </select>
      </label></td>
  </tr>
  <tr>
    <td id="ds_qz_ajax_response">&nbsp;</td>
    <td>&nbsp;</td>
    <td><label>
      <input name="ds_qz_submit" type="submit" id="ds_qz_submit" value="Submit" onclick="return ds_qz_validate();">
   <?php echo $_SESSION['ds_qz_msg']; ?> 
   <input name="ajax_key" type="text" id="ajax_key" />
    </label></td>
  </tr>
</table>

</form>

<table width="100%" border="1">
  <tr>
    <td>sl no </td>
    <td>quiz name</td>
    <td>Description </td>
    <td>Category </td>
    <td>Questions</td>
    <td>Delete </td>
  </tr>
  <?php
  $ds_query243="select q.id,q.quizz_name,q.quizz_desc,q_cat.name as cat from 
  `".$wpdb->prefix."ds_qz_quizz` as q left join 
  `".$wpdb->prefix."ds_qz_quizz_category` as q_cat 
  on q.category=q_cat.id where q.status='0' order by q.id desc ";
   //if(!$ds_query) {echo "dasdasd";}
   $ds_qz_data=$wpdb->get_results($ds_query243);
   //echo $wpdb->last_query;
   $ds_qz_count=0;
   foreach($ds_qz_data as $ds_list){ $ds_qz_count++;
  ?>
  <tr>
    <td><?php echo $ds_qz_count; ?>&nbsp;</td>
    <td><?php echo $ds_list->quizz_name;?>&nbsp;</td>
    <td><?php echo $ds_list->quizz_desc;?>&nbsp;</td>
    <td><?php echo $ds_list->cat;?>&nbsp;</td>
    <td><a href="<?php echo  get_site_url(); ?>/wp-admin/?page=ds-quiz-questions&quiz_id=<?php echo $ds_list->id; ?>">Questions</a></td>
    <td>&nbsp;</td>
  </tr>
  <?php
  }
  ?>
</table>


