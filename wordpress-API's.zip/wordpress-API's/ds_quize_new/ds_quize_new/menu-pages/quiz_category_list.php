<?php

if(isset($_POST['ds_quiz_submit'])){
  $ds_qz_quiz_cat=$_POST['ds_add_quiz_cat_input'];
  global $wpdb;
  $ds_qz_query=$wpdb->query("INSERT INTO `".$wpdb->prefix."ds_qz_quizz_category` (`id`, `name`, `status`) VALUES (NULL, '$ds_qz_quiz_cat', '')");
  if($ds_qz_query){
    $_SESSION['ds_qz_msg']="quiz category added successfully";
  }else{
    $_SESSION['ds_qz_msg']="Unable";
  }
  //header("location:");
  echo '<script>window.location.href=""</script>';
  

}else{
   add_action('shutdown','ds_unset_session_vars');
   function ds_unset_session_vars(){
     $_SESSION['ds_qz_msg']="";
   
   }
}
?>
<form action="" method="post">
<input name="ds_add_quiz_cat_input" type="text">
<input type="submit" name="ds_quiz_submit" value="Add New Category"/>
</form>
<?php echo $_SESSION['ds_qz_msg']; ?>
<table width="100%" border="1">
  <tr>
    <td>id</td>
    <td> name </td>
    <td>edit</td>
    <td>delete</td>
  </tr>
  <?php
   global $wpdb;
   $ds_query243="select * from `".$wpdb->prefix."ds_qz_quizz_category` ";
   //if(!$ds_query) {echo "dasdasd";}
   $ds_data=$wpdb->get_results($ds_query243);
   //echo $wpdb->last_query;
   foreach($ds_data as $ds_list){ 
   ?>
  <tr>
    <td>&nbsp;</td>
    <td><?php echo $ds_list->name; ?>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <?php
   } 
   ?>
</table>
