<?php
global $wpdb;
if(isset($_POST['ds_qz_submit'])){
  $ds_qz_name=$_POST['ds_qz_name'];
  $ds_qz_user_name=$_POST['ds_qz_user_name'];
  $ds_qz_pass=md5($_POST['ds_qz_pass']);
  $ds_qz_email=$_POST['ds_qz_email'];
  $ds_qz_phone=$_POST['ds_qz_phone'];
  $ds_qz_user_group=$_POST['ds_qz_user_group'];
  $ds_qz_user_type="0";
  
  $ds_qz_sql=$wpdb->query("INSERT INTO `".$wpdb->prefix."ds_qz_users` (`user_id`, `user_name`, `password`, `name`, `added_time`, `user_type`,`user_group`, `email`, `phone_no`, `status`) VALUES (NULL, '$ds_qz_user_name', '$ds_qz_pass', '$ds_qz_name', NOW(), '$ds_qz_user_type','$ds_qz_user_group', '$ds_qz_email', '$ds_qz_phone', '')");
  //echo $wpdb->last_error; exit();
  if($ds_qz_sql){
  $_SESSION['ds_qz_msg']="New User Added Successfuly";
    echo "success";
  }else{
    $_SESSION['ds_qz_msg']="Unable";
	echo "unable";
  }
  //header("location:");
  echo '<script>window.location.href=""</script>';

}else{
   add_action('shutdown','ds_unset_session_vars');
   function ds_unset_session_vars(){
     $_SESSION['ds_qz_msg']="";
   
   }
}



if(isset($_POST['cat_delete'])){

  $id=$_POST['id'];

  $ds_qz_sql=$wpdb->query("DELETE FROM enquery WHERE id='$id'");
  //echo $wpdb->last_error; exit();
  if($ds_qz_sql){
  $_SESSION['ds_qz_msg']="Deleted Successfuly";
    echo "success";
  }else{
    $_SESSION['ds_qz_msg']="Unable";
  echo "unable";
  }
  //header("location:");
  echo '<script>window.location.href=""</script>';

}else{
   add_action('shutdown','ds_unset_session_vars1');
   function ds_unset_session_vars1(){
     $_SESSION['ds_qz_msg']="";
   
   }
}



?>

<style>
#customers {
  font-family: Arial, Helvetica, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

#customers td, #customers th {
  border: 1px solid #ddd;
  padding: 8px;
}

#customers tr:nth-child(even){background-color: #f2f2f2;}

#customers tr:hover {background-color: #ddd;}

#customers th {
  padding-top: 12px;
  padding-bottom: 12px;
  text-align: left;
  background-color: #04AA6D;
  color: white;
}
</style>

<table id="customers" width="100%" >
  <tr>
    <th>sl no </th>
    <th>Sports Title</th>
    <th>Name </th>
    <th>Email </th>
    <th>Club</th>
    <th>Phone</th>
    <th>Message </th>
    <th style="width:100px;">Date </th>
    <th> </th>
    
  </tr>
  <?php
  $ds_query243="select e.*,s.title from enquery as e left join sports as s on(e.sports_id=s.id)";

   //if(!$ds_query) {echo "dasdasd";}
   $ds_data=$wpdb->get_results($ds_query243);
   //echo $wpdb->last_query;
   $ds_qz_count=0;
   foreach($ds_data as $ds_list){ $ds_qz_count++;
  ?>
  <tr>
    <td><?php echo $ds_qz_count; ?>&nbsp;</td>
    <td><?php echo $ds_list->title;?>&nbsp;</td>
    <td><?php echo $ds_list->user_name;?>&nbsp;</td>
    <td><?php echo $ds_list->user_email;?>&nbsp;</td>
    <td><?php echo $ds_list->club;?>&nbsp;</td>
<td><?php echo $ds_list->phone;?>&nbsp;</td>
<td><?php echo $ds_list->message;?>&nbsp;</td>
<td><?php echo $ds_list->entry_date;?>&nbsp;</td>
<td>
<div style="display: flex;">

<form style="margin-left: 10px;" method='post' action='' name='myform' enctype='multipart/form-data' >
<button style="background-color: #fd4f4f; color: white;" type="submit" name="cat_delete" onclick="return confirm('Are you sure to delete?')">delete</button>
<input type="hidden" name="id" value="<?php echo $ds_list->id;?>">
</form>
</div>
  </td>
  </tr>
  <?php
  }
  ?>
</table>