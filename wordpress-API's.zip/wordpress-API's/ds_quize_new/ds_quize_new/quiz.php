<?php
/**
 * @package ds-quiz
 * @version 1.0
 */
/*
Plugin Name: TM SPORTSnew
Plugin URI: http://wordpress.org/extend/plugins/ds-quiz/
Description: this is a plugin to do  test.
Author: Tanmoy Mistry
Version: 1.0
Author URI: http://ma.tt/
*/

register_activation_hook( __FILE__, 'ds_quiz_install');

function ds_quiz_install(){
require_once("installer.php");
}

require_once("ds_ajax.php");

add_action('init','ds_qz_session');
function ds_qz_session(){
  if(session_id() == '') {
    session_start();
  }
}

/*register_deactivation_hook( __FILE__, 'ds_quiz_uninstall');

function ds_quiz_uninstall(){
require_once("uninstaller.php");
}*/

function ds_qz_frontend_display(){
require_once("frontend/login.php");
}

add_shortcode('ds_qz','ds_qz_frontend_display');


function ds_quiz_add_css(){
  //wp_enqueue_style( 'ds_style_css',plugin_dir_url( __FILE__ ) .'/css/style.css' );
  //wp_enqueue_style( 'ds_style_css1',plugin_dir_url( __FILE__ ) .'/css/css1.css' );
  wp_enqueue_script('ds_validate_js',plugin_dir_url( __FILE__ ) .'js/jquery.js');
  wp_enqueue_script('ds_validate_js1',plugin_dir_url( __FILE__ ) .'js/jquery1.js');
}




add_action('admin_menu','menu_for_quiz');
function menu_for_quiz(){
$ds_menu=add_menu_page('TM SPORTS','TM SPORTS','administrator','ds-quiz','ds_quiz_home_page');
//$ds_submenu1=add_submenu_page('ds-quiz','quiz','Quiz','administrator','ds-quiz-details','ds_quiz_details_page');

$ds_submenu10=add_submenu_page('','questions','','administrator','ds-quiz-questions','ds_quiz_question_details_page');

$ds_submenu10=add_submenu_page('','country_edit','','administrator','ds-quiz-country-edit','ds_quiz_country_edit_page');


$ds_submenu10=add_submenu_page('','city_edit','','administrator','ds-quiz-city','ds_quiz_city_details_page');


$ds_submenu10=add_submenu_page('','questions','','administrator','ds-quiz-questions_sports','ds_quiz_sports_details_page');
//$ds_submenu11=add_submenu_page('','Add questions','','administrator','ds-quiz-questions-add','ds_quiz_question_add_page');

//$ds_submenu4=add_submenu_page('ds-quiz','quiz category','Quiz Category','administrator','ds-quiz-category-details','ds_quiz_category_details_page');

//$ds_submenu5=add_submenu_page('ds-quiz','sdsd','Add quiz category','administrator','ds-quiz-category-details1','ds_quiz_add_category_page');

//$ds_submenu2=add_submenu_page('ds-quiz','QUESTION DETAILS','QUESTION DETAILS','administrator','ds-quiz-question-details','ds_quiz_question_details_page');

$ds_submenu3=add_submenu_page('ds-quiz','sports','Sports','administrator','ds-quiz-sports','ds_quiz_sports_page');

$ds_submenu3=add_submenu_page('ds-quiz','sports_category','Sports Category','administrator','ds-quiz-sports_cat','ds_quiz_sports_cat_page');

$ds_submenu3=add_submenu_page('ds-quiz','sports_category1','Country','administrator','ds-quiz-country','ds_quiz_country_page');


$ds_submenu3=add_submenu_page('ds-quiz','sports_category2','City','administrator','ds-quiz-city-add','ds_quiz_city_add_page');

$ds_submenu1=add_submenu_page('ds-quiz','sports_list','Sports List','administrator','ds-quiz-users','ds_quiz_users_page');

$ds_submenu2=add_submenu_page('ds-quiz','words','Words','administrator','ds-quiz-words','ds_quiz_words_page');

$ds_submenu1=add_submenu_page('ds-quiz','query_list','Enquery List','administrator','ds-quiz-query_list','ds_quiz_query_list_page');

//$ds_submenu3=add_submenu_page('ds-quiz','r_words','Related Words','administrator','ds-quiz-r_words','ds_quiz_r_words_page');

//$ds_submenu4=add_submenu_page('ds-quiz','result','Result','administrator','ds-quiz-result','ds_quiz_result');
//$ds_submenu7=add_submenu_page('ds-quiz','Users Group','Users Group','administrator','ds-quiz-users-group','ds_quiz_users_group_page');
add_action( 'admin_print_styles-' .$ds_submenu3, 'ds_quiz_add_css' );
add_action( 'admin_print_scripts-' .$ds_submenu3, 'ds_quiz_add_css' );
//$ds_submenu6=add_submenu_page('ds-quiz','Question Category','Question Category','administrator','ds-quiz-question-category','ds_quiz_qustion_category_page');
//$ds_submenu7=add_submenu_page('ds-quiz','Question Category List','Question Category List','administrator','ds-quiz-question-category-show','ds_quiz_qustion_category_list_show');
//$ds_submenu8=add_submenu_page('ds-quiz','Assignments','Assignments','administrator','ds-quiz-assignments','ds_quiz_assignments_page');
/*add_action( 'admin_print_styles-' . $ds_submenu1, 'ds_add_style_script' );*/
}


function ds_quiz_assignments_page(){
  require_once("menu-pages/assignments.php");

}

function ds_quiz_category_details_page(){
  require_once("menu-pages/quiz_category_list.php");
}
function ds_quiz_add_category_page(){
  require_once("menu-pages/quiz_category_list.php");
}

function ds_quiz_details_page(){
  require_once("menu-pages/quiz_list.php");
}

function ds_quiz_question_details_page(){
  require_once("menu-pages/cat_edit.php");
}

function ds_quiz_country_edit_page(){
  require_once("menu-pages/country_edit.php");
}

function ds_quiz_city_details_page(){
  require_once("menu-pages/city_edit.php");

}


function ds_quiz_sports_details_page(){
  require_once("menu-pages/sports_edit.php");
}

function ds_quiz_sports_page(){
  require_once("menu-pages/sports_add.php");
}

function ds_quiz_sports_cat_page(){
  require_once("menu-pages/cat_add.php");
}

function ds_quiz_users_page(){
  require_once("menu-pages/users_list.php");
}

function ds_quiz_query_list_page(){
  require_once("menu-pages/query_list.php");
}

function ds_quiz_words_page(){
  require_once("menu-pages/words_list.php");
}

function ds_quiz_result(){
  require_once("menu-pages/result_list.php");
}

function ds_quiz_r_words_page(){
  require_once("menu-pages/r_words_list.php");
}

function ds_quiz_qustion_category_page(){
  require_once("menu-pages/question_category_list.php");
}
function ds_quiz_qustion_category_list_show(){
  require_once("menu-pages/question_category_list_show.php");
}
function ds_quiz_users_group_page(){
  require_once("menu-pages/user_group_list.php");
}

function ds_quiz_question_add_page(){
  require_once("menu-pages/add_questions.php");

}

function ds_quiz_country_page(){
  require_once("menu-pages/country_add.php");
}

function ds_quiz_city_add_page(){
  require_once("menu-pages/state_add.php");
}
