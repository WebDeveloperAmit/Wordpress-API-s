<?php


//this part needed for ajaxurl page (admin-ajax page) which is not included by default in frontend but it is included in backend by default//
add_action('wp_head','ds_qz_ajaxurl');
function ds_qz_ajaxurl() {
?>
<script type="text/javascript">
var ajaxurl = '<?php echo admin_url('admin-ajax.php'); ?>';
</script>
<?php
}

////////////////////////////////////////////////////////////////////////////////


/////////////---------------------ajax state--------------------------//////////
add_action( 'wp_ajax_tm_get_state','tm_get_state');
function tm_get_state(){
    $ds_quiz_name=$_POST['ds_qz_quiz_name'];
$state_id = $_POST['tm_state'];
   global $wpdb;
   $ds_qz_result=$wpdb->get_results("select * from state where countryid='$ds_quiz_name'"); 

?>
      <option value="">Select State</option>
<?php foreach($ds_qz_result as $ds_qz_data){?>
        <option <?php if($state_id==$ds_qz_data->sid){echo "selected";} ?> value="<?php echo $ds_qz_data->sid;?>"><?php echo $ds_qz_data->state_name;?>
    </option>
<?php } ?>
<?php 
  wp_die(); 
}
/////////////---------------------ajax state--------------------------//////////

/////////////---------------------ajax city--------------------------//////////
add_action( 'wp_ajax_tm_get_city','tm_get_city');
function tm_get_city(){
    $country=$_POST['country'];
    $city_id = $_POST['tm_city'];

   global $wpdb;
   $ds_qz_result=$wpdb->get_results("select * from tm_city where country_id='$country'"); 

?>
      <option value="">City</option>
<?php foreach($ds_qz_result as $ds_qz_data){?>
        <option <?php if($city_id==$ds_qz_data->id){echo "selected";} ?> value="<?php echo $ds_qz_data->id;?>"><?php echo $ds_qz_data->city_name;?>
    </option>
<?php } ?>

<?php 
  wp_die(); 
}
/////////////---------------------ajax city--------------------------//////////
 



?>
