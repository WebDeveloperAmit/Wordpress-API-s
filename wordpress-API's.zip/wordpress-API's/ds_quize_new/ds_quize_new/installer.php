<?php
global $wpdb;
$sql="CREATE TABLE `".$wpdb->prefix."ds_qz_answers` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `answer_data` varchar(100) NOT NULL,
 `correct` tinyint(1) NOT NULL,
 `correct_answer_text` varchar(100) NOT NULL,
 `points` varchar(3) NOT NULL,
 `answer_desc` text NOT NULL,
 `status` int(1) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";
$sql=$wpdb->query($sql);

$sql="CREATE TABLE `".$wpdb->prefix."ds_qz_assignments` (
 `id` int(8) NOT NULL AUTO_INCREMENT,
 `quizz_id` int(8) NOT NULL,
 `show_result` int(1) NOT NULL,
 `review` int(1) NOT NULL,
 `added_time` timestamp NOT NULL,
 `pass_score` varchar(5) NOT NULL,
 `assignment_type` int(1) NOT NULL,
 `status` int(1) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";
$sql=$wpdb->query($sql);

$sql="CREATE TABLE `".$wpdb->prefix."ds_qz_assignment_users` (
 `id` int(8) NOT NULL AUTO_INCREMENT,
 `assignment_id` int(8) NOT NULL,
 `user_types` int(2) NOT NULL,
 `user_id` int(5) NOT NULL,
 `status` int(1) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";
$sql=$wpdb->query($sql);

$sql="CREATE TABLE `".$wpdb->prefix."ds_qz_questions` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `question_data` text NOT NULL,
 `question_type` int(2) NOT NULL,
 `points` varchar(3) NOT NULL,
 `created_time` timestamp NOT NULL,
 `created_by` int(5) NOT NULL,
 `header_text` text NOT NULL,
 `footer_text` text NOT NULL,
 `hint` text NOT NULL,
 `status` int(1) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";
$sql=$wpdb->query($sql);

$sql="CREATE TABLE `".$wpdb->prefix."ds_qz_question_category` (
 `id` int(2) NOT NULL AUTO_INCREMENT,
 `name` varchar(100) NOT NULL,
 `desc` text NOT NULL,
 `status` int(1) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";
$sql=$wpdb->query($sql);

$sql="CREATE TABLE `".$wpdb->prefix."ds_qz_quizz` (
 `id` int(8) NOT NULL AUTO_INCREMENT,
 `category` int(5) NOT NULL,
 `quizz_name` text NOT NULL,
 `quizz_desc` text NOT NULL,
 `created_time` timestamp NOT NULL,
 `created_by` int(5) NOT NULL,
 `status` int(1) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";
$sql=$wpdb->query($sql);

$sql="CREATE TABLE `".$wpdb->prefix."ds_qz_quizz_category` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `name` varchar(100) NOT NULL,
 `status` int(1) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";
$sql=$wpdb->query($sql);

$sql="CREATE TABLE `".$wpdb->prefix."ds_qz_users` (
 `user_id` int(5) NOT NULL AUTO_INCREMENT,
 `user_name` varchar(100) NOT NULL,
 `password` varchar(64) NOT NULL,
 `name` varchar(100) NOT NULL,
 `added_time` timestamp NOT NULL,
 `user_type` int(1) NOT NULL,
 `email` varchar(100) NOT NULL,
 `phone_no` varchar(20) NOT NULL,
 `status` int(1) NOT NULL,
 PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";
$sql=$wpdb->query($sql);

$sql="CREATE TABLE `".$wpdb->prefix."ds_qz_user_answers` (
 `id` int(8) NOT NULL AUTO_INCREMENT,
 `user_quiz_id` int(8) NOT NULL,
 `question_id` int(8) NOT NULL,
 `answer_id` int(8) NOT NULL,
 `user_answer_text` varchar(100) NOT NULL,
 `created_time` timestamp NOT NULL,
 `status` int(1) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";
$sql=$wpdb->query($sql);

$sql="CREATE TABLE `".$wpdb->prefix."ds_qz_user_groups` (
 `id` int(5) NOT NULL,
 `group_name` varchar(100) NOT NULL,
 `status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1";
$sql=$wpdb->query($sql);

$sql="CREATE TABLE `".$wpdb->prefix."ds_qz_user_quizzes` (
 `quizz_id` int(8) NOT NULL AUTO_INCREMENT,
 `assignment_id` int(8) NOT NULL,
 `user_id` int(5) NOT NULL,
 `start_time` timestamp NOT NULL,
 `end_time` timestamp NOT NULL,
 PRIMARY KEY (`quizz_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1
";
$sql=$wpdb->query($sql);

$sql="CREATE TABLE `".$wpdb->prefix."ds_qz_user_types` (
 `id` int(5) NOT NULL AUTO_INCREMENT,
 `user_type_name` varchar(20) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";
$sql=$wpdb->query($sql);

$sql="CREATE TABLE `".$wpdb->prefix."question_type` (
 `id` int(11) NOT NULL AUTO_INCREMENT,
 `que_type_name` varchar(30) NOT NULL,
 PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1";
$sql=$wpdb->query($sql);


















?>
