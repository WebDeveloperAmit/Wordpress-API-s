<?php
  global $wpdb;
  $ds_qz_assignment_id=$_POST['ds_qz_assignment_id'];
  $ds_qz_quiz_id=$_POST['ds_qz_quiz_id'];
  $_SESSION['ds_qz_assignment_hint_stat']=$_POST['ds_qz_hint_stat'];
  $wpdb->query("INSERT INTO `".$wpdb->prefix."ds_qz_user_quizzes` (`quizz_id`, `assignment_id`, 
  `user_id`, `start_time`, `end_time`) VALUES ('$ds_qz_quiz_id', '$ds_qz_assignment_id', 
  '".$_SESSION['ds_qz_user_id']."', NOW(),'')");
  
  echo "<script></script>";
  ds_qz_get_quiz_question();
  
 






?>
