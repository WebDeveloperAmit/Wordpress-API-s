<?php 

  $ds_qz_assignment_id=$_POST['ds_qz_assignment_id'];
  $ds_qz_quiz_id=$_POST['ds_qz_quiz_id'];
  $ds_qz_user_id=$_SESSION['ds_qz_user_id'];
  global $wpdb;
  
  $ds_qz_data=$wpdb->get_row("select q.quizz_name,m.* from `".$wpdb->prefix."ds_qz_mark_sheet`
   as m left join `".$wpdb->prefix."ds_qz_quizz` as q on m.quiz_id=q.id where
   m.quiz_id='$ds_qz_quiz_id' and assignment_id='$ds_qz_assignment_id'
   and user_id='$ds_qz_user_id' limit 1 ");
   echo $wpdb->last_query;
   


?>


<table width="100%" border="1">
  <tr>
    <td width="12%">&nbsp;</td>
    <td width="88%">&nbsp;</td>
  </tr>
  <tr>
    <td>Quizz Name </td>
    <td><?php echo $ds_qz_data->quizz_name; ?>&nbsp;</td>
  </tr>
  <tr>
    <td>Total Question </td>
    <td><?php echo $ds_qz_data->total_question; ?>&nbsp;</td>
  </tr>
  <tr>
    <td>Correct Answer </td>
    <td><?php echo $ds_qz_data->correct_answer; ?>&nbsp;</td>
  </tr>
  <tr>
    <td>Wrong Answer </td>
    <td><?php echo $ds_qz_data->wrong_answer; ?>&nbsp;</td>
  </tr>
  <tr>
    <td>Obtained Percentage </td>
    <td><?php echo $ds_qz_data->obtained_percentage; ?>&nbsp;</td>
  </tr>
  <tr>
    <td>Remarks</td>
    <td><?php echo $ds_qz_data->remarks; ?>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
</table>

