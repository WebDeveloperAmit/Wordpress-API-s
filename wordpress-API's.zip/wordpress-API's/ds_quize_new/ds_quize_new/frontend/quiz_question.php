<?php
  global $wpdb;
  $ds_qz_assignment_id=$_POST['ds_qz_assignment_id'];
  $ds_qz_quiz_id=$_POST['ds_qz_quiz_id'];
  $ds_qz_total_question=$_POST['ds_qz_total_question'];
  //echo "jgjghjgjh<br/>";
  if(isset($_POST['ds_qz_instru'])){
    //echo "proceed";
    $ds_qz_question_id=$_POST['ds_qz_question_id'];
	$ds_qz_answer_id=$_POST['ds_qz_answer'];
	$ds_qz_answer=$_POST['ds_qz_answer'];
	$ds_qz_user_id=$_SESSION['ds_qz_user_id'];
	$ds_qz_answer_type=$_POST['ds_qz_answer_type'];
	//this is used for only rearrenge//
	$ds_qz_segment2=$_POST['ds_qz_attempt'];
	/////////////////////////////////////////
	if($ds_qz_answer_type==3){
	   $ds_qz_answer_text=$ds_qz_answer[0];
	}else{
	   $ds_qz_answer_text="";
	}
	$ds_qz_counter=0;
	foreach($ds_qz_answer_id as $ds_qz_answer_data){
	  if($ds_qz_answer_type==4){
	    $ds_qz_answer_text=$ds_qz_segment2[$ds_qz_counter];
	  }
	  $wpdb->query("INSERT INTO `".$wpdb->prefix."ds_qz_user_answers` (`id`, `user_id`, 
	  `user_assignment_id`, `user_quiz_id`, `question_id`, `answer_id`, 
	  `user_answer_text`, `created_time`, `status`) VALUES (NULL, '$ds_qz_user_id',
	   '$ds_qz_assignment_id', '$ds_qz_quiz_id', '$ds_qz_question_id', '$ds_qz_answer_data',
	    '$ds_qz_answer_text',NOW(), '')");
		$ds_qz_counter++;
	}
  
  }else{
	  //echo "not done";
	}
	//this section need to implemented by mysql_num_rows //////////
  $ds_qz_done_questions_id=$wpdb->get_results("select distinct question_id as done from 
  `".$wpdb->prefix."ds_qz_user_answers` where user_id='".$_SESSION['ds_qz_user_id']."' and user_assignment_id='$ds_qz_assignment_id' and user_quiz_id='$ds_qz_quiz_id' and status=0  ");
  //echo $wpdb->last_query;
  $ds_qz_done_questions_holder=array();
  foreach($ds_qz_done_questions_id as $ds_qz_done_question_id){
    $ds_qz_done_questions_holder[]=$ds_qz_done_question_id->done;
  }
  $user_answer_count=sizeof($ds_qz_done_questions_holder);
  ////////////////////////////////////////////////////////////////////////
  //echo "answer count :".$user_answer_count."<br/>";
  $ds_qz_remain_question=$ds_qz_total_question-$user_answer_count;
  if($ds_qz_remain_question==0){
    end_quiz_question(); 
  exit();
  }
  
  $ds_qz_data=$wpdb->get_row("select * from `".$wpdb->prefix."ds_qz_questions` where  
  quiz_id='$ds_qz_quiz_id' and id not in(select question_id from `".$wpdb->prefix.
  "ds_qz_user_answers` where user_id='".$_SESSION['ds_qz_user_id']."' and 
  user_quiz_id='$ds_qz_quiz_id' )");
  //echo $wpdb->last_error;
  //print_r($ds_qz_sql);
  
  
  
	
    //echo $wpdb->last_query;
	//print_r($ds_qz_answer_data);
?>
  <script type="text/javascript" >
	jQuery(document).ready(function($) {
	  $("#ds_qz_answer_submit_btn").click( function() {
        var assignment_id=$("#ds_qz_assignment_id").val();
		var quiz_id=$("#ds_qz_quiz_id").val();
		var ds_qz_question_id=$('#ds_qz_question_id');
		/*var data = {
			'action': 'ds_qz_get_quiz_question',
			$('#ds_qz_form1').serialize(),
			
		};*/

		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		$.post(ajaxurl, $('#ds_qz_form1').serialize(), function(response) {
		$("#ds_qz_ajax_area").html(response);
			//alert('response : ' + response);
		});
       });
	});
	</script>
	<?php
	if($ds_qz_data->question_type==1|| $ds_qz_data->question_type==2){
    $ds_qz_answer_data=$wpdb->get_results("select id,answer_data from 
	`".$wpdb->prefix."ds_qz_answers` where question_id='$ds_qz_data->id' ");
	?> 
	<?php echo $user_answer_count; ?> Question Attended Out Of <?php echo $ds_qz_total_question; ?>
  <form action="" method="post" id="ds_qz_form1">
  <table width="100%" border="1">
  <tr>
    <td colspan="3" align="center"><?php echo $ds_qz_data->question_data; ?>&nbsp;</td>
    </tr>
<?php   
  $ds_qz_counter=0;
  foreach($ds_qz_answer_data as $ds_qz_answer){ 
    $ds_qz_counter++;
?>
  <tr>
    <td width="2%"><?php echo $ds_qz_counter; ?>&nbsp;</td>
    <td width="4%">&nbsp;
	<?php if($ds_qz_data->question_type==1) {?>
	  <input name="ds_qz_answer[]" id="ds_qz_answer" type="radio" value="<?php echo $ds_qz_answer->id;?>" />
	<?php }else{ ?>
	  <input type="checkbox" name="ds_qz_answer[]" id="ds_qz_answer" value="<?php echo $ds_qz_answer->id;?>" />
	<?php } ?>
	</td>
    <td width="94%"><?php echo $ds_qz_answer->answer_data; ?>&nbsp;</td>
  </tr>
<?php } ?>
<?php if($_SESSION['ds_qz_assignment_hint_stat']==1 && 
$ds_qz_data->hint!=""){ ?>
  <tr>
    <td colspan="3" align="center">Hint : <?php echo $ds_qz_data->hint; ?>&nbsp;</td>
    
  </tr>
<?php } ?>
  <!--<tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>-->
  <tr>
    <td colspan="3" align="center">
	<input name="ds_qz_answer_submit_btn" id="ds_qz_answer_submit_btn" type="button" value="Next" />
	<input type="text" name="ds_qz_instru" value="submit_answer" />
	<input type="ds_qz_assignment_id" name="ds_qz_assignment_id" value="<?php echo $ds_qz_assignment_id; ?>" />
	<input type="ds_qz_quiz_id" name="ds_qz_quiz_id" value="<?php echo $ds_qz_quiz_id; ?>" />
	<input type="ds_qz_question_id" name="ds_qz_question_id" value="<?php echo $ds_qz_data->id; ?>" />
	<input type="text" name="action" value="ds_qz_get_quiz_question" />
	<input type="text" name="ds_qz_total_question"
	 value="<?php echo $ds_qz_total_question; ?> " />
	 <input type="text" name="ds_qz_answer_type" 
	 value="<?php echo $ds_qz_data->question_type; ?>" />
	
	
	&nbsp;
	</td>
    
  </tr>
</table>
</form>
<?php }
  if($ds_qz_data->question_type==3){
  ?>
  <form action="" method="post" id="ds_qz_form1">
  <table width="300" border="1">
   <tr>
    <td colspan="3" align="center"><?php echo $ds_qz_data->question_data; ?>&nbsp;</td>
    </tr>
  <tr>
    <td>enter Answer 
      <label>
      <textarea name="ds_qz_answer[]" id="ds_qz_answer"></textarea>
    </label></td>
  </tr>
  <tr>
    <td colspan="3" align="center">
	<input name="ds_qz_answer_submit_btn" id="ds_qz_answer_submit_btn" type="button" value="Next" />
	<input type="text" name="ds_qz_instru" value="submit_answer" />
	<input type="ds_qz_assignment_id" name="ds_qz_assignment_id" value="<?php echo $ds_qz_assignment_id; ?>" />
	<input type="ds_qz_quiz_id" name="ds_qz_quiz_id" value="<?php echo $ds_qz_quiz_id; ?>" />
	<input type="ds_qz_question_id" name="ds_qz_question_id" value="<?php echo $ds_qz_data->id; ?>" />
	<input type="text" name="action" value="ds_qz_get_quiz_question" />
	<input type="text" name="ds_qz_total_question"
	 value="<?php echo $ds_qz_total_question; ?> " />
	 <input type="text" name="ds_qz_answer_type" 
	 value="<?php echo $ds_qz_data->question_type; ?>" />
	
	
	&nbsp;
	</td>
    
  </tr>

</table>
</form>
<?php } ?>
<?php
	if($ds_qz_data->question_type==4){
	$ds_qz_answer_main_data=$wpdb->get_results("select *  from `".$wpdb->prefix."ds_qz_answers` where question_id='$ds_qz_data->id' ");
	 //echo "<pre>";
	 //print_r($ds_qz_answer_main_data);
	?>
	<form action="" method="post" id="ds_qz_form1"> 
   <table width="300" border="1">
  <tr>
    <td>Answers</td>
    <td>Correct</td>
  </tr>
  <?php 
  $used_answers=array();
  $where="";
  $ds_qz_counter=0;
  foreach($ds_qz_answer_main_data as $ds_qz_answer){
    $ds_qz_counter++;
	  if($ds_qz_counter>0){
	  //$where =" and correct_answer_text!='$ds_qz_answer->correct_answer_text' ";
	  }
    $ds_qz_wrong_answers=$wpdb->get_results("select correct_answer_text from 
	`".$wpdb->prefix."ds_qz_answers` where question_id='$ds_qz_data->id' 
	".$where." ");
	 $answer_container=array();
	 //print_r($ds_qz_wrong_answers);
	 foreach($ds_qz_wrong_answers as $ds_qz_wrong_answer_data){
	   $answer_container[]=$ds_qz_wrong_answer_data->correct_answer_text;
	 }
	 //print_r($answer_container);
	shuffle($answer_container); 
	//echo $wpdb->last_error;
	//echo $wpdb->last_query;
	//$answer_container[]=$ds_qz_wrong_answer;
	//print_r($answer_container);
  ?>
  <tr>
    <td><label>
      <!--<input name="ds_qz_answer[]" type="text" id="ds_qz_answer" value="<?php echo $ds_qz_answer->answer_data; ?>">-->
	  <select name="ds_qz_answer[]" id="ds_qz_answer">
	     <option value="<?php echo $ds_qz_answer->id; ?>">
		   <?php echo $ds_qz_answer->answer_data; ?>
		 </option>
	  </select>
    </label></td>
    <td><label>
    <!--<input name="ds_qz_attempt[]" type="text" id="ds_qz_attempt" value="<?php echo $answer_container[0]; ?>">-->
	<select name="ds_qz_attempt[]" id="ds_qz_attempt">
	<?php foreach($answer_container as $answer_container_data){ ?>
	     <option value="<?php echo $answer_container_data; ?>">
		   <?php echo $answer_container_data; ?>
		 </option>
    <?php } ?>
	</select>
    </label></td>
  </tr>
  <?php } ?>
  <tr> 
    <td colspan="2" align="center">
	<input name="ds_qz_answer_submit_btn" id="ds_qz_answer_submit_btn" type="button" value="Next" />
	<input type="text" name="ds_qz_instru" value="submit_answer" />
	<input type="ds_qz_assignment_id" name="ds_qz_assignment_id" value="<?php echo $ds_qz_assignment_id; ?>" />
	<input type="ds_qz_quiz_id" name="ds_qz_quiz_id" value="<?php echo $ds_qz_quiz_id; ?>" />
	<input type="ds_qz_question_id" name="ds_qz_question_id" value="<?php echo $ds_qz_data->id; ?>" />
	<input type="text" name="action" value="ds_qz_get_quiz_question" />
	<input type="text" name="ds_qz_total_question"
	 value="<?php echo $ds_qz_total_question; ?> " />
	 <input type="text" name="ds_qz_answer_type" 
	 value="<?php echo $ds_qz_data->question_type; ?>" />
	</td>
  </tr>
  
</table>
</form>
 <?php 
  }
  wp_die();
?>