<script type="text/javascript">
jQuery(document).ready(function($) {
   $("#ds_qz_table  tbody tr").on("click", function(event){
     var ds_qz_row_num=$(this).index();
	 var ds_qz_counter=0;
	 $('input#ds_qz_assignment_id_hidden').each(function() {
	   if(ds_qz_counter==ds_qz_row_num){
	     var assignment_id=$(this).val();
		 //alert(assignment_id);
		 var data = {'action': 'ds_qz_assignment_details','ds_x': 2,'ds_qz_assignment_id':assignment_id,};
		 $.post(ajaxurl, data, function(response) {
		    $("#ds_qz_ajax_area").html(response);
			//alert('response : ' + response);
		 });
		 return false;
	   }
       ds_qz_counter++;
     })
	
   });
});



/*  function ds_qz_get_assignment_details(id){
     alert(id);
    var data = {
			'action': 'ds_qz_assignment_details',
			'ds_x': 2,
			'ds_qz_assignment_id': id,
			
		};

		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		$.post(ajaxurl, data, function(response) {
		$("#ds_qz_ajax_area").html(response);
			alert('response : ' + response);
		});
  
  }*/
</script>
 <?php $ds_qz_user_group=$_POST['ds_qz_user_group'];
  global $wpdb;
  /*$ds_qz_assignment_data=$wpdb->get_results("select a.id as assignment_id,q.quizz_name,q.id as quizz_id from
   `".$wpdb->prefix."ds_qz_assignments` as a,`".$wpdb->prefix."ds_qz_quizz` as q where a.quizz_id=q.id and a.user_group='$ds_qz_user_group' ");*/
   $ds_qz_assignment_data=$wpdb->get_results("select m.remarks,a.id as assignment_id,q.quizz_name,
   q.id as quizz_id from `".$wpdb->prefix."ds_qz_assignments` as a inner join 
   `".$wpdb->prefix."ds_qz_quizz` as q on a.quizz_id=q.id left join `".$wpdb->prefix."ds_qz_mark_sheet` as m on a.id=m.assignment_id where a.user_group='$ds_qz_user_group' ");
   echo $wpdb->last_error;
   
   
   ?>
   <table width="100%" id="ds_qz_table" border="0">
<?php foreach($ds_qz_assignment_data as $ds_qz_data){ ?>
    <tr><td>
	<input type="hidden" name="ds_qz_assignment_id_hidden[]" id="ds_qz_assignment_id_hidden" value=" <?php echo $ds_qz_data->assignment_id; ?>" />
    <span id="ds_qz_assign_det" style="cursor:pointer" > <?php echo $ds_qz_data->quizz_name; ?>
	<?php if($ds_qz_data->remarks==NULL){echo " Start";}else{echo "View Result";} ?>
	 </span> <br/>
	</td></tr>
<?php }
  
  wp_die();
  ?>