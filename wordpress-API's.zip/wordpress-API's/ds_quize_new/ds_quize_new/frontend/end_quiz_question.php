<?php
  global $wpdb;
  $ds_qz_assignment_id=$_POST['ds_qz_assignment_id'];
  $ds_qz_quiz_id=$_POST['ds_qz_quiz_id'];
  $ds_qz_user_id=$_SESSION['ds_qz_user_id'];
  $wpdb->query("UPDATE `".$wpdb->prefix."ds_qz_user_quizzes` SET  `end_time` = NOW()
   WHERE `quizz_id` ='$ds_qz_quiz_id' and assignment_id='$ds_qz_assignment_id' and 
   user_id='$ds_qz_user_id' limit 1 ");
   
   //echo "first update <br/>";
   
   $ds_qz_question=$wpdb->get_results("select id,question_type from `".$wpdb->prefix."ds_qz_questions`
   where quiz_id='$ds_qz_quiz_id' ");
   $ds_qz_question_count=0;
   $ds_qz_correct_answer_count=0;
    //echo "first update <br/>";
   foreach($ds_qz_question as $ds_qz_question_data){
     $ds_qz_question_count++;
	 if($ds_qz_question_data->question_type==3){
	   $ds_qz_and= " and correct='0' and correct_answer_text!='' ";
	 }else{
	   $ds_qz_and= " and correct='1' ";
	 }
     $ds_qz_answer_count=$wpdb->get_var("select count(*) as found from `".$wpdb->prefix."ds_qz_answers` where 
	 question_id='$ds_qz_question_data->id' ".$ds_qz_and." ");
	 //echo $wpdb->last_query;
	 $ds_qz_answer=$wpdb->get_results("select id,answer_data,correct_answer_text from `".$wpdb->prefix."ds_qz_answers` where 
	 question_id='$ds_qz_question_data->id' ".$ds_qz_and." ");
	  $ds_qz_correct_answer_sub_count=0;
	  
	 foreach($ds_qz_answer as $ds_qz_answer_data){
	   if($ds_qz_question_data->question_type==3){
	     $ds_qz_and=" and user_answer_text='$ds_qz_answer_data->correct_answer_text' ";
	   }elseif($ds_qz_question_data->question_type==4){
	     $ds_qz_and=" and answer_id='$ds_qz_answer_data->id' and 
		 user_answer_text='$ds_qz_answer_data->correct_answer_text' ";
	   }else{
	     $ds_qz_and=" and answer_id='$ds_qz_answer_data->id' ";
	   }
	   $ds_qz_user_answer=$wpdb->get_row("select count(*)as found from `".$wpdb->prefix."ds_qz_user_answers` 
	   where user_id='$ds_qz_user_id' and user_assignment_id='$ds_qz_assignment_id' and 
	   user_quiz_id='$ds_qz_quiz_id' ".$ds_qz_and." ");
	   //echo $wpdb->last_query;
	   //exit();
	   if($ds_qz_user_answer->found==1){
	     $ds_qz_correct_answer_sub_count++;
	   }
	   if($ds_qz_question_data->question_type==4){
	     if($ds_qz_correct_answer_sub_count==4){
	       $ds_qz_correct_answer_count++; 
		 // plus 1 when 4 correct answer found for rearrenge against same question////////////////////
	     }
	    }else{
	      if($ds_qz_correct_answer_sub_count==1){
	        $ds_qz_correct_answer_count++; 
		 //plus 1 when correct answer found in user answer . in case of multi correct answer will plus one not 
		 //more than one//
	       }
	     }
	   
	 }
   
   }
   
   $ds_qz_pass_percentage=$wpdb->get_var("select pass_score from `".$wpdb->prefix."ds_qz_assignments`
    where id='$ds_qz_assignment_id' limit 1");
   $ds_qz_wrong_answer_count=$ds_qz_question_count-$ds_qz_correct_answer_count;
   $ds_qz_obtained_percentage=(100/$ds_qz_question_count)*$ds_qz_correct_answer_count;
   if($ds_qz_obtained_percentage<$ds_qz_pass_percentage){
     $ds_qz_remarks="Failed";
   }else{
     $ds_qz_remarks="Passed";
   }
   
   $wpdb->query("INSERT INTO `".$wpdb->prefix."ds_qz_mark_sheet` (`user_id`, `assignment_id`, `quiz_id`, `total_marks`, `obtained_marks`, `required_percentage`, `obtained_percentage`, `remarks`, `total_question`, `correct_answer`, `wrong_answer`, `unattempted`) VALUES ('$ds_qz_user_id', '$ds_qz_assignment_id', '$ds_qz_quiz_id', '', '', '$ds_qz_pass_percentage', '$ds_qz_obtained_percentage', '$ds_qz_remarks',
    '$ds_qz_question_count', '$ds_qz_correct_answer_count', '$ds_qz_wrong_answer_count', '')");
   
   
  
  /*$ds_qz_question_data=$wpdb->get_results("select q.id as question_id,q.question_type,a.id as
   answer_id,a.correct_answer_text from 
  `".$wpdb->prefix."ds_qz_questions` as q left join  `".$wpdb->prefix."ds_qz_answers` as a on q.id=a.question_id
   where q.quiz_id='$ds_qz_quiz_id' and a.correct='1' ");
   $ds_qz_remember_que_id="";
   $ds_qz_last_correct="";
   $ds_qz_correct_answer_count=0;
   foreach($ds_qz_question_data as $ds_qz_que_det){
     
     $ds_qz_correct=$wpdb->get_var(" select count(*) as found from `".$wpdb->prefix."ds_qz_user_answers` where 
	 user_quiz_id='$ds_qz_quiz_id' and user_assignment_id='$ds_qz_assignment_id' 
	 and question_id='$ds_qz_que_det->question_id' and answer_id='$ds_qz_que_det->answer_id'");
	 if($ds_qz_remember_que_id==$ds_qz_que_det->question_id){
	    if($ds_qz_last_correct==0){
		  $ds_qz_correct_answer_count+=$ds_qz_correct;
		} 
	 }else{
	   $ds_qz_correct_answer_count+=$ds_qz_correct;
	   $ds_qz_remember_que_id=$ds_qz_que_det->question_id;
	   $ds_qz_last_correct=$ds_qz_correct;
	 }
   
   }*/
   

?>
<script type="text/javascript" >
	jQuery(document).ready(function($) {
	  $("#ds_qz_result_view").click( function() {
        var assignment_id=$("#ds_qz_assignment_id").val();
		var quiz_id=$("#ds_qz_quiz_id").val();
		var total_question=$("#ds_qz_total_question").val();
		var data = {
			'action': 'ds_qz_view_marksheet',
			'ds_qz_assignment_id': assignment_id,
			'ds_qz_quiz_id': quiz_id,
			
		};

		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		$.post(ajaxurl, data, function(response) {
		$("#ds_qz_ajax_area").html(response);
			//alert('response : ' + response);
		});
       });
	});
	</script> 

<div align="center"> Quiz test Completed <br/> <span id="ds_qz_result_view" style="cursor:pointer; text-decoration:underline" >Click here to view Result</span> 
  <input type="hidden" name="ds_qz_assignment_id" id="ds_qz_assignment_id" value="<?php echo $ds_qz_assignment_id; ?>" />
  <input type="hidden" name="ds_qz_quiz_id" id="ds_qz_quiz_id" 
  value="<?php echo $ds_qz_quiz_id; ?>" />
</div>
<?php
  wp_die();
?>