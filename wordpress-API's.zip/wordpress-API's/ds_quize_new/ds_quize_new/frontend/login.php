<?php
/*add_action( 'wp_footer', 'my_action3_javascript' ); // Write our JS below here

function my_action3_javascript() {*/ ?>
<div id="ds_qz_ajax_response">
	<script type="text/javascript" >
	jQuery(document).ready(function($) {
	  $("#ds_ajax_submit").click( function() {
        var ds_qz_user_name=$("#ds_qz_user_name").val();
		var ds_qz_password=$("#ds_qz_password").val();
		var data = {
			'action': 'ds_qz_login',
			'ds_x': 2,
			'ds_qz_user_name': ds_qz_user_name,
			'ds_qz_password': ds_qz_password,
			
		};

		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		$.post(ajaxurl, data, function(response) {
		$("#ds_qz_ajax_response").html(response);
			//alert('response : ' + response);
		});
       });
	});
	</script> <?php 

//}

?>


<table align="center" width="500" border="1">
  <tr>
    <td colspan="4">&nbsp;</td>
  </tr>
  <tr>
    <td width="50">&nbsp;</td>
    <td width="186">User Name </td>
    <td width="189"><label>
      <input type="text" name="ds_qz_user_name" id="ds_qz_user_name">
    </label></td>
    <td width="47">&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>Password</td>
    <td><input type="text" name="ds_qz_password" id="ds_qz_password"></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
    <td><label>
      <input type="submit" name="ds_ajax_submit" id="ds_ajax_submit" value="Submit">
    </label></td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="4">&nbsp;</td>
  </tr>
</table>

</div>

