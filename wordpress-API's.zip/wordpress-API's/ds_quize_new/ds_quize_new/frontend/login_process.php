<?php // this is how you get access to the database

	//$ds_x =  $_POST['ds_x'];
	//$whatever += 10;
	global $wpdb;
	$ds_qz_user_name=$_POST['ds_qz_user_name'];
	$ds_qz_password=md5($_POST['ds_qz_password']);
	
    $sql="select count(*) from `".$wpdb->prefix."ds_qz_users` where
	 user_name='$ds_qz_user_name' and password='$ds_qz_password'";
if($wpdb->get_var($sql)>0){
    $sql="select * from `".$wpdb->prefix."ds_qz_users` where
	 user_name='$ds_qz_user_name' and password='$ds_qz_password' limit 1";
    $ds_qz_user_data=$wpdb->get_row($sql);
	$_SESSION['ds_qz_user_name']=$ds_qz_user_data->user_name;
	$_SESSION['ds_qz_password']=$ds_qz_user_data->password;
	$_SESSION['ds_qz_user_id']=$ds_qz_user_data->user_id;
	
	/*$ds_qz_assignment_data=$wpdb->get_results("select q.quizz_name,q.id as quizz_id from `".$wpdb->prefix."ds_qz_assignments` as a,`".$wpdb->prefix."ds_qz_quizz` as q where a.quizz_id=q.id and a.user_group=$ds_qz_user_data->user_group ");*/
	$ds_qz_assignment=$wpdb->get_row("select count(*) as count from 
	`".$wpdb->prefix."ds_qz_assignments` where user_group=$ds_qz_user_data->user_group ");
	//echo $wpdb->last_query;
	
?>


<table width="500" border="1">
  <tr>
    <td id="ds_timer_area"><input type="hidden" name="time_remain" id="time_remain" value="300" />&nbsp;
	<div id="timer"></div>
	</td>
  </tr>
  <tr>
    <td align="center" id="ds_qz_ajax_area">
<script type="text/javascript" >
	jQuery(document).ready(function($) {
	  $("#ds_qz_assignment_btn").click( function() {
        
		var data = {
			'action': 'ds_qz_assignment_list',
			'ds_x': 2,
			'ds_qz_user_group': '<?php echo $ds_qz_user_data->user_group; ?>',
			
		};

		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		$.post(ajaxurl, data, function(response) {
		$("#ds_qz_ajax_area").html(response);
			//alert('response : ' + response);
		});
       });
	});
	</script>
	
	hello <?php echo $ds_qz_user_data->name; ?>
	Welcome To Quiz Section Home Page  &nbsp; <br />
	<span id="ds_qz_assignment_btn" style="cursor:pointer"><?php echo $ds_qz_assignment->count." Assignments" ; ?></span>
	
	</td>
  </tr>
  <tr>
    <td>&nbsp;</td>
  </tr>
</table>
<?php
}else{
echo "Unable To Login";
}
	wp_die();
?>