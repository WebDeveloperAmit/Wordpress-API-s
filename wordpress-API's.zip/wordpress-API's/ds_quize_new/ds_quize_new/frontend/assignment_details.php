<?php
$ds_qz_assignment_id=$_POST['ds_qz_assignment_id'];
  global $wpdb;
  $ds_qz_assign_det=$wpdb->get_row("select q.quizz_name,q.id as que_id,a.id 
  as assignment_id,a.pass_score,a.assigned_time,a.hint from `".$wpdb->prefix."ds_qz_assignments` as a left join `".$wpdb->prefix."ds_qz_quizz` as q on a.quizz_id=q.id where a.id='$ds_qz_assignment_id' limit 1");
  
  $ds_qz_que_count=$wpdb->get_row("select count(*)as que_count from `".$wpdb->prefix."ds_qz_questions` where quiz_id='$ds_qz_assign_det->que_id'");
  ?>
  <input type="text" name="ds_qz_time" id="ds_qz_time" value="<?php echo $ds_qz_assign_det->assigned_time; ?>" />
 <script type="text/javascript" >
	jQuery(document).ready(function($) {
	  $("#ds_qz_start_btn").click( function() {
        var assignment_id=$("#ds_qz_assignment_id").val();
		var quiz_id=$("#ds_qz_quiz_id").val();
		var total_question=$("#ds_qz_total_question").val();
		var ds_qz_hint_stat=$("#ds_qz_hint_stat").val();
		var data = {
			'action': 'ds_qz_start_quiz_question',
			'ds_qz_assignment_id': assignment_id,
			'ds_qz_quiz_id': quiz_id,
			'ds_qz_total_question': total_question,
			'ds_qz_hint_stat':ds_qz_hint_stat,
			
		};

		// since 2.8 ajaxurl is always defined in the admin header and points to admin-ajax.php
		$.post(ajaxurl, data, function(response) {
		$("#ds_qz_ajax_area").html(response);
			//alert('response : ' + response);
			start_timer();
		});
       });
	});
function start_timer(){	
  //var set_time=document.getElementById("ds_qz_time").value;
  var set_time="<?php echo $ds_qz_assign_det->assigned_time; ?>";
  
  set_time=parseInt(set_time)*60;
  
  document.getElementById("time_remain").value=set_time;
  var num=document.getElementById("time_remain").value;
  //alert("time : "+num);
  var myVar=setInterval(function(){myTimer(document.getElementById
  ("time_remain").value)},1000);
}	
function myTimer(num){

  num--;
  var remain=rectime(num);
  document.getElementById("timer").innerHTML=remain;
  document.getElementById("time_remain").value=num;
  if(document.getElementById("time_remain").value==0) {
    document.form1.submit();
  }
  return num;
}


function rectime(secs) {
	var hr = Math.floor(secs / 3600);
	var min = Math.floor((secs - (hr * 3600))/60);
	var sec = secs - (hr * 3600) - (min * 60);
	
	if (hr < 10) {hr = "0" + hr; }
	if (min < 10) {min = "0" + min;}
	if (sec < 10) {sec = "0" + sec;}
	/*if (hr) {hr = "00";}*/
	return hr + ':' + min + ':' + sec;
}
	</script> 
  <table width="100%" border="1">
  <tr>
    <td>Quizz Name&nbsp;</td>
    <td><?php echo $ds_qz_assign_det->quizz_name; ?> &nbsp;</td>
  </tr>
  <tr>
    <td>Number Of Questions&nbsp;</td>
    <td><?php echo $ds_qz_que_count->que_count; ?> &nbsp;</td>
  </tr>
  <tr>
    <td>Pass Score&nbsp;</td>
    <td> <?php echo $ds_qz_assign_det->pass_score ; ?>&nbsp;</td>
  </tr>
  <tr>
    <td>Time Duration&nbsp;</td>
    <td> <?php echo $ds_qz_assign_det->assigned_time ; ?>&nbsp;</td>
  </tr>
  <tr>
    <td colspan="2" align="center">
	<input type="hidden" name="ds_qz_quiz_id" id="ds_qz_quiz_id" value="<?php echo $ds_qz_assign_det->que_id; ?>" />
	<input type="hidden" name="ds_qz_hint_stat" id="ds_qz_hint_stat" value="<?php echo $ds_qz_assign_det->hint; ?>" />
	<input type="hidden" name="ds_qz_assignment_id" id="ds_qz_assignment_id" value="<?php echo $ds_qz_assign_det->assignment_id; ?>" />
	<input type="hidden" name="ds_qz_total_question" id="ds_qz_total_question" value="<?php echo $ds_qz_que_count->que_count; ?>" />
	
	<input type="button" name="ds_qz_start_btn" id="ds_qz_start_btn" value="Start Now" />
	
	</td>
    
  </tr>
</table>

  
  
<?php
  wp_die();
?>