<?php
/**
 * Template Name: Single Exam Page

 */

get_header(); 

?>
<!-- header area stop -->
<div class="innerbannertwo" style="background-image:url(<?php echo get_template_directory_uri(); ?>/images/innerbanner1.png);">
  <div class="container">
     <div class="book_inner_banner">
       <img src="<?php echo get_template_directory_uri(); ?>/images/img6.png" alt="image" class="book_img_thum1">
       <div class="book_img_thum2">
         <img src="<?php echo get_template_directory_uri(); ?>/images/img8.png" alt="image" title="">
       </div>
       <div class="book_img_thum3">
         <img src="<?php echo get_template_directory_uri(); ?>/images/img7.png" alt="image" title="">
       </div>
       <div class="book_inner_contain">
         <h3>
           <span>أسئلة في</span>
         </h3>
         <h4>الكتب</h4>
       </div>
     </div>
  </div>
</div>
<div class="innermain course_book_area bg1">
  <div class="container">
    <div class="row">      
      <div class="col-lg-6">
        


        <div class="faqbox faqbox2">
          <h4>إمتحان رقم <?php echo $_GET['exam']; ?></h4>
          <p>الرجاء إختيار السؤال المناسب:</p>
          <div id="main">          
             <div class="accordion" id="faq">


 

<?php
$count=0;
if( have_rows('question',$post->ID) ):
    while( have_rows('question',$post->ID) ) : the_row();
$count++;
?>
                                   <div class="card">
                                <div class="card-header" id="faqhead<?php echo $count; ?>">
                                    <a href="#" class="btn btn-header-link <?php if($count!=1){echo 'collapsed';} ?>" data-toggle="collapse" data-target="#faq<?php echo $count; ?>"
                                    aria-expanded="true" aria-controls="faq1"><span><?php echo get_sub_field('tm_question'); ?> - <?php echo get_sub_field('chapter'); ?></span></a>
                                </div>
        
                                <div id="faq<?php echo $count; ?>" class="collapse <?php if($count==1){echo 'show';} ?>" aria-labelledby="faqhead1" data-parent="#faq">
                                    <div class="card-body">
<?php if(get_sub_field('tm_content')!=''){ ?>
    <?php echo get_sub_field('tm_content'); ?>
<?php }else{ ?>

<!--  <img src="<?php echo get_sub_field('image'); ?>" alt="image" title="" class="w-50"> -->

 <a data-fancybox href="<?php echo get_sub_field('image'); ?>"> <img src="<?php echo get_sub_field('image'); ?>" alt=""> </a>

<?php } ?>	

                                    </div>
                                </div>
                            </div>

<?php 
    endwhile;

else :

endif; 
?>





 


                        </div>
            
          </div>  
        </div>



      </div>
      <div class="col-lg-6">
        <div class="course_book_box">
          <p>السؤال غير موجود في اللائحة؟</p>
          <p>إضغط هنا لكي نقوم بإضافة السؤال</p>
          <div class="image_box">
            <img src="<?php echo get_template_directory_uri(); ?>/images/img9.png" alt="image" title="" class="course_thum1">
            <div class="course_thum2">
              <img src="<?php echo get_template_directory_uri(); ?>/images/img11.png" alt="image" title="">
            </div>
            <div class="course_thum3">
              <img src="<?php echo get_template_directory_uri(); ?>/images/img10.png" alt="image" title="">
            </div>
            <div class="course_thum4">
<?php
if($_SESSION['userid']==''){
?>
     <a href="https://enigma-study.com/user_login/"><img src="<?php echo get_template_directory_uri(); ?>/images/img12.png" alt="image" title=""></a>
<?php }else{ ?>
<a href="https://enigma-study.com/add_exam_question/"><img src="<?php echo get_template_directory_uri(); ?>/images/img12.png" alt="image" title=""></a>
<?php } ?>

            </div>
            <div class="course_thum5">
              <img src="<?php echo get_template_directory_uri(); ?>/images/img13.png" alt="image" title="">
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>


<?php get_footer(); ?>