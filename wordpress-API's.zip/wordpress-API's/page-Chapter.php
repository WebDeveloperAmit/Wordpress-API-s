<?php
/**
 * Template Name: Chapter

 */

get_header(); 
global $wpdb;

$_COOKIE["tm_id"];
if($_COOKIE["tm_id"]==''){
 $user_id = $_SESSION['ds_qz_user_id'] ;
}else{
  $user_id = $_COOKIE["tm_id"];
}

$booklet = $_GET['booklet'];

?>

<div class="innermain">
<div class="innermartra_area">
   <div class="innermartra_area_top d-flex justify-content-between align-items-center">
      <div class="usermarthera">
      <img src="<?php echo get_template_directory_uri(); ?>/images/women.png" alt="">
      </div>
      <div class="martraback">
        <button><i class="fas fa-chevron-left"></i></button>
      </div>
    </div>
  <div class="text-center">
  <h3>المستويات</h3>
  <p>حدد مستوى صعوبة الاختبار</p>
<?php
$booklet = $_GET['booklet'];

$wpdb->get_results("SELECT * FROM wp_tbl_questions WHERE  booklet='$booklet'"); 

$total2 = $wpdb->num_rows;
  

?>
  <p>عدد الكلمات الكلي في البوكليت   <span style="font-family: verdana;"><?php echo $total2; ?></p>  
  </div>
</div>
  <div class="container">
     <div class="martra_area">

       <ul>

<?php
//echo $booklet;
if($booklet==2){
$thepost = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM wp_ds_qz_user_result WHERE user_id = $user_id AND booklet='1' AND lebel='10' AND total_sec!=0 ORDER BY overall_point DESC LIMIT 1") );
}elseif($booklet==3){
$thepost = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM wp_ds_qz_user_result WHERE user_id = $user_id AND booklet='2' AND chapter='10' AND total_sec!=0 ORDER BY overall_point DESC LIMIT 1") );  
}elseif($booklet==4){
$thepost = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM wp_ds_qz_user_result WHERE user_id = $user_id AND booklet='3' AND chapter='10' AND total_sec!=0 ORDER BY overall_point DESC LIMIT 1") );  
}
//$wpdb->last_query;
$overall_point = $thepost->overall_point;
if($overall_point>19){
?>

  <li class="martra_list" style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/martrabg1.svg);"><a href="<?php echo home_url(); ?>/preview/?chapter=chapter_1&&booklet=<?php echo $booklet; ?>"></a></li>

<?php }else{ ?>

<!-- <li class="martra_list disable" style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/martrabg1.svg);"></li> -->

<li class="martra_list" style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/martrabg1.svg);"><a href="<?php echo home_url(); ?>/preview/?chapter=chapter_1&&booklet=<?php echo $booklet; ?>"></a></li>

<?php } ?>         

<?php
$thepost = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM wp_ds_qz_user_result WHERE user_id = $user_id AND booklet='$booklet' AND chapter='1' AND total_sec!=0 ORDER BY overall_point DESC LIMIT 1") );
//$wpdb->last_query;
$overall_point = $thepost->overall_point;
if($overall_point>19){
?>
         <li class="martra_list" style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/martrabg2.svg);"><a href="<?php echo home_url(); ?>/preview/?chapter=chapter_2&&booklet=<?php echo $booklet; ?>"></a></li>

<?php }else{ ?>

<li class="martra_list disable" style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/martrabg2.svg);"></li>

<?php } ?>

<?php
$thepost = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM wp_ds_qz_user_result WHERE user_id = $user_id AND booklet='$booklet' AND chapter='2' AND total_sec!=0 ORDER BY overall_point DESC LIMIT 1") );
$wpdb->last_query;
$overall_point = $thepost->overall_point;
if($overall_point>19){
?>
         <li class="martra_list" style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/martrabg3.svg);"><a href="<?php echo home_url(); ?>/preview/?chapter=chapter_3&&booklet=<?php echo $booklet; ?>"></a></li>

<?php ?>

<?php }else{ ?>

<li class="martra_list disable" style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/martrabg3.svg);"></li>

<?php } ?>

<?php
$thepost = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM wp_ds_qz_user_result WHERE user_id = $user_id AND booklet='$booklet' AND chapter='3' AND total_sec!=0 ORDER BY overall_point DESC LIMIT 1") );
$wpdb->last_query;
$overall_point = $thepost->overall_point;
if($overall_point>19){
?>
         <li class="martra_list" style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/martrabg4.svg);"><a href="<?php echo home_url(); ?>/preview/?chapter=chapter_4&&booklet=<?php echo $booklet; ?>"></a></li>
<?php }else{ ?>

<li class="martra_list disable" style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/martrabg4.svg);"></li>

<?php } ?>

<?php
$thepost = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM wp_ds_qz_user_result WHERE user_id = $user_id AND booklet='$booklet' AND chapter='4' AND total_sec!=0 ORDER BY overall_point DESC LIMIT 1") );
$wpdb->last_query;
$overall_point = $thepost->overall_point;
if($overall_point>19){
?>         

         <li class="martra_list" style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/martrabg5.svg);"><a href="<?php echo home_url(); ?>/preview/?chapter=chapter_5&&booklet=<?php echo $booklet; ?>"></a></li>
<?php }else{ ?>

<li class="martra_list disable" style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/martrabg5.svg);"></li>

<?php } ?>
<?php
$thepost = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM wp_ds_qz_user_result WHERE user_id = $user_id AND booklet='$booklet' AND chapter='5' AND total_sec!=0 ORDER BY overall_point DESC LIMIT 1") );
$wpdb->last_query;
$overall_point = $thepost->overall_point;
if($overall_point>19){
?>         

         <li class="martra_list" style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/martrabg6.svg);"><a href="<?php echo home_url(); ?>/preview/?chapter=chapter_6&&booklet=<?php echo $booklet; ?>"></a></li>
<?php }else{ ?>

<li class="martra_list disable" style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/martrabg6.svg);"></li>

<?php } ?>
<?php
$thepost = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM wp_ds_qz_user_result WHERE user_id = $user_id AND booklet='$booklet' AND chapter='6' AND total_sec!=0 ORDER BY overall_point DESC LIMIT 1") );
$wpdb->last_query;
$overall_point = $thepost->overall_point;
if($overall_point>19){
?>         

         <li class="martra_list" style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/martrabg7.svg);"><a href="<?php echo home_url(); ?>/preview/?chapter=chapter_7&&booklet=<?php echo $booklet; ?>"></a></li>
<?php }else{ ?>

<li class="martra_list disable" style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/martrabg7.svg);"></li>

<?php } ?>
<?php
$thepost = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM wp_ds_qz_user_result WHERE user_id = $user_id AND booklet='$booklet' AND chapter='7' AND total_sec!=0 ORDER BY overall_point DESC LIMIT 1") );
$wpdb->last_query;
$overall_point = $thepost->overall_point;
if($overall_point>19){
?>         

         <li class="martra_list" style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/martrabg8.svg);"><a href="<?php echo home_url(); ?>/preview/?chapter=chapter_8&&booklet=<?php echo $booklet; ?>"></a></li>
<?php }else{ ?>

<li class="martra_list disable" style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/martrabg8.svg);"></li>

<?php } ?>
<?php
$thepost = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM wp_ds_qz_user_result WHERE user_id = $user_id AND booklet='$booklet' AND chapter='8' AND total_sec!=0 ORDER BY overall_point DESC LIMIT 1") );
$wpdb->last_query;
$overall_point = $thepost->overall_point;
if($overall_point>19){
?>         

         <li class="martra_list" style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/martrabg9.svg);"><a href="<?php echo home_url(); ?>/preview/?chapter=chapter_9&&booklet=<?php echo $booklet; ?>"></a></li>
<?php }else{ ?>

<li class="martra_list disable" style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/martrabg9.svg);"></li>

<?php } ?>
<?php
$thepost = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM wp_ds_qz_user_result WHERE user_id = $user_id AND booklet='$booklet' AND chapter='9' AND total_sec!=0 ORDER BY overall_point DESC LIMIT 1") );
$wpdb->last_query;
$overall_point = $thepost->overall_point;
if($overall_point>19){
?>         

         <li class="martra_list" style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/martrabg10.svg);"><a href="<?php echo home_url(); ?>/preview/?chapter=chapter_10&&booklet=<?php echo $booklet; ?>"></a></li>
<?php }else{ ?>

<li class="martra_list disable" style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/martrabg10.svg);"></li>

<?php } ?>


<?php
$thepost = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM wp_ds_qz_user_result WHERE user_id = $user_id AND booklet='$booklet' AND chapter='10' AND total_sec!=0 ORDER BY overall_point DESC LIMIT 1") );
$overall_point = $thepost->overall_point;
if($overall_point>19){
?>  


      <a href="https://enigma-study.com/mega-leaderboard/?booklet=<?php echo $booklet; ?>">
      <li class="martra_list lastlist" style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/martrabg11.svg);">
      مستوى  ميجا
      </li>
      </a>
<?php }else{ ?>

<li class="martra_list lastlist disable" style="background-image: url(<?php echo get_template_directory_uri(); ?>/images/martrabg11.svg);">
           مستوى  ميجا
</li>

<?php } ?>


       </ul>
     </div>
  </div>
</div>



<?php get_footer(); ?>