<?php 
 foreach ($CourseData as $row) {
 		if(empty($row->header_title))
 		{ $title=$row->course_name; }
 		else
 		{ $title=$row->header_title; }
 		$keywords=$row->keywords;
 		$keywords_desc=$row->keywords_desc;		
 	}	
?>
<?php include('include/header.php');?>
<?php include('include/top_header.php');?>
<?php include('include/nav.php');?>
	<!-- Inner Page Breadcrumb -->
<?php
$student_email=$this->session->userdata('student_email');
 $ip_address=$_SERVER['REMOTE_ADDR'];
     $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, "http://www.geoplugin.net/json.gp?ip=".$ip_address);
    curl_setopt($ch, CURLOPT_HEADER, 0);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
    $ip_data_in = curl_exec($ch); // string
    curl_close($ch);

    $ip_data = json_decode($ip_data_in,true);
    $ip_data = str_replace('&quot;', '"', $ip_data); 
    if($ip_data && $ip_data['geoplugin_countryName'] != null) {
        $city = $ip_data['geoplugin_city'];
        $country = $ip_data['geoplugin_countryName'];
    }
    else
    {
        $city ="New York"; 
       $country ="United States";
    }
    
$timezone_modify=date(' T');

foreach ($CourseData as $row) {
    $course_name=str_replace(" ","-",$row->course_name);
?>
 <section class="banner_content" style="padding-top: 0px !important;">
    <div class="container">
        <div class="row">
    		<div class="col-md-6"> </div>
    			 <div class="col-md-6 mr0 pr0 coursepagesearch">
         	   	<div class="search_box_home4" >
                <div class="ht_search_widget">
                  <div class="header_search_widget" style="margin:0px !important;padding: 0px !important;">
                    <form action="<?php echo base_url()?>search" method="POST"  class="form-inline mailchimp_form">
                      <input type="text" id="skill_input" class="form-control mb-2 mr-sm-2" name="search" placeholder="Enter Keywords (e.g. Java, Oracle, etc...)">
                      <button type="submit" class="btn btn-primary mb-2"><span class="fa fa-search"></span></button>
                    </form>
                  </div>
                </div>
              </div>
        	</div>
    		</div>
    
    	<div class="course-box-bg">
        <div class="row">
        	  <div class="col-md-12">
        	  	<?php 
			 $enrollmsg=$this->session->flashdata('enrollmsg');
			  $error=$this->session->flashdata('error');
			 if(!empty($enrollmsg))
			 {
			 ?>
			 <div class="alert alert-success alert-dismissible fade show">
	        <strong>Success!</strong> <?php echo $enrollmsg;?>
	        <button type="button" class="close" data-dismiss="alert">&times;</button>
	    	</div>
			 <?php	
			 }
			 if(!empty($error))
			 {
			 ?>
			 <div class="alert alert-danger alert-dismissible fade show">
	        <strong>Error! </strong> <?php echo $error;?>
	        <button type="button" class="close" data-dismiss="alert">&times;</button>
	    	</div>
			 <?php	
			 }
		   ?>
        	  </div>
        	    <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12"> 
        	    <div class="row"> 
				<div class="coursetitle"><b><?php echo $row->course_name;?> </b> </div>
				</div>
            	<?php
            		if(!empty($row->youtube_link))
            		{
            		 ?>
					<div class="courseImageBackground mt10">
						<a rel="noreferrer nofollow" class="video-btn" href="javascript:void(0);"  data-src="<?php echo $row->youtube_link;?>" data-toggle="modal"  data-target="#video-popup">
						<h4><strong>Preview</strong> Course Video</h4>
						<center>
						<img src="<?php echo base_url()?>assets/videopay.png" class="video-btn">
						</center>
						</a>
					</div>
            		 <?php	
            		}
            		else
            		{
            		 ?>
            		 <div class="courseImageBackground mt10">
						<img src="<?php echo $row->course_image;?>">
					</div>
            		 <?php	
            		}
            	?>
				<script>
				(function ($){
					$(document).on('ready',function(){
					$(document).on('click','.video-btn',function(){
					var ip_video_src = $(this).attr('data-src');
					if(ip_video_src){			 
					var ip_video_src_trim = ip_video_src.trim();			  
					$('#video-popup .embed-responsive').html('').html('<iframe class="embed-responsive-item" src="'+ip_video_src_trim+'?autoplay=1&rel=0&modestbranding=1&showinfo=0" allowfullscreen="allowfullscreen" allowscriptaccess="always" allow="autoplay" ></iframe>');
					} 
					});
					$(document).on('click','button.close',function () {
					$('#video-popup .embed-responsive').html('');
					});		
				  });   
				})( jQuery );
				</script>
				<div class="sign_up_modal modal fade" id="video-popup" tabindex="-1" role="dialog" aria-hidden="true">
					<div class="modal-dialog modal-dialog-centered" role="document">
						<div class="modal-content">
						<div class="modal-header">
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
						</div>
						<div style="width: 96% !important;margin:auto !important;"> 
							<br>
							<div class="embed-responsive embed-responsive-16by9"><iframe class="embed-responsive-item" src="<?php echo $row->youtube_link;?>?autoplay=1&mute=1" allowfullscreen="allowfullscreen" allowscriptaccess="always" allow="autoplay"></iframe>
							</div>
								<br>
						  </div>
						</div>
					</div>
				</div>
				<?php
					if($country=='India')
						{
						  $sym="INR"; 
					      $live_training_total= $row->live_training_total;
						}
						else if($country=='United States' && $row->live_training_total>0)
						{
					        $sym="USD"; 
					     	$live_training_total=($row->live_training_total/75);   
						}
						else if($country=='Canada' && $row->live_training_total>0)
						{
						  $sym="CAD";  
    						  $live_training_total=($row->live_training_total/53); 
						}
						else if($country=='United Kingdom')
						{
						  $sym="Pound";
						  $live_training_total=($row->live_training_total/92);   
						}
						else if($country=='Australian' && $row->live_training_total>0)
						{
						  $sym="ADollar";  
    						  $live_training_total=($row->live_training_total/49); 
						}
						else
						{
						  $sym="USD"; 
						  if($row->live_training_total>0)
						  {
						      $live_training_total=($row->live_training_total/71);
						  }
						  else
						  {
						      $live_training_total=$row->live_training_total;  
						  }
						} 
						
						if(!$live_training_total=='' or !$live_training_total=='0')
						{
							?>
							<div class="course-fee mt10">
							<b>Course Fee : <?php echo round($live_training_total,1);?> <?php echo $sym;?>  </b>
							</div>
							<?php
						}
					?> 
				<?php
				if(!empty($row->total_enrollment))
				{
					?>
					<div class="total-learner">
				     <?php echo $row->course_name;?> Learners from Hachion: <?php echo $row->total_enrollment;?> 
					</div>
					<?php
				}
			  ?>
            </div>
            <div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
		
			<div class="page_title mt10">
			  <h3>Course Description </h3>
			</div>
			
            <div class="SubHeadingText" style="color: #000;">
                <?php echo $row->description;?>
            </div> 
            </div>
          </div>
        </div>
         <?php
    if(!$row->benefit1=='' or !$row->benefit2=='' or !$row->benefit3=='' or !$row->benefit4=='' or !$row->benefit5=='' or !$row->benefit6=='')
		{
		 ?>
        	<div class="course-box-bg">
			<div class="row">
				<div class="col-md-12">
				  <h3>Benefits from Hachion </h3>
				</div>
			<?php
					if(!$row->benefit1=='')
					{
					  ?>
						<div class="col-md-4">
						<p class="feature-icons"><i class="fa fa-user"> </i>
						<span><?php echo $row->benefit1;?></span> </p>
						</div>
					  <?php	
					}
					if(!$row->benefit2=='')
					{
					  ?>
						<div class="col-md-4">
						<p class="feature-icons"><i class="fa fa-tasks"></i>
						<span><?php echo $row->benefit2;?></span> </p>
						</div>
					  <?php	
					}
					if(!$row->benefit3=='')
					{
					  ?>
						<div class="col-md-4">
						<p class="feature-icons"><i class="fa fa-history"></i>
						<span><?php echo $row->benefit3;?></span> </p>
						</div>
					  <?php	
					}
					if(!$row->benefit4=='')
					{
					  ?>
						<div class="col-md-4">
						<p class="feature-icons"><i class="fa fa-history"></i>
						<span><?php echo $row->benefit4;?></span> </p>
						</div>
					  <?php	
					}
					if(!$row->benefit5=='')
					{
					  ?>
						<div class="col-md-4">
						<p class="feature-icons"><i class="fa fa-file"></i>
						<span><?php echo $row->benefit5;?></span> </p>
						</div>
					  <?php	
					}
					if(!$row->benefit6=='')
					{
					  ?>
						<div class="col-md-4">
						<p class="feature-icons"><i class="fa fa-certificate"></i>
						<span><?php echo $row->benefit6;?></span> </p>
						</div>
					  <?php	
					}
				?>

			</div>
		</div>
		 <?php	
		}	
    ?>
   
<script>
(function ($){
    $(document).on('ready',function(){
    $(document).on('click','.video-btn',function(){
    var ip_video_src = $(this).attr('data-src');
    if(ip_video_src){			 
    var ip_video_src_trim = ip_video_src.trim();			  
    $('#video-popup .embed-responsive').html('').html('<iframe class="embed-responsive-item" src="'+ip_video_src_trim+'?autoplay=1&rel=0&modestbranding=1&showinfo=0" allowfullscreen="allowfullscreen" allowscriptaccess="always" allow="autoplay" ></iframe>');
    } 
    });
    $(document).on('click','button.close',function () {
    $('#video-popup .embed-responsive').html('');
    });		
    });   
    })( jQuery );
</script>
<style>
.search_box_home4 .header_search_widget .mailchimp_form .form-control {
	padding-left: 30px;
	width: 450px;
	font-size: 17px;
	border: 1px solid #000;
}
@media (min-width: 200px) and (max-width: 600px) {
    .search_box_home4 .header_search_widget .mailchimp_form button 
    {
        position: absolute;
        right: 1px !important;
        top: 3px !important;
        height: 32px !important;
        font-size: 14px !important;
    }
    .header_search_widget .mailchimp_form .form-control {
        padding-left: 5px !important; 
    }
}
@media (min-width: 600px) and (max-width: 1024px) {
.modes h5 {
    font-weight: 500;
    font-size: 16px;
    line-height:18px;
    height:40px;
}
.d-flex span:last-child {
    margin-left: 6px !important;
    font-size: 11px !important;
}
}
</style> 


<div class="course-box-bg">
    <div class="col-xl-12 col-md-12">
			<h3 class="sheduletitle"> <span>Course Schedule</span> </h3>
			<div class="table-responsive card-body " style="padding: 0px;" >
		
				<?php
			if(empty($CourseShedule))
				{
				     ?>  
				        <br>
				    	 <h2 class="text-center" style="color:#00aeef;"> 
				    	 Upcoming course schedule will be updated soon
				    	</h2>	
				    <?php	
				}		
			?>
			
			<?php
					if(!empty($CourseShedule))
					{
					?>							
				<table  class="table table-bordered shadow bg-white">
					<thead>
					<tr>
					<th>Enroll </th> 
					<th>Cost <span style="font-size:10px;color:#0000EE;">in <?php
						 if($country=='India')
						{
					      echo "INR";
					      $live_training_total= $row->live_training_total;
						}
						else if($country=='United States')
						{
					     echo "USD"; 
					     	if($row->live_training_total=='')
    						{
    						  $live_training_total=0;
    						}
    						else
    						{
    						  $live_training_total=($row->live_training_total/75);   
    						}
						}
						else if($country=='Canada')
						{
						 echo "CAD";  
						 if($row->live_training_total=='')
    						{
    						  $live_training_total=0;
    						}
    						else
    						{
    						  $live_training_total=($row->live_training_total/53);   
    						}
						}
						else if($country=='United Kingdom')
						{
						 echo "Pound";
						if($row->live_training_total=='')
						{
						  $live_training_total=0;
						}
						else
						{
						  $live_training_total=($row->live_training_total/92);   
						}
						     
						}
						else if($country=='Australian')
						{
						 echo "ADollar";  
						 if($row->live_training_total=='')
    						{
    						  $live_training_total=0;
    						}
    						else
    						{
    						  $live_training_total=($row->live_training_total/49);   
    						}
						}
						else
						{
						 echo "USD"; 
						 if($row->live_training_total=='')
    						{
    						  $live_training_total=0;
    						}
    						else
    						{
    						  $live_training_total=($row->live_training_total/71);   
    						}
						} 
					
					?> </span>
					 </th>
					<th>Trainer</th>
					<th>Date</th>
					<th>Mode </th>
					<th>Week</th>
					<th>Timings</th>
					<th>Duration</th>
					<th>Pattern</th>
					</tr>
					</thead>
					<tbody>
					<?php
		 $ip_address=$_SERVER['REMOTE_ADDR'];
		 $ipInfo = file_get_contents('http://ip-api.com/json/' . $ip_address);
         $ipInfo = json_decode($ipInfo);
         $timezone = $ipInfo->timezone;
         date_default_timezone_set($timezone);
					  foreach($CourseShedule as $row1)
						{
						   $meeting= $row1->meeting;
						    $fromTime= $row1->shedule_timings;
						    $week= $row1->shedule_week;
						     $sdate=$row1->shedule_date;
						     
                        $main=$week.' ,'.$sdate .' '. $fromTime;
                        $dateg = new DateTime($main, new DateTimeZone('Asia/Kolkata'));
                        $dateg->setTimezone(new DateTimeZone($timezone));
                        
                        $weekg = new DateTime($main, new DateTimeZone('Asia/Kolkata'));
                       $weekg->setTimezone(new DateTimeZone($timezone));
                       
                        $date = new DateTime($fromTime, new DateTimeZone('Asia/Kolkata'));
                    $date->setTimezone(new DateTimeZone($timezone));
                    
                    $shedule_mode=$row1->shedule_mode;
                       
             
                            $ip_address=$_SERVER['REMOTE_ADDR'];
                            $ch = curl_init();
                            curl_setopt($ch, CURLOPT_URL, "http://www.geoplugin.net/json.gp?ip=".$ip_address);
                            curl_setopt($ch, CURLOPT_HEADER, 0);
                            curl_setopt($ch, CURLOPT_RETURNTRANSFER, TRUE);
                            $ip_data_in = curl_exec($ch); // string
                            curl_close($ch);
                            
                            $ip_data = json_decode($ip_data_in,true);
                            $ip_data = str_replace('&quot;', '"', $ip_data); 
                            if($ip_data && $ip_data['geoplugin_countryName'] != null) {
                            $city = $ip_data['geoplugin_city'];
                            $country = $ip_data['geoplugin_countryName'];
                            }
                            else
                            {
                                $city ="New York"; 
                                $country ="United States";
                            }
                            $timezone_modify=date(' T');
							?>
						<tr>
						<td>
				<?php
				$registration_id=$this->session->userdata('registration_id');
				$student_name=$this->session->userdata('student_name');
				$student_mobile=$this->session->userdata('student_mobile');
				$student_email=$this->session->userdata('student_email');
					if(empty($student_email))
					{
					?>
					<?php
						if($row1->shedule_mode=='Live Class')
						{
						    
						 ?>
						 <a href="" class="btn btn-primary btn-padding" data-toggle="modal" data-target="#exampleModalCenter">Enroll </a>
						 <?php 	
						}
						else
						{
						?>
						<button type="button" class="btn btn-primary btn-padding " data-toggle="modal" data-target="#exampleModalCenter">
						Enroll
						</button>
						<?php	
						}
					?>
			
					<?php	
					}
					else
					{
					?>
		<form action="<?php echo base_url()?>EnrollWithLogin" method="POST">	
         <?php 	$ip_address=$_SERVER['REMOTE_ADDR'];?>
			<input type="hidden" name="ip_address" value="<?php echo $ip_address;?>">
             <input type="hidden" name="shedule_id" value="<?php echo $row1->shedule_id;?>">
				<input type="hidden" name="trainer" value="<?php echo $row1->trainer;?>">
				<input type="hidden" name="duration" value="<?php echo $row1->duration;?>">		
			<input type="hidden" name="pattern" value="<?php echo $row1->pattern;?>">
					<input type="hidden" name="shedule_date" value="<?php echo $dateg->format('M j Y'); ?>">
					<input type="hidden" name="year" value="<?php echo $dateg->format('Y'); ?>">
				    <input type="hidden" name="month" value="<?php echo $dateg->format('M'); ?>">
					<input type="hidden" name="shedule_week" value="<?php echo $weekg->format('l'); ?>">
					<input type="hidden" name="shedule_timings" value="<?php echo $date->format('h:i A'); echo $timezone_modify; ?>">
					
					<input type="hidden" name="shedule_mode" value="<?php echo $shedule_mode; ?>">
					
					<input type="hidden" name="meeting" value="<?php  if(empty($meeting)){echo "Not Available";}else{echo $meeting;}?>">

					<input type="hidden" name="course_id" value="<?php echo $row->course_id;?>">
					<input type="hidden" name="course_name" value="<?php echo $row->course_name;?>">
					<input type="hidden" name="url" value="<?php echo base_url()?>CourseDetails/<?php echo $course_name;?>">
                	<input type="hidden" name="batchid" value="<?php echo $row1->batchid;?>">
					<input type="hidden" name="name" value="<?php echo $student_name;?>">
					<input type="hidden" name="email" value="<?php echo $student_email;?>">
					<input type="hidden" name="mobile" value="<?php echo $student_mobile;?>">
					<?php
					$disbled=$this->db->where('shedule_id',$row1->shedule_id)->where('email',$student_email)
						->get('enroll');
						if($disbled->num_rows()>0)
						{
							?>
							<span style="color:green;"> <?php echo "Enrolled";?> </span>
							<?php		
						}	
						else
						{
						if($row1->shedule_mode=='Live Demo')
							{
							 ?>
							<input type="submit"  class="btn btn-primary btn-padding" value="Enroll" class="enroll" >
							 <?php 	
							}
						}
					?>
					</form>
					<?php	
						if($disbled->num_rows()>0)
						{}	
						else
						{
						if($row1->shedule_mode=='Live Class')
							{
							    
                            $this->db->select('payment.*, payment_status.*');
                            $this->db->from('payment');
                            $this->db->join('payment_status', 'payment_status.transaction_id = payment.transaction_id');
                            $this->db->where('payment.course_name',$row->course_name);
                            $this->db->where('payment.email',$student_email);
                            $this->db->where('payment_status.status','success');
                            $LiveRows=$this->db->get();
                            if($LiveRows->num_rows()>0)
                            {
                             ?>
                             <b style="color:green;">Enrolled</b>
                             <?php   
                            }
                            else
                            {
                              ?>
                              <form action="<?php echo base_url()?>payment" method="POST">
                            <input type="hidden" value="Live Training" name="mode">	
                            <input type="hidden" value="<?php echo $row1->shedule_id;?>" name="shedule_id">		 	
                            <input type="hidden" name="course_id" value="<?php echo $row->course_id;?>">
                            <button type="submit" class="btn btn-primary btn-padding">Enroll  </button>		
                            </form>
                              <?php
                            }
							  	
							}
					   	}
					}	
				?> 
			</td>      
			    <td class="fw-700">
						<?php 
							if($shedule_mode=='Live Demo')
							{
								echo "Free";
							}
							else if($shedule_mode=='Live Class')
							{
							?><b style="color: #0000EE; font-size:18px;">
							<?php  echo  round($live_training_total, 0); ?></b><?php 
							}
						?>
						</td>
			 	<td> 
				<?php 
				$sqlTrainer=$this->db->where('trainer',$row1->trainer)
				->where('course_name',$row->course_name)
				->get('trainer');
				foreach ($sqlTrainer->result() as $TraRow) {
					?>
				<a href="#" style="color:#0000EE;font-size:16px;text-decoration:underline; " data-toggle="modal" data-target="#Trainer<?php echo $TraRow->id;?>"> <b><?php echo $TraRow->trainer;?> 	</b></a>
			 <div class="sign_up_modal modal fade" id="Trainer<?php echo $TraRow->id;?>" tabindex="-1" role="dialog" aria-hidden="true">
	  	     <div class="modal-dialog modal-dialog-centered" role="document">
	    	  <div class="modal-content ">
		      	<div class="modal-header">
		        	<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		      	</div>
	    		<ul class="sign_up_tab nav nav-tabs" id="myTab" role="tablist">
				  	<li class="nav-item">
				    	<a class="nav-link active" id="home-tab" data-toggle="tab" href="#home<?php echo $TraRow->id;?>" role="tab" aria-controls="home" aria-selected="true">Trainer Profile</a>
				  	</li>
				  	<li class="nav-item">
				    	<a class="nav-link" id="profile-tab" data-toggle="tab" href="#profile<?php echo $TraRow->id;?>" role="tab" aria-controls="profile" aria-selected="false">Rating and Review</a>
				  	</li>
				</ul>
				<div class="tab-content trainer-popupfixed" id="myTabContent">
				  	<div class="tab-pane fade show active" id="home<?php echo $TraRow->id;?>" role="tabpanel" aria-labelledby="home-tab">
							<div class="row">
								<div class="col-md-4 col-xl-4 col-4">
									<center>
										<img src="<?php echo base_url()?>assets/images/resource/review1.png" class="mt5" alt="review">  
									</center>
								</div>
								<div class="col-md-6 col-8 text-left mt5">
								<div class="trainer-name">
								<b>Trainer Name : <?php echo ucfirst($TraRow->trainer);?></b>
								</div>
								<div class="trainer-skill">
							     <b>Trainer Skill Set: <?php echo $row->course_name;?> 
							     </b>
								</div>
								</div>	
							</div>
							<hr>
							<div style="padding:0 5px;">
								<div class="pop-content-trainer">
								<div class="card bg-light text-dark" style="border-radius: 0px;">	
								<?php echo $TraRow->summery;?>
								</div>
							  </div>
							</div>
				     	      <div class="row" style="padding:0 3px;">
				     				<?php
				     				 if(!empty($TraRow->demo_link1))
				     				 {
				     				 	?>
										<div class="col-xl-4 col-4">
										<b> Sample Session 1:</b>
										<iframe width="100%" height="150" src="<?php echo $TraRow->demo_link1;?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
										</div>	
				     				 	<?php
				     				 }
				     				  if(!empty($TraRow->demo_link2))
				     				  {
				     				  	?>
										<div class="col-xl-4 col-4">
										<b> Sample Session 2:</b>
										<iframe width="100%" height="150" src="<?php echo $TraRow->demo_link2;?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
										</div>
				     				  	<?php
				     				  }
				     				  if(!empty($TraRow->demo_link3))
				     				  {
				     				  	?>
										<div class="col-xl-4 col-4">
										<b> Sample Session 3:</b>
										<iframe width="100%" height="150" src="<?php echo $TraRow->demo_link3;?>" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe>
										</div>
				     				  	<?php
				     				  }
				     				?>
				     		</div>	
				  	</div>
				  	<div class="tab-pane fade" id="profile<?php echo $TraRow->id;?>" role="tabpanel" aria-labelledby="profile-tab">
				  		<div style="background: #dddddd; padding:0 10px;">
				  			<?php
				     			$TraReview=$this->db->where('course_id',$row->course_id)
				     			->where('trainer',$TraRow->trainer)
				     			->where('review_type','Trainer Review')
				     			->where('approvel','Approved')
				     			->get('course_review');
				     			 	foreach ($TraReview->result() as $TraRev) {
				     				$CanLocation=$this->db->where('email',$TraRev->email)
				     				->get('registration');
				     				foreach ($CanLocation->result() as $locaAdd) {	
				     					?>
				     					<div class="card pl5 pr5 pt10 mt5" style="border: 1px solid #000;">
				     						<div class="row">
				     							<div class="col-xl-2 col-3">
													<div class="text-center">
													<div style="height:50px; width:50px; background-color:#00AEEF;border-radius:50%; line-height:45px; font-weight: bold; font-size: 25px;">
													<div class="text-white">
													<?php echo substr($TraRev->name, 0, 2);?>
													</div>
													</div>
													</div>
				     							</div>
				     							<div class="col-xl-7 col-6">
												<div class="text-left">
												<h3>
													Name: <?php echo $TraRev->name;?>
												</h3>
											  </div>
												<div class="text-left">
												<?php echo $locaAdd->iso;?>,<?php echo $locaAdd->location;?>		
												</div>	
				     							</div>
				     							<div class="col-xl-3 col-3">
				     								<?php
													if($TraRev->rating==1)
													{
													 ?>
													 <i class="fa fa-star"></i>
													 <?php		
													}
													if($TraRev->rating==2)
													{
													 ?>
													 <i class="fa fa-star"></i>
													  <i class="fa fa-star"></i>
													 <?php		
													}
													if($TraRev->rating==3)
													{
													 ?>
													 <i class="fa fa-star"></i>
													  <i class="fa fa-star"></i>
													  <i class="fa fa-star"></i>
													 <?php	
													}
													if($TraRev->rating==4)
													{
													 ?>
													 <i class="fa fa-star"></i>
													  <i class="fa fa-star"></i>
													  <i class="fa fa-star"></i>
													    <i class="fa fa-star"></i>
													 <?php	
													}
													if($TraRev->rating==5)
													{
													 ?>
													 <i class="fa fa-star"></i>
													  <i class="fa fa-star"></i>
													  <i class="fa fa-star"></i>
													    <i class="fa fa-star"></i>
													    <i class="fa fa-star"></i>
													 <?php
													}	
												?>
				     							</div>
				     							<div class="col-xl-2 col-3"> </div>
				     							<div class="col-xl-10 col-9 text-center">
				     							<p align="justify"> 
				     								<?php echo $TraRev->review;?>
				     							</p>
				     							</div>
				     						</div>
				     						
				     					</div>	

				     		<?php
				    	  }
				    	 }
				     	?> 	 
     				 	</div>
				  	</div>
				</div>
	    	</div>
	  	</div>
	</div>
<?php
}
?>
 </td>
			    <td> <?php echo $dateg->format('M j Y');?> </td>
				<td class="fw-700"><?php echo $shedule_mode=$row1->shedule_mode;?></td>
				
						<td>
						<?php   echo $weekg->format('l');?>
						</td>
						<td>
						<?php
				echo $date->format('h:i A'); echo $timezone_modify=date(' T');
						?>
						</td>
						<td><?php echo $row1->duration;?> </td>
					<td>
						<?php echo $row1->pattern;?> 
					</td>
		             </tr>
		     <?php
	    	}
		?>	
</tbody> 
</table>
<?php
}?>
</div>	

<?php
	$sqlRes=$this->db->where('course_name',$row->course_name)
	->where('email',$student_email)
	->where('schedule_mode','Live Demo')
	->where('schedule_mode','Live Class')
	->get('request_schedule');
	$total_res=$sqlRes->num_rows();
	if($total_res>0)
	{
	 	?>
			<h5 class="text-center"> <?php  echo "Reschedule already ";?></h5>
		<?php	
	}
	else
	{
	?>
                	<div class="text-center mt10">Would you like to make your own schedule? <a href="" data-toggle="modal" data-target="#exampleModalSchedule" class="course-text-color"> <b>Reschedule </b> </a> 
                       
                	</div>
                	<?php	
                	}
                ?>
                </div>    
                </div>
                
<style>

.modes {
    background: #fff;
    box-shadow: 0 2px 8px 0 rgba(0,0,0,.1);
    border-radius: 0px;
    padding: 0 10px;
    display: inline-block;
    height: 340px;
    position: relative;
    margin-top:10px;
    padding-bottom:20px;
    width: 100%;
    border:1px solid #eee; 
    margin-bottom:10px;
}	
.modes:hover {
  box-shadow: 0 11px 28px rgba(0,0,0,0.25), 0 10px 10px rgba(0,0,0,0.22);
}
.mode-title
{
	margin: 15px 0 10px;
	width: 100%;
	/*background-color:#00aeef;*/	
	padding:10px 0 1px;
	 box-shadow: 0 2px 8px 0 rgba(0,0,0,.1);
	background: linear-gradient(90deg,#776ee4 0,#00aeef 100%);
	border-radius: 0;
}
.modes h5 {
    color: #ffffff;
    text-align: center;
	font-weight: 600;
	font-size: 18px;
	line-height: 30px;
	margin-bottom: 5px;
}
.d-flex span:last-child {
	margin-left: 10px;
	font-size: 16px;
	font-weight: 500;
}
.strikeprice
{
 color:#2874f0;
}
.dis-mode
{
 color:#2874f0;	
}
.price_quere_list
{
 margin-top: 10px;
}
.totalamt b
{
font-size:21px;	
}
.bg-white
{
	background: #ffffff !important;
	box-shadow: 0 0 5px 0 rgba(0,0,0,0.1);
	
}
</style>                
                
 <div class="course-box-bg">
        <div class="row">
        	<div class="col-md-12">
        		<h3>Choose the best training mode which suits to your requirement </h3>
        	</div>
        		<?php
        		
					if($country=='India')
						{
						    $sym="INR";
						    $live_amount = $row->live_training_amount;
							$live_total = $row->live_training_total;
							$mentor_amount = $row->mentoring_training_amount;
							$mentor_total = $row->mentoring_training_total;
							$self_amount = $row->self_training_amount;
							$self_total = $row->self_training_total;
						}
						else if($country=='United States')
						{
					        $sym="USD"; 
					        if($row->live_training_total>0)
					        {
					            	$live_amount =( $row->live_training_amount/75);
							        $live_total =( $row->live_training_total/75);
					        }
					        else
					        {
				            	$live_amount =$row->live_training_amount;
					        	$live_total =$row->live_training_total;
					        }
					        
					        if($row->mentoring_training_total>0)
					        {
					            $mentor_amount =( $row->mentoring_training_amount/75);
							    $mentor_total = ($row->mentoring_training_total/75);
					        }
					        else
					        {
					            $mentor_amount =$row->mentoring_training_amount;
							    $mentor_total =$row->mentoring_training_total;
					        }
					        
					        if($row->self_training_total>0)
					        {
					            
							     $self_amount =( $row->self_training_amount/75);
							    $self_total = ($row->self_training_total/75); 
					        }
					        else
					        {
					           $self_amount = $row->self_training_amount;
							    $self_total =$row->self_training_total; 
					        }
					        
						}
						else if($country=='Canada')
						{
						    $sym="CAD";   
						    
						    if($row->live_training_total>0)
					        {
					            	$live_amount =( $row->live_training_amount/53);
							        $live_total =( $row->live_training_total/53);
					        }
					        else
					        {
				            	$live_amount =$row->live_training_amount;
					        	$live_total =$row->live_training_total;
					        }
					        
					        if($row->mentoring_training_total>0)
					        {
					            $mentor_amount =( $row->mentoring_training_amount/53);
							    $mentor_total = ($row->mentoring_training_total/53);
					        }
					        else
					        {
					            $mentor_amount =$row->mentoring_training_amount;
							    $mentor_total =$row->mentoring_training_total;
					        }
					        
					        if($row->self_training_total>0)
					        {
					            
							     $self_amount =( $row->self_training_amount/53);
							    $self_total = ($row->self_training_total/53); 
					        }
					        else
					        {
					           $self_amount = $row->self_training_amount;
							    $self_total =$row->self_training_total; 
					        }

						}
						else if($country=='United Kingdom')
						{
						  $sym="Pound";
						  if($row->live_training_total>0)
					        {
					            	$live_amount =( $row->live_training_amount/92);
							        $live_total =( $row->live_training_total/92);
					        }
					        else
					        {
				            	$live_amount =$row->live_training_amount;
					        	$live_total =$row->live_training_total;
					        }
					        
					        if($row->mentoring_training_total>0)
					        {
					            $mentor_amount =( $row->mentoring_training_amount/92);
							    $mentor_total = ($row->mentoring_training_total/92);
					        }
					        else
					        {
					            $mentor_amount =$row->mentoring_training_amount;
							    $mentor_total =$row->mentoring_training_total;
					        }
					        
					        if($row->self_training_total>0)
					        {
					            
							     $self_amount =( $row->self_training_amount/92);
							    $self_total = ($row->self_training_total/92); 
					        }
					        else
					        {
					           $self_amount = $row->self_training_amount;
							    $self_total =$row->self_training_total; 
					        }
						  
						  
						}
						else if($country=='Australian')
						{
						  $sym="ADollar";  
						  
						  if($row->live_training_total>0)
					        {
					            	$live_amount =( $row->live_training_amount/49);
							        $live_total =( $row->live_training_total/49);
					        }
					        else
					        {
				            	$live_amount =$row->live_training_amount;
					        	$live_total =$row->live_training_total;
					        }
					        
					        if($row->mentoring_training_total>0)
					        {
					            $mentor_amount =( $row->mentoring_training_amount/49);
							    $mentor_total = ($row->mentoring_training_total/49);
					        }
					        else
					        {
					            $mentor_amount =$row->mentoring_training_amount;
							    $mentor_total =$row->mentoring_training_total;
					        }
					        
					        if($row->self_training_total>0)
					        {
					            
							     $self_amount =( $row->self_training_amount/49);
							    $self_total = ($row->self_training_total/49); 
					        }
					        else
					        {
					           $self_amount = $row->self_training_amount;
							    $self_total =$row->self_training_total; 
					        }
						  
						}
						else
						{
						   $sym="USD"; 
						    if($row->live_training_total>0)
						    {
						        $live_amount =($row->live_training_amount/71);
							    $live_total =($row->live_training_total/71);
						    }
						    else
						    {
						       $live_amount =$row->live_training_amount;
							   $live_total =$row->live_training_total; 
						    }
						    
						    if($row->mentoring_training_amount>0)
						    {
						        $mentor_amount =( $row->mentoring_training_amount/71);
							    $mentor_total = ($row->mentoring_training_total/71);
						    }
						    else
						    {
						        $mentor_amount =$row->mentoring_training_amount;
							    $mentor_total =$row->mentoring_training_total;
						    }
						    
						    if($row->self_training_amount>0)
						    {
						        $self_amount =($row->self_training_amount/71);
							    $self_total = ($row->self_training_total/71);   
						    }
						    else
						    {
						        $self_amount =$row->self_training_amount;
							    $self_total =$row->self_training_total;    
						    }
							   	
						} 
					?> 
			<div class="col-md-4 pl5 pr5">
        		<div class="modes">    
                  <div class="mode-title"> <h5> Live online training</h5> </div>
                	 <div class="row mt5">
					   <?php 
						 if(!$live_total=='' or !$live_total=='0')
							{
							  ?>
							<div class="col-md-4 col-4">
							Training Fee:
							</div>
							<div class="col-md-3 col-3">
								<span class="sub-price strikeprice">
								<b>
								<?php echo $sym.'&nbsp;'.round($live_amount,1); ?>
								</b>
								</span>
							</div>
							<div class="col-md-5 col-5">
								<span class="dis-mode">
							<?php
								if(!$row->live_training_discount=='' or !$row->live_training_discount=='0')
								{
								echo $row->live_training_discount; 
								echo "% Discount";
								}
							?></span>
							</div>
							<div class="col-md-12 text-center totalamt">
								<b>
								<?php  echo $sym.'&nbsp;'.round($live_total,1); ?> 
								</b>
								</div>
							  <?php	
							}
						 ?> 
        	       </div>
					<ul class="price_quere_list text-left ">
							<li class="d-flex"><span><i class="fa fa-check-circle" ></i> </span><span> Live interactive online training </span></li>
							<li class="d-flex"><span><i class="fa fa-check-circle" ></i> </span><span> Daily Assignments and Lab exercises</span></li>
							<li class="d-flex"><span><i class="fa fa-check-circle" ></i> 
							</span><span> Resume and certification guidance </span></li>
							<li class="d-flex"><span><i class="fa fa-check-circle" ></i> </span><span> Mock interview and live project assistance  </span> </li>
							<li class="d-flex"><span><i class="fa fa-check-circle"></i></span><span>Resume marketing and job assistance</span></li>
						</ul> 
					<center>  
                 <?php
                	$student_email=$this->session->userdata('student_email');
                    if($live_total=='' or $live_total=='0')
                	 {}
                    else if($student_email=='')
                	 {
                	 	?>
                	 	 <a href="" class="cart_btnss" data-toggle="modal" data-target="#exampleModalCenter">Enroll Now</a>
                	 	<?php
                	 }
                    else
                    {
                    	?>
                    	  <form action="<?php echo base_url()?>payment" method="POST">
                        <input type="hidden" name="course_id" value="<?php echo $row->course_id;?>">
                      	<input type="hidden" value="Live Training" name="mode">	
                        <?php
						$this->db->select('payment_status.*, payment.*');
						$this->db->from('payment_status');
						$this->db->join('payment', 'payment.transaction_id = payment_status.transaction_id');
						$this->db->group_by('payment.course_name');
						$this->db->where('payment.course_name',$row->course_name);
						$this->db->where('payment.email',$student_email);
						$this->db->where('payment_status.status','success');
						$this->db->where('payment.mode','Live Training');
						$Liverow = $this->db->get();
						if($Liverow->num_rows()>0)
						{
							echo "Enrolled";
						}
						else
						{
						?>
						 <button type="submit"  class="cart_btnss">Enroll Now </button>
						<?php
						}
                        ?>
						</form>
                      <?php
                      }
					?>	

                     </center>     
                 </div>
        	</div>	
        	<div class="col-md-4 pl5 pr5">
        		<div class="modes">    
                <div class="mode-title"> <h5>Mentoring mode training</h5> </div>
                 <div class="row mt5">
					   <?php 
						 if(!$mentor_total=='' or !$mentor_total=='0')
							{
							  ?>
							<div class="col-md-4 col-4">
							Training Fee:
							</div>
							<div class="col-md-3 col-3">
								<span class="sub-price strikeprice">
								<b>
								<?php echo $sym.'&nbsp;'.round($mentor_amount,1); ?>
								</b>
								</span>
								
							</div>
							<div class="col-md-5 col-5">
								<span class="dis-mode">
								<?php
									if(!$row->mentoring_training_discount=='' or !$row->mentoring_training_discount=='0')
									{
									echo $row->mentoring_training_discount; 
									echo "% Discount";
									}
								?>
					    	</span> 
							</div>
							 <div class="col-md-12 text-center totalamt">
								<b>
								<?php  echo $sym.'&nbsp;'.round($mentor_total,1); ?> 
								</b>
								</div>
							  <?php	
							}
						 ?> 
        	       </div>
					   <ul class="price_quere_list text-left">
							<li class="d-flex"><span><i class="fa fa-check-circle" ></i> </span><span> Recorded videos and Trainer support </span></li>
							<li class="d-flex"><span><i class="fa fa-check-circle" ></i> </span><span> Topic wise assignments and lab exercises </span></li>
							<li class="d-flex"><span ><i class="fa fa-check-circle" ></i> </span><span> Resume and certification guidance</span></li>
							<li class="d-flex"><span><i class="fa fa-check-circle" ></i> 
							</span><span>Mock interview and live project assistance </span></li>
							<li class="d-flex"><span><i class="fa fa-check-circle" ></i> </span><span> Resume marketing and job assistance </span> </li>
						</ul>  
					<center>         
					<?php
                	$student_email=$this->session->userdata('student_email');
                    if($mentor_total=='' or $mentor_total=='0')
                	 {}
                   else if($student_email=='')
                	 {
                	 	?>
                	 	 <a href="" class="cart_btnss" data-toggle="modal" data-target="#exampleModalCenter">Enroll Now</a>
                	 	<?php
                	 }
                    else
                    {
                    	?>
                    	  <form action="<?php echo base_url()?>payment" method="POST">
                        <input type="hidden" name="course_id" value="<?php echo $row->course_id;?>">
                        <input type="hidden" value="Mentoring Training" name="mode">
                        <?php
						$this->db->select('payment_status.*, payment.*');
						$this->db->from('payment_status');
						$this->db->join('payment', 'payment.transaction_id = payment_status.transaction_id');
						$this->db->group_by('payment.course_name');
						$this->db->where('payment.course_name',$row->course_name);
						$this->db->where('payment.email',$student_email);
						$this->db->where('payment_status.status','success');
						$this->db->where('payment.mode','Mentoring Training');
						$mentorow = $this->db->get();
						if($mentorow->num_rows()>0)
						{
							echo "Enrolled";
						}
						else
						{
						?>
						 <button type="submit"  class="cart_btnss">Enroll Now </button>
						<?php
						}
                        ?>
						</form>
                      <?php
                      }
					?>	
                    </center>     
                 </div>
        	</div>
        	<div class="col-md-4 pl5 pr5">
        		<div class="modes">    
                 <div class="mode-title"><h5>Live online training and internship</h5> </div>
                 <div class="row mt5">
        	          	<?php 
						 if(!$self_total=='' or !$self_total=='0')
							{
							  ?>
							<div class="col-md-4 col-4">
							Training Fee:
							</div>
							<div class="col-md-3 col-3">
								<span class="sub-price strikeprice">
								<b>
								<?php echo $sym.'&nbsp;'.round($self_amount,1); ?>
								</b>
								</span>
								<div class="text-center totalamt">
								<b>
								<?php  echo $sym.'&nbsp;'.round($self_total,1); ?> 
								</b>
								</div>
							</div>
							<div class="col-md-5 col-5">
							 <span class="dis-mode">
								<?php
									if(!$row->mentoring_training_discount=='' or !$row->mentoring_training_discount=='0')
									{
										echo $row->mentoring_training_discount; 
										echo "% Discount";
									}
								?>
							</span>
							</div>
							  <?php	
							}
						 ?> 
						</div>
					<ul class="price_quere_list text-left">
						<li class="d-flex"><span><i class="fa fa-check-circle" ></i> </span> <span>Recorded videos and Trainer support</span></li>	
						<li class="d-flex"><span><i class="fa fa-check-circle" ></i> </span><span>Daily assignments and lab exercises</span>
						</li>
						<li class="d-flex"><span><i class="fa fa-check-circle" ></i> 
						</span><span>Resume and certification guidance </span></li>
						<li class="d-flex"><span><i class="fa fa-check-circle" ></i> </span><span> Project internship and certification </span> </li>
				    	<li class="d-flex"><span><i class="fa fa-check-circle" ></i> </span><span> Resume marketing and job assistance </span> </li>
						</ul>
					<center>  
				   <?php
                	$student_email=$this->session->userdata('student_email');
                    if($self_amount=='' or $self_amount=='0')
                	 {}
                   else if($student_email=='')
                	 {
                	 	?>
                	 	 <a href="" class="cart_btnss" data-toggle="modal" data-target="#exampleModalCenter">Enroll Now</a>
                	 	<?php
                	 }
                    else
                    {
                    	?>
                    	  <form action="<?php echo base_url()?>payment" method="POST">
                        <input type="hidden" name="course_id" value="<?php echo $row->course_id;?>">
                       <input type="hidden" value="Self Paced Training" name="mode">
                        <?php
						$this->db->select('payment_status.*, payment.*');
						$this->db->from('payment_status');
						$this->db->join('payment', 'payment.transaction_id = payment_status.transaction_id');
						$this->db->group_by('payment.course_name');
						$this->db->where('payment.course_name',$row->course_name);
						$this->db->where('payment.email',$student_email);
						$this->db->where('payment_status.status','success');
						$this->db->where('payment.mode','Self Paced Training');
						$selfrow = $this->db->get();
						if($selfrow->num_rows()>0)
						{
							echo "Enrolled";
						}
						else
						{
						?>
						 <button type="submit"  class="cart_btnss">Enroll Now </button>
						<?php
						}
                        ?>
						</form>
                      <?php
                      }
					?>	
                   </center>     
                 </div>
        	</div>   
        	<div> 	
        </div>
 
						<div class="row">
						<div class="col-lg-12">
							<div class="courses_single_container">
                                <?php
                                if(!empty($CourseSyllabus))
                                {
                                 ?>
                                 	<div class="cs_row_three course-box-bg">
									<div class="course_content" >
										<div class="row">
											<div class="col-md-9 col-8">
											<div class="cc_headers">
											<h4 class="title">Course Content</h4>
										</div>
										</div>
										<div class="col-md-3 col-4">
											<?php
												if(empty($student_email))
												{
												?>
												<a href="<?php echo $row->download_pdf;?>"data-toggle="modal" data-target="#exampleModalCenter" class="course-text-color"> Download <img src="<?php echo base_url()?>assets/images/about/pdf.png"> </a>
												<?php	
												}	
												else
												{
													?>
													<a href="<?php echo $row->download_pdf;?>"  target="_blank" > Download <img src="<?php echo base_url()?>assets/images/about/pdf.png" > </a>
													<?php			
												}
											?>	
										
										</div>
										</div>	
										
										
							<?php
							$c=0;
							$syllabus_id=0;
						     foreach ($CourseSyllabus as $row4) {
								if($c==5)
								break;
							?>
							<div class="details">
							<div id="accordion" class="panel-group cc_tab">
							<div class="panel">
							<div class="panel-heading">
							<h4 class="panel-title">
							<a href="#panelBodyCourseType<?php echo $row4->syllabus_id;?>" class="accordion-toggle link" data-toggle="collapse" data-parent="#accordion">
							<?php echo $row4->Syllabus_title;?></a>
							</h4>
							</div>
							<div id="panelBodyCourseType<?php echo $row4->syllabus_id;?>" class="panel-collapse collapse">
							<div class="panel-body">
							<?php echo $row4->Syllabus_topics;?>
							</div>
							</div>
							</div>
							</div>
							</div>
							<?php
								$c++;
								$syllabus_id=$row4->syllabus_id;
							  }
							?>
							
						
							<div id="CourseContentHide">
							<?php
							$coucmore=$this->db->where('course_id',$row->course_id)
							->where('syllabus_id>',$syllabus_id)
							->get('syllabus_course');
						     foreach ($coucmore->result() as $Morerow4) {
							?>
							<div class="details" id="CourseContentHide">
							<div id="accordion" class="panel-group cc_tab">
							<div class="panel">
							<div class="panel-heading">
							<h4 class="panel-title">
							<a href="#panelBodyCourseType<?php echo $Morerow4->syllabus_id;?>" class="accordion-toggle link" data-toggle="collapse" data-parent="#accordion">
							<?php echo $Morerow4->Syllabus_title;?></a>
							</h4>
							</div>
							<div id="panelBodyCourseType<?php echo $Morerow4->syllabus_id;?>" class="panel-collapse collapse">
							<div class="panel-body">
							<?php echo $Morerow4->Syllabus_topics;?>
							</div>
							</div>
							</div>
							</div>
							</div>
							<?php
								}
							?>
					       </div>
					       <div  id="CourseContentShow" class="text-right">
								<button class="btn btn-primary white-text">
								<< Show More >>
								</button>
							</div>	
							<div id="CourseContentless" class="text-right">
								<button class="btn btn-primary white-text">
								<< Show Less >>
								</button>
							</div>	
					     
                	 	</div>
                	  </div>
                         <?php   
                        }
                        ?>
							
                                <?php
                                if(!empty($FAQs))
                                    {
                                    ?>
                                   <div class="cs_row_three course-box-bg col-xl-12">
									<div class="course_content">
										<div class="row">
											<div class="col-md-12">
											<div class="cc_headers">
											<h4 class="title"><?php echo $row->course_name;?> Training FAQs</h4>
											<span class="title pull-right course-text-color">
											<?php
											if(!empty($row->download_pdf))
												{
												?>
												Download <?php
												if(empty($student_email))
												{
												?>
												<a href="<?php echo $row->download_pdf;?>"   data-toggle="modal" data-target="#exampleModalCenter">  <img src="<?php echo base_url()?>assets/images/about/pdf.png"> </a>
												<?php	
												}	
												else
												{
													?>
													<a href="<?php echo $row->faq_pdf;?>" class="course-text-color" target="_blank" >  <img src="<?php echo base_url()?>assets/images/about/pdf.png"> </a>
													<?php			
												}
												?>	
												<?php   
												}
											?>
											</span> 
										</div>
										</div>
										</div>	
										
										<?php
										$e=0;
										$faq_id=0;
										foreach ($FAQs as $FAQsrow) {
											if($e==5)
												break;
											?>
										<div class="details">
										  <div id="accordion" class="panel-group cc_tab">
											    <div class="panel">
											      	<div class="panel-heading">
												      	<h4 class="panel-title">
												        	<a href="#panelBodyCourseFAQs<?php echo $FAQsrow->faq_id;?>" class="accordion-toggle link" data-toggle="collapse" data-parent="#accordion">
												       <?php echo $FAQsrow->faq_title;?></a>
												        </h4>
											      	</div>
									<div id="panelBodyCourseFAQs<?php echo $FAQsrow->faq_id;?>" class="panel-collapse collapse">
									  <div class="panel-body">        	
									<?php echo $FAQsrow->description;?>
												   </div>
												  </div>
											    </div>
											</div>
										</div>
										<?php
										$e++;
										$faq_id=$FAQsrow->faq_id;
									    }
									?>
							<div id="FaqContentHide">
							<?php
						$FaqMore=$this->db->where('course_id',$row->course_id)
						->where('faq_id>',$faq_id)
						->get('faq_course');
							foreach ($FaqMore->result() as $FAQsrow) {
							?>
							<div class="details">
							<div id="accordion" class="panel-group cc_tab">
							<div class="panel">
							<div class="panel-heading">
							<h4 class="panel-title">
							<a href="#panelBodyCourseFAQs<?php echo $FAQsrow->faq_id;?>" class="accordion-toggle link" data-toggle="collapse" data-parent="#accordion">
							<?php echo $FAQsrow->faq_title;?></a>
							</h4>
							</div>
							<div id="panelBodyCourseFAQs<?php echo $FAQsrow->faq_id;?>" class="panel-collapse collapse">
							<div class="panel-body">        	
							<?php echo $FAQsrow->description;?>
							</div>
							</div>
							</div>
							</div>
							</div>
							<?php
							}
							?>
							</div>
								<div  id="FaqContentShow" class="text-right">
									<button class="btn btn-primary white-text">
									<< Show More >>
									</button>
								</div>	
								<div id="FaqContentless" class="text-right">
									<button class="btn btn-primary white-text">
									<< Show Less >>
									</button>
								</div>
								  </div>
								 </div>
                                    <?php    
                                    }                                
                                ?>
						
                            <script>
							$(document).ready(function(){
							   $("#CourseContentHide").hide();
							    $("#CourseContentless").hide();
							  $("#CourseContentShow").click(function(){
							    $("#CourseContentHide").show();
							     $("#CourseContentless").show();
							     $("#CourseContentShow").hide();
							  });
							  $("#CourseContentless").click(function(){
							    $("#CourseContentHide").hide();
							     $("#CourseContentless").hide();
							     $("#CourseContentShow").show();
							  });
							});

							$(document).ready(function(){
							   $("#FaqContentHide").hide();
							   $("#FaqContentless").hide();
							  $("#FaqContentShow").click(function(){
							    $("#FaqContentHide").show();
							    $("#FaqContentless").show();
							     $("#FaqContentShow").hide();
							  });
							   $("#FaqContentless").click(function(){
							    $("#FaqContentHide").hide();
							    $("#FaqContentless").hide();
							     $("#FaqContentShow").show();
							  });

							});

							$(document).ready(function(){
							   $("#CertificatetHide").hide();
							   $("#CertiContentless").hide();
							  $("#CertiContentShow").click(function(){
							    $("#CertificatetHide").show();
							    $("#CertiContentless").show();
							     $("#CertiContentShow").hide();
							  });
							   $("#CertiContentless").click(function(){
							    $("#CertificatetHide").hide();
							    $("#CertiContentless").hide();
							     $("#CertiContentShow").show();
							  });
							});
						</script>

								<?php
								    if(empty($ReviewRow->rating))
								    {}
								    else
								    {
								    ?>
								<div class="titletext-line">
									<h3 class="sectitle"><?php echo $row->course_name;?>   Reviews</h3>
									<span class="crossline"></span>
								</div>
								    <?php    
								    }
								?>
							
							</div>
						</div>
                     </div>
                </div>	
          </div>               
            
		   </div>
	</section>

<section class="review_wrapper" >
    <div class="container">
			<div class="col-lg-12">
				<h3 class="r_course_title mt5">Related Courses</h3>
			</div>
			<div class="row">
				<div class="col-lg-12">
					<div class="popular_course_slider_home3">
					<?php
							$sql3=$this->db->where('category_id',$row->category_id)
							->get('course');	
							foreach ($sql3->result() as $row3) {
						$course_name3=str_replace(" ","-",$row3->course_name);
						if($country=='India')
						{
					      $sym="INR";
					      $relate_training_total= $row3->live_training_total;
					      $relate_training_amount= $row3->live_training_amount;
						}
						else if($country=='United States' && $row3->live_training_total>0)
						{
					      $sym="USD";
					      $relate_training_total= $row3->live_training_total/75;
					      $relate_training_amount= $row3->live_training_amount/75;
						}
						else if($country=='Canada' && $row3->live_training_total>0)
						{ 
						  $sym="CAD";
					      $relate_training_total= $row3->live_training_total/53;
					      $relate_training_amount= $row3->live_training_amount/53;
						}
						else if($country=='United Kingdom' && $row3->live_training_total>0)
						{
						  $sym="CAD";
					      $relate_training_total= $row3->live_training_total/92;
					      $relate_training_amount= $row3->live_training_amount/92;
						     
						}
						else
						{
						  $sym="USD";
						  if($row3->live_training_total>0)
						  {
						      $relate_training_total= $row3->live_training_total/71;
					          $relate_training_amount= $row3->live_training_amount/71;
						  }
						  else
						  {
						      $relate_training_total= $row3->live_training_total;
					          $relate_training_amount= $row3->live_training_amount;
						  }
					      
						} 
						?>
						<div class="item">
							<div class="top_courses mb0">
								<a href="<?php echo base_url()?>CourseDetails/<?php echo $course_name3;?>"> 
            					<div class="discount-box">
            					<div class="discount-box-img">	
            					<img src="<?php echo $row3->course_image?>" alt="<?php echo $row3->course_name?>">
            					</div>
	            				<div class="iUmrbN"><?php echo $row3->course_name?></div>
	            				<div class="text-right">
	            			
	            			   </div>
	            				<div class="M_qL_C"><span class="main-price"><?php echo $sym;?> <?php echo round($relate_training_total, 0);?> </span> &nbsp;&nbsp;<span class="sub-price"><?php echo $sym;?> <?php echo round($relate_training_amount, 0);?></span></div>
	            				<div style="width:100%;">
	            			    <?php
	            			    	if(!$row3->live_hours=='')
	            			    	{
	            			    	?>
									<div class="top-discontent">
										<?php echo $row3->live_hours;?> Hours 
										Live Training 
									</div>
	            			    	<?php			
	            			    	}
	            			    	if(!$row3->lab_exercises=='')
	            			    	{
	            			    	?>
	            			    	<div class="top-discontent"><?php echo $row3->lab_exercises;?> Hours Lab Exercises
	            			    	</div>
	            			    	<?php	
	            			    	}
	            			    	if(!$row3->real_timeproject=='')
	            			    	{
	            			    	?>
	            			    	 <div class="top-discontent"><?php echo $row3->real_timeproject;?> Realtime Projects
	            			    	 </div>	
	            			    	<?php	
	            			    	}	
	            			    ?>
	            			 </div>
	            				<center><a href="<?php echo base_url()?>CourseDetails/<?php echo $course_name3;?>" class="btn btn-primary discount_btn_more">View Course</a> </center>
            				</div>
            				</a>
							</div>
						</div>
							<?php	
						  }
						?>
						
					</div>
				</div>
			</div>
		</div>
	</section>	
	
	
	<section class="review_wrapper" >
    <div class="container">
        <div class="row">
           <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
           	<?php
           		if(!empty($Reviews))
           		{
           			?>
           			<h3> <?php echo $row->course_name;?> Reviews </h3> 
           			<?php
           		}
           	?>
            </div>
        </div>
        <div class="row">
         <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">                  
        <div class="hachion_review_carousel">
		<?php
		foreach ($Reviews as $Reviews) {
		$CanLocation=$this->db->where('email',$Reviews->email)
		->get('registration');
		foreach ($CanLocation->result() as $ReviewData) {	
		?>	     					
          <div class="hachion_review_post">
            <div class="hachion_reviewoverall">
                <div class="hachion_review_left">
                    <div class="hachion_review_thumb">
                        <p style="background:#2874f0;">
                            <?php echo substr($ReviewData->name, 0, 1);?> </p>
                    </div>
                    <div class="hachion_review_rating"> 
                        <div class="starratings">
						<?php
							if($Reviews->rating==1)
							{
							 ?>
							 <i class="fa fa-star"></i>
							 <?php		
							}
							if($Reviews->rating==2)
							{
							 ?>
							 <i class="fa fa-star"></i>
							  <i class="fa fa-star"></i>
							 <?php		
							}
							if($Reviews->rating==3)
							{
							 ?>
							 <i class="fa fa-star"></i>
							  <i class="fa fa-star"></i>
							  <i class="fa fa-star"></i>
							 <?php	
							}
							if($Reviews->rating==4)
							{
							 ?>
							 <i class="fa fa-star"></i>
							  <i class="fa fa-star"></i>
							  <i class="fa fa-star"></i>
							    <i class="fa fa-star"></i>
							 <?php	
							}
							if($Reviews->rating==5)
							{
							 ?>
							 <i class="fa fa-star"></i>
							  <i class="fa fa-star"></i>
							  <i class="fa fa-star"></i>
							  <i class="fa fa-star"></i>
							  <i class="fa fa-star"></i>
							 <?php
							}	
						?>                       
                        </div>
                       </div>
                </div>
                <div class="hachion_review_right">
                    <div class="hachion_review_title">
                    <h4><?php echo $ReviewData->name;?></h4> 
                    <p><?php echo $ReviewData->iso;?>,<?php echo $ReviewData->location;?></p>
                    </div>
                    <div class="hachion_review_content">
                       <p><?php echo $Reviews->review?> </p>
                     </div>
                 </div>
              </div>
            </div>
            <?php
			  }
			 }
			?> 	
          </div>
          <div class="hachion_review_post">
          	<div class="row">
          	 <div class="col-md-2"> </div>
	        <div class="col-md-10  mt10">
			<h3> Grab a chance to work with one of my reputed partner in IT Industry </h3>
			<img src="<?php echo base_url()?>assets/images/company.png">
			</div>
		</div>
	    </div>
        </div>

        </div>
    </div>
</section>
<div class="sign_up_modal modal fade" id="exampleModalSchedule" tabindex="-1" role="dialog" aria-hidden="true">
	  	<div class="modal-dialog modal-dialog-centered" role="document">
	    	<div class="modal-content">
		      	<div class="modal-header">
		        	<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		      	</div>
	    		<?php
	    		
	        	$registration_id=$this->session->userdata('registration_id');
				$student_name=$this->session->userdata('student_name');
				$student_mobile=$this->session->userdata('student_mobile');
				$student_email=$this->session->userdata('student_email');
	    		?>
				<div class="tab-content" id="myTabContent">
				  	<div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
				  	      <div class="footr-modal">
							<div class="row ">
							<div class="col-xl-2 col-2">
							<img src="<?php echo base_url()?>assets/images/about/calendar-flat.png" alt="calender">	
							</div>
							<div class="col-xl-10 col-10">
							<div class="heading">
							<h4 class="white-text">
							Tell Us Your Preferred Starting Date
							</h4>
							</div>
							</div>	
							</div>
						</div>
						<div class="login_form">
							<form action="<?php echo base_url()?>Hachion/RescheduleReq" method="POST" id="register">
								<input type="hidden" name="url" value="<?php echo base_url()?>CourseDetails/<?php echo $course_name;?>">
								
									<?php $ip_address=$_SERVER['REMOTE_ADDR'];?>
								<input type="hidden" name="ip_address" value="<?php echo $ip_address;?>">
								<input type="hidden" name="course_id" value="<?php echo $row->course_id;?>">
								<input type="hidden" name="course_name" value="<?php echo $row->course_name;?>">
									<?php

										$date=date('Y-m-d');
									?>
								 <div class="form-group">
							    	<input  type="text" name="schedule_date" class="form-control" id="shootdate" placeholder="Preferred Schedule Start Date" pattern="(0[1-9]|1[012])[- /.](0[1-9]|[12][0-9]|3[01])[- /.](19|20)\d\d" required/>
								</div>
								<div class="form-group">
							    	<select name="shedule_timings" class="form-control" required><option value="">Preferred Schedule Start Time</option><option value="12:00am">12:00am</option><option value="12:30am">12:30am</option><option value="1:00am">1:00am</option><option value="1:30am">1:30am</option><option value="2:00am">2:00am</option><option value="2:30am">2:30am</option><option value="3:00am">3:00am</option><option value="3:30am">3:30am</option><option value="4:00am">4:00am</option><option value="4:30am">4:30am</option><option value="5:00am">5:00am</option><option value="5:30am">5:30am</option><option value="6:00am">6:00am</option><option value="6:30am">6:30am</option><option value="7:00am">7:00am</option><option value="7:30am">7:30am</option><option value="8:00am">8:00am</option><option value="8:30am">8:30am</option><option value="9:00am">9:00am</option><option value="9:30am">9:30am</option><option value="10:00am">10:00am</option><option value="10:30am">10:30am</option><option value="11:00am">11:00am</option><option value="11:30am">11:30am</option><option value="12:00pm">12:00pm</option><option value="12:30pm">12:30pm</option><option value="1:00pm">1:00pm</option><option value="1:30pm">1:30pm</option><option value="2:00pm">2:00pm</option><option value="2:30pm">2:30pm</option><option value="3:00pm">3:00pm</option><option value="3:30pm">3:30pm</option><option value="4:00pm">4:00pm</option><option value="4:30pm">4:30pm</option><option value="5:00pm">5:00pm</option><option value="5:30pm">5:30pm</option><option value="6:00pm">6:00pm</option><option value="6:30pm">6:30pm</option><option value="7:00pm">7:00pm</option><option value="7:30pm">7:30pm</option><option value="8:00pm">8:00pm</option><option value="8:30pm">8:30pm</option><option value="9:00pm">9:00pm</option><option value="9:30pm">9:30pm</option><option value="10:00pm">10:00pm</option><option value="10:30pm">10:30pm</option><option value="11:00pm">11:00pm</option><option value="11:30pm">11:30pm</option> </select>	
								</div>

								<script>
								$( function() {
								$( "#shootdate" ).datepicker({
								minDate: 0, dateFormat: 'mm-dd-yy'
								});
								});
								</script>

							  <div class="form-group">
							    	<select name="schedule_mode" class="form-control" required>
							   <option value="">Select</option>
							    <option value="Live Demo">Live Demo </option>
							    <option value="Live Class">Live Class </option>
							    	</select>
								</div>

								 <div class="form-group">
							    	<input type="email"  name="email" class="form-control" placeholder="Email-Id" value="<?php echo $student_email;?>" required>
								</div>

								<div class="form-group">
							<input type="tel" name="mobile" id="phone"  class="form-control" required placeholder="Mobile" value="<?php echo $student_mobile;?>" pattern="[+]?[1-9][0-9]{9,14}" >
								</div>

								<input type="hidden" name="iso" id="demor">

								<button type="submit"  class="btn btn-log btn-block btn-thm2 btnbgcolor">Submit Request</button>
								<hr>
								
							</form>
						</div>
				  	</div>
				</div>
	    	</div>
	  	</div>
	</div>

	<?php
	}
	?>
<style>
@media (min-width: 320px) and (max-width: 480px) {
  	.csv1
	{
	  height:auto !important;
	  padding: 0px !important;
	  line-height:auto; 
	}
	 .subtitle
	{
	display: none !important;	
	}
}
</style>

	   
                <!-- Modal -->
				<div class="sign_up_modal modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-hidden="true">
	  	            <div class="modal-dialog modal-dialog-centered" role="document">
	    	            <div class="modal-content">
		      	        <div class="modal-header">
		        	    <button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
		      	        </div>
				     <div class="tab-content" id="myTabContent">
				    	<div class="tab-pane fade show active" id="home" role="tabpanel" aria-labelledby="home-tab">
				    	    	<div class="footr-modal">
							<div class="row ">
							<div class="col-xl-2 col-2">
								<img src="<?php echo base_url()?>assets/images/cloud-account-login-male.png"/>
							</div>
							<div class="col-xl-8 col-10">
							<div class="heading">
							<h4 style="font-style:bold; font-size:21px;text-align:center;">
							Login
							</h4>
							</div>
							</div>	
							</div>
						<p class="text-center">Don't have an account? <a class="text-thm" style="color:#fff !important;" href="<?php echo base_url()?>register">
							 Register Here</a></p>
						</div>
						<div class="login_form">
							<form action="#">
								 <div class="form-group" style="text-align:left !important;">
								 	<label><span style="color:red;">* </span> Email-Id</label>
							    	<input type="email" id="email" class="form-control"  value="<?php echo $this->session->flashdata('email');?>" required>
								</div>
								<div class="form-group" style="text-align:left !important;">
									<label><span style="color:red;">* </span> Password</label>
							    	<input type="password"  id="password" class="form-control" value="<?php echo $this->session->flashdata('password');?>"required>
								</div>
									<div class="error" id="logerror" style="color:red;"></div>
								<div class="form-group custom-control custom-checkbox">
									<a class="tdu btn-fpswd float-right" href="<?php echo base_url()?>ForgotPassword">Forgot Password?</a>
								</div>
								<button type="submit" onclick="myFunction()" id="Login" class="btn btn-log btn-block btn-thm2 btnbgcolor">Login</button>
								<hr>
								
							</form>
						</div>
				  	</div>
				  	
				</div>
	    	</div>
	  	</div>
	</div>

<script src="http://ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
<script type="text/javascript">
$(document).ready(function() {
$("#Login").click(function(event) {
event.preventDefault();
var email = $("#email").val();
var password =$("#password").val();

jQuery.ajax({
type: "POST",
url: "<?php echo base_url()?>" + "Hachion/customerlogin",
dataType: 'json',
data: {email: email,password: password},
    success: function(data)
             {
               if(data==1)              
               window.location.href = "<?php echo base_url()?>CourseDetails/<?php echo $course_name;?>";
               else
$('#logerror').html('Incorrect Email-ID/Password');
                     $('#logerror').addClass("error");
             }
});
});
});
</script>

	<?php include('include/footer.php');?>