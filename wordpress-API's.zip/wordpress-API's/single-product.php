<?php

/**
 * Template Name: Single Product

 */

get_header(); 

?>
<?php

// $meta_values = get_post_meta( $post->ID );

// echo "<pre>"; print_r($meta_values);





$product = wc_get_product( $post->ID );



$nonVariable = $product->get_regular_price();
$product->get_sale_price();
$product->get_price();

//$regular_price  =  $product->get_variation_regular_price();

$variation_id = $_GET['variation_ID'];


$price1 = get_post_meta($variation_id, '_regular_price', true);




 if( $product->is_type( 'simple' ) ) {
    $price = $nonVariable;
    } else {
   $price = $price1;
    }







?>
<div class="innerbanner_textbox" style="background-image:url(<?php echo get_template_directory_uri(); ?>/images/coursebg.jpg);">
  <div class="container">
    <div class="innerbanner_contactbox">
     <h1><?php the_title(); ?></h1>
     <p><?php echo get_field('haeder_text',$post->ID); ?></p>
     <div class="btn-group">
      <!-- <a href="#" class="btn btn-outline-light">قائمة الرغبات <span class="select-fav"><input type="checkbox" class="custom-control-input"
                                                                    id="fab-1">
                                                                <label class="fav" for="fab-1"></label>
                                                            </span></a> -->
      <a href="#" class="btn btn-outline-light">يشارك <i class="zmdi zmdi-mail-reply"></i></a>
     </div>
    </div>
  </div>
</div>
<div class="innermain">
  <div class="container">
     <div class="course_pagearea">
        <div class="container">
           <div class="row">
             <div class="col-lg-8">
                <div class="course_page_rightbox">
                   <h2>محتوى الدورة</h2>
                  <ul>
                    <li><a href="#"><strong>5</strong> أقسام</a></li>
                    <li><a href="#"><strong>70</strong> محاضرة</a></li>
                    <li><a href="#"> الطول الإجمالي <strong>150h 17m</strong></a></li>
                  </ul>
                  <div class="accordion" id="course">
                            <div class="card">


                                <div class="card-header" id="faqhead1">
                                    <a href="#" class="btn btn-header-link" data-toggle="collapse" data-target="#faq1" aria-expanded="true" aria-controls="faq1"><span>المستوى 1</span></a>
                                </div>
        
                                <div id="faq1" class="collapse show" aria-labelledby="faqhead1" data-parent="#course">
                                    <div class="card-body">
                                       <div class="d-flex justify-content-between">
                                         <div class="boxone d-flex justify-content-between">
                                           <p><i class="fas fa-play-circle"></i></p>
                                           <p>Introduction</p>
                                          </div>
                                          <div class="boxone d-flex justify-content-between">
                                            <p><a href="#">Preview</a></p>
                                            <p>07:15</p>
                                           </div>
                                        </div>
                                    </div>
                                </div>

                                
                            </div>
                            <div class="card">
                                <div class="card-header" id="faqhead2">
                                    <a href="#" class="btn btn-header-link collapsed" data-toggle="collapse" data-target="#faq2" aria-expanded="true" aria-controls="faq2"><span>المستوى 2</span></a>
                                </div>
        
                                <div id="faq2" class="collapse" aria-labelledby="faqhead2" data-parent="#course">
                                    <div class="card-body">
                                       <div class="d-flex justify-content-between">
                                         <div class="boxone d-flex justify-content-between">
                                           <p><i class="fas fa-play-circle"></i></p>
                                           <p>Alphabets</p>
                                          </div>
                                          <div class="boxone d-flex justify-content-between">
                                            <p><a href="#">Preview</a></p>
                                            <p>05:01</p>
                                           </div>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                         <div class="boxone d-flex justify-content-between">
                                           <p><i class="fas fa-play-circle"></i></p>
                                           <p>Vowels</p>
                                          </div>
                                          <div class="boxone d-flex justify-content-between">
                                            <p>04:21</p>
                                           </div>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                         <div class="boxone d-flex justify-content-between">
                                           <p><i class="fas fa-play-circle"></i></p>
                                           <p>Noun</p>
                                          </div>
                                          <div class="boxone d-flex justify-content-between">
                                            <p>14:32</p>
                                           </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="faqhead3">
                                    <a href="#" class="btn btn-header-link collapsed" data-toggle="collapse" data-target="#faq3" aria-expanded="true" aria-controls="faq3"><span>المستوى 3</span></a>
                                </div>
        
                                <div id="faq3" class="collapse" aria-labelledby="faqhead3" data-parent="#course">
                                    <div class="card-body">
                                       <div class="d-flex justify-content-between">
                                         <div class="boxone d-flex justify-content-between">
                                           <p><i class="fas fa-play-circle"></i></p>
                                           <p>Introduction</p>
                                          </div>
                                          <div class="boxone d-flex justify-content-between">
                                            <p><a href="#">Preview</a></p>
                                            <p>07:15</p>
                                           </div>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                         <div class="boxone d-flex justify-content-between">
                                           <p><i class="fas fa-play-circle"></i></p>
                                           <p>Alphabets</p>
                                          </div>
                                          <div class="boxone d-flex justify-content-between">
                                            <p><a href="#">Preview</a></p>
                                            <p>05:01</p>
                                           </div>
                                        </div>
                                       
                                        <div class="d-flex justify-content-between">
                                         <div class="boxone d-flex justify-content-between">
                                           <p><i class="fas fa-play-circle"></i></p>
                                           <p>Noun</p>
                                          </div>
                                          <div class="boxone d-flex justify-content-between">
                                            <p>14:32</p>
                                           </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="card">
                                <div class="card-header" id="faqhead4">
                                    <a href="#" class="btn btn-header-link collapsed" data-toggle="collapse" data-target="#faq4" aria-expanded="true" aria-controls="faq4"><span>المستوى 4</span></a>
                                </div>
        
                                <div id="faq4" class="collapse" aria-labelledby="faqhead4" data-parent="#course">
                                    <div class="card-body">
                                       <div class="d-flex justify-content-between">
                                         <div class="boxone d-flex justify-content-between">
                                           <p><i class="fas fa-play-circle"></i></p>
                                           <p>Conversation</p>
                                          </div>
                                          <div class="boxone d-flex justify-content-between">
                                           <p>24:00</p>
                                          </div>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                         <div class="boxone d-flex justify-content-between">
                                           <p><i class="fas fa-play-circle"></i></p>
                                           <p>Speaking Skills</p>
                                          </div>
                                          <div class="boxone d-flex justify-content-between">
                                             <p>34:23</p>
                                           </div>
                                        </div>
                                        <div class="d-flex justify-content-between">
                                         <div class="boxone d-flex justify-content-between">
                                           <p><i class="fas fa-play-circle"></i></p>
                                           <p>Summary</p>
                                          </div>
                                          <div class="boxone d-flex justify-content-between">
                                            <p>54:14</p>
                                           </div>
                                        </div>
                                        
                                    </div>
                                </div>
                            </div>
                      </div>
                 </div>
             </div>
             <div class="col-lg-4">
               <div class="course_page_leftbox">
                  <div class="asidebox">

                     <div class="asidethumble">
                      <img src="<?php echo get_template_directory_uri(); ?>/images/coursevideo.jpg" alt=""> 
                       <a id="play-video" class="video-play-button" data-fancybox href="<?php echo get_field('youtube_link',$post->ID); ?>">
                          <span></span>
                        </a>
                        <p>معاينة هذه الدورة</p>
                     </div>


                     <div class="asidebody">
                       <h3><?php echo $price; ?><img src="<?php echo get_template_directory_uri(); ?>/images/courseicon1.jpg" alt=""></h3>


<form class="cart">
<input type="hidden" name="product_id" value="<?php echo $post->ID; ?>">
<input type="hidden" name="variation_id" value="<?php echo $variation_id; ?>">
<input type="hidden" name="qty" value="1">
<a href="https://enigma-study.com/subs-time/" class="btn btn-outline-primary" name="add-to-cart" value="<?php echo $post->ID; ?>">اشتري الآن  </a>
</form> 

                      



                       <p>ضمان استرداد الأموال لمدة 30 يومًا</p>
                       <ul>
                       <h4>تشمل هذه الدورة :</h4>
                         <li><img src="images/courseiconright1.png" alt=""> 150 ساعة من أفضل مقاطع الفيديو الموضحة </li>
                         <li><img src="images/courseiconright2.png" alt=""> الموارد القابلة للتنزيل </li>
                         <li><img class="ph" src="images/courseiconright3.png" alt=""> الوصول على الهاتف المحمول والكمبيوتر</li>
                         <li><img class="beach" src="images/courseiconright4.png" alt=""> شهادة إتمام</li>
                       </ul>
                       <h5>تطبيق القسيمة</h5>
                       
                       <div class="coach_area">
                         <h3>مدرب</h3>
                         <div class="coachbox">
                           <div class="thumble_coach">
                            <img src="images/team2.png" alt=""> 
                           </div>
                           <h4>ربيع قبلان</h4>
                           <p>مؤسس معهد إنيجم <br>خريج لقب علم الحاسوب - التخنيون</p>
                         </div>
                       </div>
                     </div>
                  </div>
               </div>
             </div>
           </div>
           
           <div class="studentnotes_area">
           <div class="row">
             <div class="col-lg-4 col-md-4">
               <div class="studentnotes_left">
                  <h2>ملاحظات الطلاب</h2>
                  <h3>4.7</h3>
                  <ul>
                    <li><i class="fas fa-star-half-alt" ></i></li>
                    <li><i class="fas fa-star" ></i></li>
                    <li><i class="fas fa-star" ></i></li>
                    <li><i class="fas fa-star" ></i></li>
                    <li><i class="fas fa-star" ></i></li>
                  </ul>
                  <p>تصنيف الدورة</p>
               </div>
             </div>
             <div class="col-lg-8 col-md-8">
               <div class="studentnotes_right">
                 <div class="media">
                  <img class="d-flex mr-3" src="images/testimg.jpg">
                  <div class="media-body">
                    <h5 class="mt-0">رامي يوسف</h5>
                     <ul>
                        <li><i class="fas fa-star-half-alt" ></i></li>
                        <li><i class="fas fa-star" ></i></li>
                        <li><i class="fas fa-star" ></i></li>
                        <li><i class="fas fa-star" ></i></li>
                        <li><i class="fas fa-star" ></i></li>
                      </ul>
                    هذه الدورة مثالية لأي شخص لغته الأم ليست الإنجليزية ويريد تعلم كيفية قراءة أصوات الإنجليزية الأمريكية والتعرف عليها بشكل طبيعي ، لا مزيد من الحفظ. يتم تدريس كل شيء بطريقة طبيعية للغاية وبديهية. الدورة سهلة للغاية ، وربيع معلم رائع ، يمكنك أن تقول إنه يحب حقًا مشاركة معرفته ولديه موهبة في التعليم والأشخاص. طلبي الوحيد هو أنني أرغب في رؤية المزيد من الدورات التدريبية الجديدة التي تركز على تعميق واختبار مهاراتنا المكتسبة الجديدة ، مثل القراءة لمتخصصي تكنولوجيا المعلومات ، أو لمجالات العلوم ، نصائح من ربيع حول كيفية تقليل اللهجات المختلفة ، أي شيء يراه يمكن أن تساعدنا في تحسين لهجتنا.
                  </div>
                </div>
               </div>
             </div>
           </div>
          </div>
        </div>
     </div>
  </div>
</div>


<?php get_footer(); ?>